--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.4
-- Dumped by pg_dump version 9.5.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: publicacao; Type: SCHEMA; Schema: -; Owner: urbem
--

CREATE SCHEMA publicacao;


ALTER SCHEMA publicacao OWNER TO urbem;

--
-- Name: transparencia; Type: SCHEMA; Schema: -; Owner: urbem
--

CREATE SCHEMA transparencia;


ALTER SCHEMA transparencia OWNER TO urbem;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: process; Type: TYPE; Schema: public; Owner: urbem
--

CREATE TYPE process AS (
	base character varying(50),
	usuario character varying(30),
	processo integer,
	inicio timestamp without time zone,
	consulta text
);


ALTER TYPE process OWNER TO urbem;

--
-- Name: fn_transparencia_remuneracao(character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: urbem
--

CREATE FUNCTION fn_transparencia_remuneracao(character varying, integer, character varying, integer) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $_$
DECLARE
stEntidade                ALIAS FOR $1;
inCodPeriodoMovimentacao  ALIAS FOR $2;
stExercicio               ALIAS FOR $3;
inCodEntidade             ALIAS FOR $4;
stSql                     VARCHAR;
stSqlInsert               VARCHAR;
stSqlUpdate               VARCHAR;
arTipo                    VARCHAR[];
reRegistro                RECORD;
indice		  	          INT;

BEGIN

	 -- LIMPA TABELA DE REGISTROS
	 stSql := 'DELETE FROM temp_transparencia_remuneracao';
	 EXECUTE stSql;

  	 stSql := 'SELECT   contrato.registro
		          , contrato.cod_contrato
			  , sw_cgm.nom_cgm AS cgm
			  , '||quote_literal(inCodEntidade)||'::varchar as cod_entidade
		     FROM pessoal'||stEntidade||'.contrato
	       INNER JOIN (SELECT cod_contrato, numcgm
			     FROM pessoal'||stEntidade||'.servidor, pessoal.servidor_contrato_servidor
			    WHERE servidor.cod_servidor = servidor_contrato_servidor.cod_servidor
				   
			    UNION 
			       
			   SELECT contrato_pensionista.cod_contrato, numcgm
			     FROM pessoal'||stEntidade||'.contrato_pensionista, pessoal.pensionista
			    WHERE contrato_pensionista.cod_pensionista = pensionista.cod_pensionista
			      AND contrato_pensionista.cod_contrato_cedente = pensionista.cod_contrato_cedente 
			  ) AS servidor_pensionista
			ON servidor_pensionista.cod_contrato = contrato.cod_contrato
		INNER JOIN sw_cgm
			ON sw_cgm.numcgm = servidor_pensionista.numcgm
		INNER JOIN folhapagamento'||stEntidade||'.contrato_servidor_periodo
			ON contrato_servidor_periodo.cod_contrato = contrato.cod_contrato
		     WHERE contrato_servidor_periodo.cod_periodo_movimentacao = '||inCodPeriodoMovimentacao||'
		  ORDER BY contrato.registro, contrato.cod_contrato';

	FOR reRegistro IN EXECUTE stSql LOOP
	    IF reRegistro.cod_entidade = '' THEN
		reRegistro.cod_entidade := NULL;
	    END IF;

	    stSqlInsert := 'INSERT INTO temp_transparencia_remuneracao (registro, cod_contrato, cgm, cod_periodo_movimentacao, cod_entidade, exercicio) VALUES ('||reRegistro.registro||', '||reRegistro.cod_contrato||', '||quote_literal(reRegistro.cgm)||', '||inCodPeriodoMovimentacao||', '||inCodEntidade||', '||quote_literal(stExercicio)||')';
	    EXECUTE stSqlInsert;
	END LOOP; 

	
	arTipo[1]  := 'remuneracao_bruta';
	arTipo[2]  := 'redutor_teto';
	arTipo[3]  := 'remuneracao_natalina';
	arTipo[4]  := 'remuneracao_ferias';
	arTipo[5]  := 'remuneracao_outras';
	arTipo[6]  := 'deducoes_irrf';
	arTipo[7]  := 'deducoes_obrigatorias';
    arTipo[8]  := 'demais_deducoes';
    arTipo[9]  := 'salario_familia';
    arTipo[10] := 'jetons';
    arTipo[11] := 'verbas';

	FOR indice IN 1..array_upper(arTipo,1) LOOP        
            stSql := ' SELECT contrato.registro,
                              COALESCE(SUM(folhas.valor), 0) AS valor_calculado
       			    
       			 FROM pessoal'||stEntidade||'.contrato
       			 
       			 JOIN (SELECT cod_contrato
       				   FROM pessoal'||stEntidade||'.servidor, pessoal.servidor_contrato_servidor
       				   WHERE servidor.cod_servidor = servidor_contrato_servidor.cod_servidor
                                   
       			      UNION
                              
       			      SELECT contrato_pensionista.cod_contrato
       				FROM pessoal'||stEntidade||'.contrato_pensionista, pessoal.pensionista
       			       WHERE contrato_pensionista.cod_pensionista = pensionista.cod_pensionista
                                 AND contrato_pensionista.cod_contrato_cedente = pensionista.cod_contrato_cedente
       			      ) AS servidor_pensionista
       			   ON servidor_pensionista.cod_contrato = contrato.cod_contrato
       			   
       			 JOIN ( 
       
       			       SELECT ''salario''::varchar as ind_fl                 
       					, registro_evento_periodo.cod_contrato 
       					, evento.codigo               
       					, evento.descricao 
       					, evento.natureza 
       					, evento_calculado.valor 
       					, evento_calculado.quantidade
       					, CASE WHEN evento_calculado.desdobramento IS NULL THEN ''''::varchar
       					       ELSE evento_calculado.desdobramento END AS desdobramento
       
       				      FROM folhapagamento'||stEntidade||'.registro_evento 
       				    
       				INNER JOIN folhapagamento'||stEntidade||'.registro_evento_periodo
       					ON registro_evento_periodo.cod_registro = registro_evento.cod_registro
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento
       					ON evento.cod_evento = registro_evento.cod_evento
       
       				INNER JOIN folhapagamento'||stEntidade||'.ultimo_registro_evento
       					ON ultimo_registro_evento.cod_evento   = registro_evento.cod_evento        
       				       AND ultimo_registro_evento.cod_registro = registro_evento.cod_registro
       				       AND ultimo_registro_evento.timestamp    = registro_evento.timestamp
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento_calculado
       					ON evento_calculado.cod_evento 		 = registro_evento.cod_evento
       				       AND evento_calculado.cod_registro         = registro_evento.cod_registro
       				       AND evento_calculado.timestamp_registro   = registro_evento.timestamp
       
       				INNER JOIN pessoal'||stEntidade||'.contrato
       					ON contrato.cod_contrato = registro_evento_periodo.cod_contrato
            
       				     WHERE registro_evento_periodo.cod_periodo_movimentacao = '||inCodPeriodoMovimentacao||'
       				       AND contrato.registro 			     	    IN (SELECT registro FROM temp_transparencia_remuneracao)
       				     
       			      UNION
       			      
       				SELECT ''ferias''::varchar as ind_fl        
       				      , registro_evento_ferias.cod_contrato
       				      , evento.codigo
       				      , evento.descricao
       				      , evento.natureza
       				      , evento_ferias_calculado.valor
       				      , evento_ferias_calculado.quantidade
       				      , evento_ferias_calculado.desdobramento
       
       				      FROM folhapagamento'||stEntidade||'.registro_evento_ferias 
       
       				INNER JOIN folhapagamento'||stEntidade||'.ultimo_registro_evento_ferias
       					ON ultimo_registro_evento_ferias.cod_evento    = registro_evento_ferias.cod_evento        
       				       AND ultimo_registro_evento_ferias.cod_registro  = registro_evento_ferias.cod_registro
       				       AND ultimo_registro_evento_ferias.timestamp     = registro_evento_ferias.timestamp
       				       AND ultimo_registro_evento_ferias.desdobramento = registro_evento_ferias.desdobramento
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento_ferias_calculado
       					ON evento_ferias_calculado.cod_evento 	 = ultimo_registro_evento_ferias.cod_evento
       				       AND evento_ferias_calculado.cod_registro  = ultimo_registro_evento_ferias.cod_registro
       				       AND evento_ferias_calculado.timestamp_registro     = ultimo_registro_evento_ferias.timestamp
       				       AND evento_ferias_calculado.desdobramento = ultimo_registro_evento_ferias.desdobramento
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento
       					ON evento.cod_evento = registro_evento_ferias.cod_evento
       
       				INNER JOIN pessoal'||stEntidade||'.contrato
       					ON contrato.cod_contrato = registro_evento_ferias.cod_contrato
       				     
       				     WHERE registro_evento_ferias.cod_periodo_movimentacao = '||inCodPeriodoMovimentacao||'
       				       AND contrato.registro 			           IN (SELECT registro FROM temp_transparencia_remuneracao)
       				     
       			      UNION
       			      
       				SELECT ''decimo''::varchar as ind_fl        
       				      , registro_evento_decimo.cod_contrato
       				      , evento.codigo
       				      , evento.descricao
       				      , evento.natureza
       				      , evento_decimo_calculado.valor
       				      , evento_decimo_calculado.quantidade
       				      , evento_decimo_calculado.desdobramento
       
       				      FROM folhapagamento'||stEntidade||'.registro_evento_decimo 
       
       				INNER JOIN folhapagamento'||stEntidade||'.ultimo_registro_evento_decimo
       					ON ultimo_registro_evento_decimo.cod_evento    = registro_evento_decimo.cod_evento        
       				       AND ultimo_registro_evento_decimo.cod_registro  = registro_evento_decimo.cod_registro
       				       AND ultimo_registro_evento_decimo.timestamp     = registro_evento_decimo.timestamp
       				       AND ultimo_registro_evento_decimo.desdobramento = registro_evento_decimo.desdobramento
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento_decimo_calculado
       					ON evento_decimo_calculado.cod_evento 	      = ultimo_registro_evento_decimo.cod_evento
       				       AND evento_decimo_calculado.cod_registro       = ultimo_registro_evento_decimo.cod_registro
       				       AND evento_decimo_calculado.timestamp_registro = ultimo_registro_evento_decimo.timestamp
       				       AND evento_decimo_calculado.desdobramento      = ultimo_registro_evento_decimo.desdobramento
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento
       					ON evento.cod_evento = registro_evento_decimo.cod_evento
       
       				INNER JOIN pessoal'||stEntidade||'.contrato
       					ON contrato.cod_contrato = registro_evento_decimo.cod_contrato
       				     
       				     WHERE registro_evento_decimo.cod_periodo_movimentacao = '||inCodPeriodoMovimentacao||'
       				       AND contrato.registro 			     	   IN (SELECT registro FROM temp_transparencia_remuneracao)
       				       
       			      UNION
       
       				SELECT ''rescisao''::varchar as ind_fl
       				      , registro_evento_rescisao.cod_contrato
       				      , evento.codigo
       				      , evento.descricao
       				      , evento.natureza   
       				      , evento_rescisao_calculado.valor
       				      , evento_rescisao_calculado.quantidade
       				      , evento_rescisao_calculado.desdobramento
       
       				      FROM folhapagamento'||stEntidade||'.registro_evento_rescisao 
       
       				INNER JOIN folhapagamento'||stEntidade||'.ultimo_registro_evento_rescisao
       					ON ultimo_registro_evento_rescisao.cod_evento    = registro_evento_rescisao.cod_evento        
       				       AND ultimo_registro_evento_rescisao.cod_registro  = registro_evento_rescisao.cod_registro
       				       AND ultimo_registro_evento_rescisao.timestamp     = registro_evento_rescisao.timestamp
       				       AND ultimo_registro_evento_rescisao.desdobramento = registro_evento_rescisao.desdobramento
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento_rescisao_calculado
       					ON evento_rescisao_calculado.cod_evento 	= ultimo_registro_evento_rescisao.cod_evento
       				       AND evento_rescisao_calculado.cod_registro       = ultimo_registro_evento_rescisao.cod_registro
       				       AND evento_rescisao_calculado.timestamp_registro = ultimo_registro_evento_rescisao.timestamp
       				       AND evento_rescisao_calculado.desdobramento      = ultimo_registro_evento_rescisao.desdobramento
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento
       					ON evento.cod_evento = registro_evento_rescisao.cod_evento
       
       				INNER JOIN pessoal'||stEntidade||'.contrato
       					ON contrato.cod_contrato = registro_evento_rescisao.cod_contrato
       				     
       				     WHERE registro_evento_rescisao.cod_periodo_movimentacao = '||inCodPeriodoMovimentacao||'
       				       AND contrato.registro 			     	     IN (SELECT registro FROM temp_transparencia_remuneracao)
       			      
       			      UNION
       			      
       				SELECT ''complementar''::varchar as ind_fl
       				      , registro_evento_complementar.cod_contrato
       				      , evento.codigo
       				      , evento.descricao
       				      , evento.natureza
       				      , evento_complementar_calculado.valor
       				      , evento_complementar_calculado.quantidade
       				      , CASE WHEN evento_complementar_calculado.desdobramento IS NULL THEN ''''::varchar
       					     ELSE evento_complementar_calculado.desdobramento END AS desdobramento
       
       				      FROM folhapagamento'||stEntidade||'.registro_evento_complementar 
       
       				INNER JOIN folhapagamento'||stEntidade||'.ultimo_registro_evento_complementar
       					ON ultimo_registro_evento_complementar.cod_evento    = registro_evento_complementar.cod_evento        
       				       AND ultimo_registro_evento_complementar.cod_registro  = registro_evento_complementar.cod_registro
       				       AND ultimo_registro_evento_complementar.timestamp     = registro_evento_complementar.timestamp
       				       AND ultimo_registro_evento_complementar.cod_configuracao = registro_evento_complementar.cod_configuracao
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento_complementar_calculado
       					ON evento_complementar_calculado.cod_evento 	    = ultimo_registro_evento_complementar.cod_evento
       				       AND evento_complementar_calculado.cod_registro       = ultimo_registro_evento_complementar.cod_registro
       				       AND evento_complementar_calculado.timestamp_registro = ultimo_registro_evento_complementar.timestamp
       				       AND evento_complementar_calculado.cod_configuracao   = ultimo_registro_evento_complementar.cod_configuracao
       
       				INNER JOIN folhapagamento'||stEntidade||'.evento
       					ON evento.cod_evento = registro_evento_complementar.cod_evento
       
       				INNER JOIN pessoal'||stEntidade||'.contrato
       					ON contrato.cod_contrato = registro_evento_complementar.cod_contrato
       				     
       				     WHERE registro_evento_complementar.cod_periodo_movimentacao = '||inCodPeriodoMovimentacao||'
       				       AND contrato.registro 			     	         IN (SELECT registro FROM temp_transparencia_remuneracao)
       			      ) AS folhas
       			   ON contrato.cod_contrato = folhas.cod_contrato ';
                                  
       	    IF indice = 1 THEN
	       stSql := stSql || ' WHERE folhas.natureza = ''P''
				     AND folhas.desdobramento IN ('''', ''S'')
				     AND folhas.codigo NOT IN ( SELECT evento.codigo
					                          FROM folhapagamento'||stEntidade||'.ferias_evento
							    INNER JOIN folhapagamento'||stEntidade||'.evento
								    ON evento.cod_evento = ferias_evento.cod_evento
							         WHERE cod_tipo = 2
								   AND timestamp <= (SELECT * FROM ultimotimestampperiodomovimentacao('||inCodPeriodoMovimentacao||', '''||stEntidade||'''))
							      ORDER BY timestamp DESC LIMIT 1)
						
				     AND NOT (folhas.codigo::integer = ANY(string_to_array((SELECT CASE WHEN configuracao.valor != '''' THEN configuracao.valor ELSE ''0'' END
										             FROM administracao.configuracao
										            WHERE cod_modulo = 8
										              AND exercicio = '''|| stExercicio ||'''
										              AND parametro = ''remuneracao_eventual''), '','')))';
	    END IF;	    
	    
	    IF indice = 2 THEN
	       stSql := stSql || ' WHERE folhas.codigo::integer = ANY(string_to_array((SELECT CASE WHEN configuracao.valor != '''' THEN configuracao.valor ELSE ''0'' END
											      FROM administracao.configuracao
											     WHERE cod_modulo = 8
											       AND exercicio = '''|| stExercicio ||'''
											       AND parametro = ''redutor_teto''), '',''))';
	    END IF;

	    IF indice = 3 THEN
		stSql := stSql || ' WHERE folhas.desdobramento = ''D'' AND folhas.natureza = ''P'' AND ind_fl != ''ferias''';
	    END IF;
	    
	    IF indice = 4 THEN
	        stSql := stSql || ' WHERE folhas.codigo IN ( SELECT evento.codigo
							       FROM folhapagamento'||stEntidade||'.ferias_evento
							 INNER JOIN folhapagamento'||stEntidade||'.evento
								 ON evento.cod_evento = ferias_evento.cod_evento
							      WHERE cod_tipo = 2
								AND timestamp <= (SELECT * FROM ultimotimestampperiodomovimentacao('||inCodPeriodoMovimentacao||', '''||stEntidade||'''))
							   ORDER BY timestamp DESC LIMIT 1)			 
				     AND folhas.desdobramento = ''F''';
	    END IF;

	    IF indice = 5 THEN
	        stSql := stSql || ' WHERE folhas.codigo::integer = ANY(string_to_array((SELECT CASE WHEN configuracao.valor != '''' THEN configuracao.valor ELSE ''0'' END
										          FROM administracao.configuracao
										         WHERE cod_modulo = 8
											   AND exercicio = '''|| stExercicio ||'''
											   AND parametro = ''remuneracao_eventual''), '',''))';
	    END IF;

	    IF indice = 6 THEN
	        stSql := stSql || ' WHERE folhas.codigo IN (SELECT evento.codigo 
                                                        FROM folhapagamento'||stEntidade||'.tabela_irrf_evento 
                                                      INNER JOIN folhapagamento'||stEntidade||'.evento
                                                          ON evento.cod_evento = tabela_irrf_evento.cod_evento
                                                       WHERE cod_tipo IN (3,6) 
                                                         AND cod_tabela = 1 
                                                         AND timestamp = (SELECT timestamp 
                                                                    FROM folhapagamento'||stEntidade||'.tabela_irrf 
                                                                   WHERE cod_tabela = 1 
                                                                     AND vigencia <= ultimotimestampperiodomovimentacao('||inCodPeriodoMovimentacao||', '''||stEntidade||''')
                                                                ORDER BY timestamp DESC LIMIT 1))
                                              
                                AND folhas.desdobramento IN ('''', ''S'')';
	    END IF;

	    IF indice = 7 THEN
	        stSql := stSql || ' WHERE folhas.codigo IN (SELECT codigo 
                                                        FROM folhapagamento'||stEntidade||'.previdencia_evento 
                                                      INNER JOIN folhapagamento'||stEntidade||'.evento
                                                              ON evento.cod_evento = previdencia_evento.cod_evento
                                                           WHERE cod_tipo = 1
                                                                               
                                         AND cod_previdencia = (SELECT cod_previdencia 
                                                                  FROM ultimo_contrato_servidor_previdencia('''||stEntidade||''', '||inCodPeriodoMovimentacao||') 
                                                                 WHERE cod_contrato = folhas.cod_contrato
                                                                   AND bo_excluido = false) 
                                                   
                                        AND timestamp = (SELECT timestamp
                                                       FROM folhapagamento'||stEntidade||'.previdencia_previdencia
                                                      WHERE vigencia <= ultimotimestampperiodomovimentacao('||inCodPeriodoMovimentacao||', '''||stEntidade||''')
                                                        AND cod_previdencia = previdencia_evento.cod_previdencia
                                                   ORDER BY timestamp DESC LIMIT 1))
                                 
			  AND folhas.desdobramento IN ('''', ''S'')';	    
	    END IF;

	    IF indice = 8 THEN
	       stSql := stSql || ' WHERE folhas.codigo::integer = ANY(string_to_array((SELECT CASE WHEN configuracao.valor != ''''   
                                                                                              THEN configuracao.valor
                                                                                              ELSE ''0'' 
                                                                                              END
                                                                                         FROM administracao.configuracao
                                                                                        WHERE cod_modulo = 8
                                                                                          AND exercicio = '''||stExercicio||'''
                                                                                          AND parametro = ''demais_deducoes''), '','')) ';
	    END IF;

	    IF indice = 9 THEN
	       stSql := stSql || ' WHERE folhas.codigo IN (SELECT codigo
                                                             FROM folhapagamento'||stEntidade||'.salario_familia
                                                             
                                                       INNER JOIN folhapagamento'||stEntidade||'.salario_familia_evento  
                                                               ON salario_familia_evento.cod_regime_previdencia = salario_familia.cod_regime_previdencia     
                                                              AND salario_familia_evento.timestamp              = salario_familia.timestamp                              
                                                              AND salario_familia_evento.cod_tipo               = 1
                                                              AND salario_familia.cod_regime_previdencia        = (SELECT cod_regime_previdencia 
                                                                                                                     FROM folhapagamento'||stEntidade||'.previdencia 
                                                                                                                    WHERE cod_previdencia = (SELECT cod_previdencia 
                                                                                                                                               FROM ultimo_contrato_servidor_previdencia('''||stEntidade||''', '||inCodPeriodoMovimentacao||') 
                                                                                                                                              WHERE cod_contrato = folhas.cod_contrato
                                                                                                                                                AND bo_excluido = false))
                                                       INNER JOIN folhapagamento'||stEntidade||'.evento
                                                               ON evento.cod_evento = salario_familia_evento.cod_evento
                                                            WHERE salario_familia.vigencia <= ultimotimestampperiodomovimentacao('||inCodPeriodoMovimentacao||', '''||stEntidade||''')
                                                         ORDER BY salario_familia.timestamp DESC LIMIT 1)';	    
	    END IF;

	    IF indice = 10 THEN
	       stSql := stSql || ' WHERE folhas.codigo::integer = ANY(string_to_array((SELECT CASE WHEN configuracao.valor != ''''   
                                                                                              THEN configuracao.valor
                                                                                              ELSE ''0'' 
                                                                                              END
                                                                                         FROM administracao.configuracao
                                                                                        WHERE cod_modulo = 8
                                                                                          AND exercicio = '''||stExercicio||'''
                                                                                          AND parametro = ''pagamento_jetons''), '','')) ';  
	    END IF;

	    IF indice = 11 THEN
	       stSql := stSql || ' WHERE folhas.codigo::integer = ANY(string_to_array((SELECT CASE WHEN configuracao.valor != ''''   
                                                                                              THEN configuracao.valor
                                                                                              ELSE ''0'' 
                                                                                              END
                                                                                         FROM administracao.configuracao
                                                                                        WHERE cod_modulo = 8
                                                                                          AND exercicio = '''||stExercicio||'''
                                                                                          AND parametro = ''verbas_indenizatorias''), '','')) ';  
	    END IF;

	    stSql := stSql || ' GROUP BY registro';
        
	    FOR reRegistro IN EXECUTE stSql LOOP
	        stSqlUpdate := 'UPDATE temp_transparencia_remuneracao SET '||arTipo[indice]||' = '||quote_literal(reRegistro.valor_calculado)||' WHERE registro = '||reRegistro.registro;
	        EXECUTE stSqlUpdate;
	    END LOOP;
        
        END LOOP;         

    stSql := 'SELECT *, ((coalesce(remuneracao_bruta::float, 0) +
                           coalesce(remuneracao_natalina::float, 0) +
                           coalesce(remuneracao_ferias::float, 0) + 
                           coalesce(remuneracao_outras::float, 0)) -
                          (coalesce(redutor_teto::float, 0) + coalesce(deducoes_irrf::float, 0) + coalesce(deducoes_obrigatorias::float, 0) + coalesce(demais_deducoes::float, 0))
                        ) as remuneracao_apos_deducoes
                FROM temp_transparencia_remuneracao';

    FOR reRegistro IN EXECUTE stSql
    LOOP
	RETURN NEXT reRegistro;
    END LOOP;
       
    RETURN;
    
END;
$_$;


ALTER FUNCTION public.fn_transparencia_remuneracao(character varying, integer, character varying, integer) OWNER TO urbem;

--
-- Name: pedeprasai(integer); Type: FUNCTION; Schema: public; Owner: urbem
--

CREATE FUNCTION pedeprasai(intpid integer) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
   DECLARE
      varRetorno  VARCHAR;
      bolOk       BOOLEAN;
   BEGIN
      PERFORM 1
         FROM ( SELECT pg_stat_get_backend_idset()  AS backendid)             AS backend_idset
        WHERE pg_stat_get_backend_pid(backend_idset.backendid) = intPid
      ;

      IF FOUND THEN
         SELECT INTO bolOk pg_cancel_backend(intPid);
         varRetorno := CASE WHEN bolOk THEN ' -- Processo Saiu -- ' ELSE  ' -- Processo Não Saiu -- ' END;
      ELSE
         varRetorno := ' -- Processo inexistente -- ';
      END IF;


      RETURN varRetorno;
   END;
$$;


ALTER FUNCTION public.pedeprasai(intpid integer) OWNER TO urbem;

--
-- Name: process(); Type: FUNCTION; Schema: public; Owner: urbem
--

CREATE FUNCTION process() RETURNS SETOF process
    LANGUAGE plpgsql
    AS $$
   DECLARE
      recProcess RECORD;
      typProcess process%ROWTYPE;
   BEGIN

      FOR recProcess IN
          SELECT pg_database.datname                                             AS base
               , pg_authid.rolname                                               AS usuario
               , pg_stat_get_backend_pid(backend_idset.backendid)                AS processo
               , pg_stat_get_backend_activity_start(backend_idset.backendid)     AS inicio
               , pg_stat_get_backend_activity(backend_idset.backendid)           AS consulta
            FROM pg_database
               , ( SELECT pg_stat_get_backend_idset()  AS backendid)             AS backend_idset
               , pg_authid
           WHERE pg_stat_get_backend_dbid(backend_idset.backendid)   = pg_database.oid
             AND pg_stat_get_backend_userid(backend_idset.backendid) = pg_authid.oid
           ORDER BY  3

      LOOP

         typProcess.base      := recProcess.base    ;
         typProcess.usuario   := recProcess.usuario ;
         typProcess.processo  := recProcess.processo;
         typProcess.inicio    := recProcess.inicio  ;
         typProcess.consulta  := recProcess.consulta;

         RETURN NEXT typProcess;
      END LOOP;

      RETURN ;
   END;
$$;


ALTER FUNCTION public.process() OWNER TO urbem;

--
-- Name: publicacao_id_seq; Type: SEQUENCE; Schema: public; Owner: urbem
--

CREATE SEQUENCE publicacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE publicacao_id_seq OWNER TO urbem;

SET search_path = publicacao, pg_catalog;

--
-- Name: publicacao_id_seq; Type: SEQUENCE; Schema: publicacao; Owner: urbem
--

CREATE SEQUENCE publicacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE publicacao_id_seq OWNER TO urbem;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: publicacao; Type: TABLE; Schema: publicacao; Owner: urbem
--

CREATE TABLE publicacao (
    id integer DEFAULT nextval('publicacao_id_seq'::regclass) NOT NULL,
    usuario character varying(150) NOT NULL,
    secao_id integer NOT NULL,
    descricao character varying(150) NOT NULL,
    detalhamento text,
    status character varying(2) NOT NULL,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone,
    arquivo character varying(150) NOT NULL
);


ALTER TABLE publicacao OWNER TO urbem;

--
-- Name: secao_id_seq; Type: SEQUENCE; Schema: publicacao; Owner: urbem
--

CREATE SEQUENCE secao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE secao_id_seq OWNER TO urbem;

SET default_with_oids = true;

--
-- Name: secao; Type: TABLE; Schema: publicacao; Owner: urbem
--

CREATE TABLE secao (
    id integer DEFAULT nextval('secao_id_seq'::regclass) NOT NULL,
    type character varying(30) NOT NULL,
    alias character varying(30) NOT NULL,
    secao character varying(100) NOT NULL,
    parent_id integer,
    created timestamp without time zone NOT NULL,
    updated timestamp without time zone DEFAULT now()
);


ALTER TABLE secao OWNER TO urbem;

SET search_path = transparencia, pg_catalog;

--
-- Name: acao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE acao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE acao_id_seq OWNER TO urbem;

--
-- Name: acao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE acao (
    id integer DEFAULT nextval('acao_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio integer NOT NULL,
    cod_projeto integer NOT NULL,
    nome_projeto character varying(80) NOT NULL
);


ALTER TABLE acao OWNER TO urbem;

--
-- Name: balancete_despesa_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE balancete_despesa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE balancete_despesa_id_seq OWNER TO urbem;

--
-- Name: balancete_despesa; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE balancete_despesa (
    id integer DEFAULT nextval('balancete_despesa_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer,
    cod_orgao integer,
    cod_unidade integer,
    cod_funcao integer,
    cod_subfuncao integer,
    cod_programa integer,
    cod_projeto integer,
    cod_elemento bigint,
    cod_recurso integer,
    dotacao_inicial numeric(14,2),
    atualizacao_monetaria numeric(14,2),
    creditos_suplementares numeric(14,2),
    creditos_especiais numeric(14,2),
    creditos_extraordinarios numeric(14,2),
    reducao_dotacoes numeric(14,2),
    suplementacao_recurso numeric(14,2),
    reducao_recurso numeric(14,2),
    valor_empenhado numeric(14,2),
    valor_liquidado numeric(14,2),
    valor_pago numeric(14,2)
);


ALTER TABLE balancete_despesa OWNER TO urbem;

--
-- Name: balancete_receita_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE balancete_receita_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE balancete_receita_id_seq OWNER TO urbem;

--
-- Name: balancete_receita; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE balancete_receita (
    id integer DEFAULT nextval('balancete_receita_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer,
    cod_conta bigint,
    cod_orgao_unidade integer,
    receita_orcada numeric(14,2),
    receita_janeiro numeric(14,2),
    receita_fevereiro numeric(14,2),
    receita_marco numeric(14,2),
    receita_abril numeric(14,2),
    receita_maio numeric(14,2),
    receita_junho numeric(14,2),
    receita_julho numeric(14,2),
    receita_agosto numeric(14,2),
    receita_setembro numeric(14,2),
    receita_outubro numeric(14,2),
    receita_novembro numeric(14,2),
    receita_dezembro numeric(14,2),
    especificacao_conta character varying(170),
    tipo_nivel character(1),
    numero_nivel character varying(2),
    cod_recurso integer
);


ALTER TABLE balancete_receita OWNER TO urbem;

--
-- Name: cargo_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE cargo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cargo_id_seq OWNER TO urbem;

--
-- Name: cargo; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE cargo (
    id integer DEFAULT nextval('cargo_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer NOT NULL,
    mes_ano character varying(7) NOT NULL,
    codigo integer NOT NULL,
    descricao_cargo character varying(60) NOT NULL,
    tipo_cargo character varying(20) NOT NULL,
    lei character varying(10) NOT NULL,
    descricao_padrao character varying(60) NOT NULL,
    carga_horaria_mensal numeric(14,2) NOT NULL,
    carga_horaria_semanal numeric(14,2) NOT NULL,
    valor numeric(14,2) NOT NULL,
    vigencia date,
    regime_subdivisao character varying(80) NOT NULL,
    vagas_criadas integer NOT NULL,
    vagas_ocupadas integer NOT NULL,
    vagas_disponiveis integer NOT NULL
);


ALTER TABLE cargo OWNER TO urbem;

--
-- Name: cedidoadido_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE cedidoadido_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE cedidoadido_id_seq OWNER TO urbem;

--
-- Name: cedidoadido; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE cedidoadido (
    id integer DEFAULT nextval('cedidoadido_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer NOT NULL,
    mes_ano character varying(7) NOT NULL,
    matricula integer NOT NULL,
    nom_cgm character varying(60) NOT NULL,
    situacao character varying(40) NOT NULL,
    ato_cedencia character varying(10) NOT NULL,
    dt_inicial date NOT NULL,
    dt_final date,
    tipo_cedencia character varying(10) NOT NULL,
    indicativo_onus character varying(20) NOT NULL,
    orgao_cedente_cessionario character varying(60) NOT NULL,
    num_convenio character varying(15) NOT NULL,
    local character varying(60) NOT NULL
);


ALTER TABLE cedidoadido OWNER TO urbem;

--
-- Name: compra_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE compra_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE compra_id_seq OWNER TO urbem;

--
-- Name: compra; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE compra (
    id integer DEFAULT nextval('compra_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio_entidade integer NOT NULL,
    cod_entidade integer NOT NULL,
    cod_compra_direta integer NOT NULL,
    modalidade character varying(50) NOT NULL,
    exercicio_empenho integer NOT NULL,
    cod_empenho integer NOT NULL,
    descricao_tipo_licitacao character varying(15) NOT NULL,
    descricao_tipo_objeto character varying(50) NOT NULL,
    descricao_objeto character varying(500) NOT NULL
);


ALTER TABLE compra OWNER TO urbem;

--
-- Name: configuracao_entidade_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE configuracao_entidade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE configuracao_entidade_id_seq OWNER TO urbem;

SET default_with_oids = false;

--
-- Name: configuracao_entidade; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE configuracao_entidade (
    id integer DEFAULT nextval('configuracao_entidade_id_seq'::regclass) NOT NULL,
    entidade_id integer NOT NULL
);


ALTER TABLE configuracao_entidade OWNER TO urbem;

--
-- Name: credor_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE credor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE credor_id_seq OWNER TO urbem;

SET default_with_oids = true;

--
-- Name: credor; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE credor (
    id integer DEFAULT nextval('credor_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_credor integer NOT NULL,
    nome_credor character varying(60) NOT NULL,
    cnpj_cpf_credor character varying(14)
);


ALTER TABLE credor OWNER TO urbem;

--
-- Name: empenho_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE empenho_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empenho_id_seq OWNER TO urbem;

--
-- Name: empenho; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE empenho (
    id integer DEFAULT nextval('empenho_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer NOT NULL,
    cod_orgao integer NOT NULL,
    cod_unidade integer NOT NULL,
    cod_funcao integer NOT NULL,
    cod_subfuncao integer NOT NULL,
    cod_programa integer NOT NULL,
    cod_subprograma integer NOT NULL,
    cod_projeto integer NOT NULL,
    cod_rubrica bigint NOT NULL,
    cod_recurso integer NOT NULL,
    contrapartida_recurso integer NOT NULL,
    numero_empenho bigint NOT NULL,
    data_empenho date NOT NULL,
    valor_empenho numeric(14,2) NOT NULL,
    sinal_valor character(1) NOT NULL,
    cod_credor integer NOT NULL,
    historico_empenho character varying(165) NOT NULL,
    modalidade_licitacao character varying(30) NOT NULL,
    numero_licitacao character varying(10) NOT NULL,
    ano_licitacao integer NOT NULL
);


ALTER TABLE empenho OWNER TO urbem;

--
-- Name: entidade_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE entidade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE entidade_id_seq OWNER TO urbem;

--
-- Name: entidade; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE entidade (
    id integer DEFAULT nextval('entidade_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer NOT NULL,
    nome_entidade character varying(160) NOT NULL
);


ALTER TABLE entidade OWNER TO urbem;

--
-- Name: estagiario_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE estagiario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE estagiario_id_seq OWNER TO urbem;

--
-- Name: estagiario; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE estagiario (
    id integer DEFAULT nextval('estagiario_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer NOT NULL,
    mes_ano character varying(7) NOT NULL,
    numero_estagio integer NOT NULL,
    nome character varying(60) NOT NULL,
    data_inicio date NOT NULL,
    data_fim date,
    data_renovacao date,
    descricao_lotacao character varying(60) NOT NULL,
    descricao_local character varying(60) NOT NULL
);


ALTER TABLE estagiario OWNER TO urbem;

--
-- Name: funcao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE funcao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE funcao_id_seq OWNER TO urbem;

--
-- Name: funcao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE funcao (
    id integer DEFAULT nextval('funcao_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio integer NOT NULL,
    cod_funcao integer NOT NULL,
    nome_funcao character varying(80) NOT NULL
);


ALTER TABLE funcao OWNER TO urbem;

--
-- Name: importacao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE importacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE importacao_id_seq OWNER TO urbem;

--
-- Name: importacao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE importacao (
    id integer DEFAULT nextval('importacao_id_seq'::regclass) NOT NULL,
    "timestamp" timestamp without time zone DEFAULT ('now'::text)::timestamp(3) with time zone NOT NULL,
    exercicio integer NOT NULL,
    timestamp_geracao timestamp without time zone NOT NULL,
    usuario character varying(15) NOT NULL,
    data_limite_dado date
);


ALTER TABLE importacao OWNER TO urbem;

--
-- Name: item_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE item_id_seq OWNER TO urbem;

--
-- Name: item; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE item (
    id integer DEFAULT nextval('item_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    numero_empenho bigint NOT NULL,
    cod_entidade integer NOT NULL,
    exercicio integer NOT NULL,
    data date NOT NULL,
    numero_item integer NOT NULL,
    descricao character varying(160) NOT NULL,
    unidade character varying(80) NOT NULL,
    quantidade numeric(14,2) NOT NULL,
    valor numeric(14,2) NOT NULL,
    sinal_valor character(1) NOT NULL,
    complemento text NOT NULL
);


ALTER TABLE item OWNER TO urbem;

--
-- Name: licitacao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE licitacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE licitacao_id_seq OWNER TO urbem;

--
-- Name: licitacao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE licitacao (
    id integer DEFAULT nextval('licitacao_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio_entidade integer NOT NULL,
    cod_entidade integer NOT NULL,
    cod_licitacao integer NOT NULL,
    modalidade character varying(50) NOT NULL,
    exercicio_empenho integer NOT NULL,
    cod_empenho integer NOT NULL,
    descricao_tipo_licitacao character varying(15) NOT NULL,
    descricao_tipo_objeto character varying(50) NOT NULL,
    descricao_objeto character varying(500) NOT NULL
);


ALTER TABLE licitacao OWNER TO urbem;

--
-- Name: liquidacao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE liquidacao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE liquidacao_id_seq OWNER TO urbem;

--
-- Name: liquidacao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE liquidacao (
    id integer DEFAULT nextval('liquidacao_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_empenho bigint NOT NULL,
    cod_entidade integer NOT NULL,
    cod_liquidacao integer NOT NULL,
    data_liquidacao date NOT NULL,
    valor_liquidacao numeric(14,2) NOT NULL,
    sinal_valor character(1) NOT NULL,
    historico_liquidacao character varying(165) NOT NULL
);


ALTER TABLE liquidacao OWNER TO urbem;

--
-- Name: orgao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE orgao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE orgao_id_seq OWNER TO urbem;

--
-- Name: orgao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE orgao (
    id integer DEFAULT nextval('orgao_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio integer NOT NULL,
    cod_orgao integer NOT NULL,
    nome_orgao character varying(80) NOT NULL
);


ALTER TABLE orgao OWNER TO urbem;

--
-- Name: pagamento_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE pagamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pagamento_id_seq OWNER TO urbem;

--
-- Name: pagamento; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE pagamento (
    id integer DEFAULT nextval('pagamento_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_empenho bigint NOT NULL,
    cod_entidade integer NOT NULL,
    numero_pagamento integer NOT NULL,
    data_pagamento date NOT NULL,
    valor_pagamento numeric(14,2) NOT NULL,
    sinal_valor character(1) NOT NULL,
    historico_pagamento character varying(165) NOT NULL
);


ALTER TABLE pagamento OWNER TO urbem;

--
-- Name: programa_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE programa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE programa_id_seq OWNER TO urbem;

--
-- Name: programa; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE programa (
    id integer DEFAULT nextval('programa_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio integer NOT NULL,
    cod_programa integer NOT NULL,
    nome_programa character varying(80) NOT NULL
);


ALTER TABLE programa OWNER TO urbem;

--
-- Name: publicacao_edital_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE publicacao_edital_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE publicacao_edital_id_seq OWNER TO urbem;

--
-- Name: publicacao_edital; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE publicacao_edital (
    id integer DEFAULT nextval('publicacao_edital_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio_edital integer NOT NULL,
    num_edital integer NOT NULL,
    exercicio_licitacao integer NOT NULL,
    cod_licitacao integer NOT NULL,
    cod_entidade integer NOT NULL,
    modalidade character varying(50) NOT NULL,
    veiculo_publicacao character varying(80) NOT NULL,
    data_publicacao date NOT NULL,
    observacao character varying(50) NOT NULL
);


ALTER TABLE publicacao_edital OWNER TO urbem;

--
-- Name: recurso_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE recurso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE recurso_id_seq OWNER TO urbem;

--
-- Name: recurso; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE recurso (
    id integer DEFAULT nextval('recurso_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_recurso integer NOT NULL,
    nome_recurso character varying(80) NOT NULL
);


ALTER TABLE recurso OWNER TO urbem;

--
-- Name: remuneracao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE remuneracao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE remuneracao_id_seq OWNER TO urbem;

--
-- Name: remuneracao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE remuneracao (
    id integer DEFAULT nextval('remuneracao_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer NOT NULL,
    mes_ano character varying(7) NOT NULL,
    matricula character varying(8) NOT NULL,
    nome character varying(60) NOT NULL,
    remuneracao_bruta numeric(14,2) NOT NULL,
    remuneracao_teto numeric(14,2) NOT NULL,
    remuneracao_eventual_natalina numeric(14,2) NOT NULL,
    remuneracao_eventual_ferias numeric(14,2) NOT NULL,
    remuneracao_eventual_outras numeric(14,2) NOT NULL,
    deducoes_obrigatorias_irrf numeric(14,2) NOT NULL,
    deducoes_obrigatorias_prev numeric(14,2) NOT NULL,
    demais_deducoes numeric(14,2) NOT NULL,
    remuneracao_apos_deducoes numeric(14,2) NOT NULL,
    verbas_salario_familia numeric(14,2) NOT NULL,
    verbas_jetons numeric(14,2) NOT NULL,
    demais_verbas numeric(14,2) NOT NULL
);


ALTER TABLE remuneracao OWNER TO urbem;

--
-- Name: rubrica_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE rubrica_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE rubrica_id_seq OWNER TO urbem;

--
-- Name: rubrica; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE rubrica (
    id integer DEFAULT nextval('rubrica_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio integer NOT NULL,
    cod_rubrica_despesa bigint NOT NULL,
    especificacao_rubrica_despesa character varying(110) NOT NULL,
    tipo_nivel_conta character(1) NOT NULL,
    numero_nivel_conta integer NOT NULL
);


ALTER TABLE rubrica OWNER TO urbem;

--
-- Name: servidor_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE servidor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE servidor_id_seq OWNER TO urbem;

--
-- Name: servidor; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE servidor (
    id integer DEFAULT nextval('servidor_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    cod_entidade integer NOT NULL,
    mes_ano character varying(7) NOT NULL,
    matricula character varying(8) NOT NULL,
    nome character varying(60) NOT NULL,
    situacao character varying(40) NOT NULL,
    dt_admissao date NOT NULL,
    ato_nomeacao character varying(10) NOT NULL,
    dt_rescisao date,
    descricao_causa_rescisao character varying(60) NOT NULL,
    descricao_regime_funcao character varying(3) NOT NULL,
    descricao_regime_subdivisao_funcao character varying(40) NOT NULL,
    descricao_funcao character varying(60) NOT NULL,
    descricao_especialidade_funcao character varying(60) NOT NULL,
    descricao_padrao character varying(60) NOT NULL,
    horas_mensais numeric(14,2) NOT NULL,
    lotacao character varying(20) NOT NULL,
    descricao_lotacao character varying(60) NOT NULL,
    descricao_local character varying(60) NOT NULL
);


ALTER TABLE servidor OWNER TO urbem;

--
-- Name: subfuncao_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE subfuncao_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE subfuncao_id_seq OWNER TO urbem;

--
-- Name: subfuncao; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE subfuncao (
    id integer DEFAULT nextval('subfuncao_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio integer NOT NULL,
    cod_subfuncao integer NOT NULL,
    nome_subfuncao character varying(80) NOT NULL
);


ALTER TABLE subfuncao OWNER TO urbem;

--
-- Name: unidade_id_seq; Type: SEQUENCE; Schema: transparencia; Owner: urbem
--

CREATE SEQUENCE unidade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE unidade_id_seq OWNER TO urbem;

--
-- Name: unidade; Type: TABLE; Schema: transparencia; Owner: urbem
--

CREATE TABLE unidade (
    id integer DEFAULT nextval('unidade_id_seq'::regclass) NOT NULL,
    importacao_id integer NOT NULL,
    exercicio integer NOT NULL,
    cod_orgao integer NOT NULL,
    cod_unidade integer NOT NULL,
    nome_unidade character varying(80) NOT NULL
);


ALTER TABLE unidade OWNER TO urbem;

SET search_path = publicacao, pg_catalog;

--
-- Name: pk_publicacao_id; Type: CONSTRAINT; Schema: publicacao; Owner: urbem
--

ALTER TABLE ONLY publicacao
    ADD CONSTRAINT pk_publicacao_id PRIMARY KEY (id);


--
-- Name: pk_secao_id; Type: CONSTRAINT; Schema: publicacao; Owner: urbem
--

ALTER TABLE ONLY secao
    ADD CONSTRAINT pk_secao_id PRIMARY KEY (id);


SET search_path = transparencia, pg_catalog;

--
-- Name: pk_acao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY acao
    ADD CONSTRAINT pk_acao PRIMARY KEY (id);


--
-- Name: pk_balancete_despesa; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY balancete_despesa
    ADD CONSTRAINT pk_balancete_despesa PRIMARY KEY (id);


--
-- Name: pk_balancete_receita; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY balancete_receita
    ADD CONSTRAINT pk_balancete_receita PRIMARY KEY (id);


--
-- Name: pk_cargo; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY cargo
    ADD CONSTRAINT pk_cargo PRIMARY KEY (id);


--
-- Name: pk_cedidoadido; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY cedidoadido
    ADD CONSTRAINT pk_cedidoadido PRIMARY KEY (id);


--
-- Name: pk_compra; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY compra
    ADD CONSTRAINT pk_compra PRIMARY KEY (id);


--
-- Name: pk_configuracao_entidade_id; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY configuracao_entidade
    ADD CONSTRAINT pk_configuracao_entidade_id PRIMARY KEY (id);


--
-- Name: pk_credor; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY credor
    ADD CONSTRAINT pk_credor PRIMARY KEY (id);


--
-- Name: pk_empenho; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY empenho
    ADD CONSTRAINT pk_empenho PRIMARY KEY (id);


--
-- Name: pk_entidade; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY entidade
    ADD CONSTRAINT pk_entidade PRIMARY KEY (id);


--
-- Name: pk_estagiario; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY estagiario
    ADD CONSTRAINT pk_estagiario PRIMARY KEY (id);


--
-- Name: pk_funcao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY funcao
    ADD CONSTRAINT pk_funcao PRIMARY KEY (id);


--
-- Name: pk_importacao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY importacao
    ADD CONSTRAINT pk_importacao PRIMARY KEY (id);


--
-- Name: pk_item; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY item
    ADD CONSTRAINT pk_item PRIMARY KEY (id);


--
-- Name: pk_licitacao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY licitacao
    ADD CONSTRAINT pk_licitacao PRIMARY KEY (id);


--
-- Name: pk_liquidacao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY liquidacao
    ADD CONSTRAINT pk_liquidacao PRIMARY KEY (id);


--
-- Name: pk_orgao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY orgao
    ADD CONSTRAINT pk_orgao PRIMARY KEY (id);


--
-- Name: pk_pagamento; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY pagamento
    ADD CONSTRAINT pk_pagamento PRIMARY KEY (id);


--
-- Name: pk_programa; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY programa
    ADD CONSTRAINT pk_programa PRIMARY KEY (id);


--
-- Name: pk_publicacao_edital; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY publicacao_edital
    ADD CONSTRAINT pk_publicacao_edital PRIMARY KEY (id);


--
-- Name: pk_recurso; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY recurso
    ADD CONSTRAINT pk_recurso PRIMARY KEY (id);


--
-- Name: pk_remuneracao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY remuneracao
    ADD CONSTRAINT pk_remuneracao PRIMARY KEY (id);


--
-- Name: pk_rubrica; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY rubrica
    ADD CONSTRAINT pk_rubrica PRIMARY KEY (id);


--
-- Name: pk_servidor; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY servidor
    ADD CONSTRAINT pk_servidor PRIMARY KEY (id);


--
-- Name: pk_subfuncao; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY subfuncao
    ADD CONSTRAINT pk_subfuncao PRIMARY KEY (id);


--
-- Name: pk_unidade; Type: CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY unidade
    ADD CONSTRAINT pk_unidade PRIMARY KEY (id);


SET search_path = publicacao, pg_catalog;

--
-- Name: fki_publicacao_secao_id; Type: INDEX; Schema: publicacao; Owner: urbem
--

CREATE INDEX fki_publicacao_secao_id ON publicacao USING btree (secao_id);


SET search_path = transparencia, pg_catalog;

--
-- Name: index_balance_despesa_cod_funcao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balance_despesa_cod_funcao ON balancete_despesa USING btree (cod_funcao);


--
-- Name: index_balancete_despesa_cod_elemento; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_elemento ON balancete_despesa USING btree (cod_elemento);


--
-- Name: index_balancete_despesa_cod_entidade; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_entidade ON balancete_despesa USING btree (cod_entidade);


--
-- Name: index_balancete_despesa_cod_orgao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_orgao ON balancete_despesa USING btree (cod_orgao);


--
-- Name: index_balancete_despesa_cod_programa; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_programa ON balancete_despesa USING btree (cod_programa);


--
-- Name: index_balancete_despesa_cod_projeto; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_projeto ON balancete_despesa USING btree (cod_projeto);


--
-- Name: index_balancete_despesa_cod_recurso; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_recurso ON balancete_despesa USING btree (cod_recurso);


--
-- Name: index_balancete_despesa_cod_subfuncao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_subfuncao ON balancete_despesa USING btree (cod_subfuncao);


--
-- Name: index_balancete_despesa_cod_unidade; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_balancete_despesa_cod_unidade ON balancete_despesa USING btree (cod_unidade);


--
-- Name: index_credor_cod_credor; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_credor_cod_credor ON credor USING btree (cod_credor);


--
-- Name: index_empenho_cod_credor; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_credor ON empenho USING btree (cod_credor);


--
-- Name: index_empenho_cod_funcao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_funcao ON empenho USING btree (cod_funcao);


--
-- Name: index_empenho_cod_orgao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_orgao ON empenho USING btree (cod_orgao);


--
-- Name: index_empenho_cod_programa; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_programa ON empenho USING btree (cod_programa);


--
-- Name: index_empenho_cod_projeto; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_projeto ON empenho USING btree (cod_projeto);


--
-- Name: index_empenho_cod_recurso; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_recurso ON empenho USING btree (cod_recurso);


--
-- Name: index_empenho_cod_rubrica; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_rubrica ON empenho USING btree (cod_rubrica);


--
-- Name: index_empenho_cod_subfuncao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_subfuncao ON empenho USING btree (cod_subfuncao);


--
-- Name: index_empenho_cod_unidade; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_cod_unidade ON empenho USING btree (cod_unidade);


--
-- Name: index_empenho_numero_empenho; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_empenho_numero_empenho ON empenho USING btree (numero_empenho);


--
-- Name: index_entidade_cod_entidade; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_entidade_cod_entidade ON entidade USING btree (cod_entidade);


--
-- Name: index_funcao_cod_funcao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_funcao_cod_funcao ON funcao USING btree (cod_funcao);


--
-- Name: index_funcao_cod_subfuncao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_funcao_cod_subfuncao ON subfuncao USING btree (cod_subfuncao);


--
-- Name: index_item_importacao_id; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_item_importacao_id ON item USING btree (importacao_id);


--
-- Name: index_item_numero_empenho; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_item_numero_empenho ON item USING btree (numero_empenho);


--
-- Name: index_liquidacao_cod_empenho; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_liquidacao_cod_empenho ON liquidacao USING btree (cod_empenho);


--
-- Name: index_orgao_cod_orgao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_orgao_cod_orgao ON orgao USING btree (cod_orgao);


--
-- Name: index_pagamento_cod_empenho; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_pagamento_cod_empenho ON pagamento USING btree (cod_empenho);


--
-- Name: index_programa_cod_programa; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_programa_cod_programa ON programa USING btree (cod_programa);


--
-- Name: index_recurso_cod_recurso; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_recurso_cod_recurso ON recurso USING btree (cod_recurso);


--
-- Name: index_rubrica_cod_rubrica_despesa; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_rubrica_cod_rubrica_despesa ON rubrica USING btree (cod_rubrica_despesa);


--
-- Name: index_unidade_cod_orgao; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_unidade_cod_orgao ON unidade USING btree (cod_orgao);


--
-- Name: index_unidade_cod_unidade; Type: INDEX; Schema: transparencia; Owner: urbem
--

CREATE INDEX index_unidade_cod_unidade ON unidade USING btree (cod_unidade);


SET search_path = publicacao, pg_catalog;

--
-- Name: fk_publicacao_secao_id; Type: FK CONSTRAINT; Schema: publicacao; Owner: urbem
--

ALTER TABLE ONLY publicacao
    ADD CONSTRAINT fk_publicacao_secao_id FOREIGN KEY (secao_id) REFERENCES secao(id);


SET search_path = transparencia, pg_catalog;

--
-- Name: fk_acao_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY acao
    ADD CONSTRAINT fk_acao_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_balancete_despesa_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY balancete_despesa
    ADD CONSTRAINT fk_balancete_despesa_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_balancete_receita_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY balancete_receita
    ADD CONSTRAINT fk_balancete_receita_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_cargo_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY cargo
    ADD CONSTRAINT fk_cargo_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_cedidoadido_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY cedidoadido
    ADD CONSTRAINT fk_cedidoadido_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_compra_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY compra
    ADD CONSTRAINT fk_compra_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_credor_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY credor
    ADD CONSTRAINT fk_credor_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_empenho_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY empenho
    ADD CONSTRAINT fk_empenho_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_entidade_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY entidade
    ADD CONSTRAINT fk_entidade_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_estagiario_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY estagiario
    ADD CONSTRAINT fk_estagiario_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_funcao_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY funcao
    ADD CONSTRAINT fk_funcao_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_item_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY item
    ADD CONSTRAINT fk_item_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_licitacao_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY licitacao
    ADD CONSTRAINT fk_licitacao_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_liquidacao_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY liquidacao
    ADD CONSTRAINT fk_liquidacao_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_orgao_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY orgao
    ADD CONSTRAINT fk_orgao_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_pagamento_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY pagamento
    ADD CONSTRAINT fk_pagamento_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_programa_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY programa
    ADD CONSTRAINT fk_programa_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_publicacao_edital_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY publicacao_edital
    ADD CONSTRAINT fk_publicacao_edital_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_recurso_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY recurso
    ADD CONSTRAINT fk_recurso_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_remuneracao_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY remuneracao
    ADD CONSTRAINT fk_remuneracao_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_rubrica_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY rubrica
    ADD CONSTRAINT fk_rubrica_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_servidor_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY servidor
    ADD CONSTRAINT fk_servidor_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_subfuncao_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY subfuncao
    ADD CONSTRAINT fk_subfuncao_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: fk_unidade_1; Type: FK CONSTRAINT; Schema: transparencia; Owner: urbem
--

ALTER TABLE ONLY unidade
    ADD CONSTRAINT fk_unidade_1 FOREIGN KEY (importacao_id) REFERENCES importacao(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: acao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE acao FROM PUBLIC;
REVOKE ALL ON TABLE acao FROM urbem;
GRANT ALL ON TABLE acao TO urbem;


--
-- Name: balancete_despesa; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE balancete_despesa FROM PUBLIC;
REVOKE ALL ON TABLE balancete_despesa FROM urbem;
GRANT ALL ON TABLE balancete_despesa TO urbem;


--
-- Name: balancete_receita; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE balancete_receita FROM PUBLIC;
REVOKE ALL ON TABLE balancete_receita FROM urbem;
GRANT ALL ON TABLE balancete_receita TO urbem;


--
-- Name: cargo; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE cargo FROM PUBLIC;
REVOKE ALL ON TABLE cargo FROM urbem;
GRANT ALL ON TABLE cargo TO urbem;


--
-- Name: cedidoadido; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE cedidoadido FROM PUBLIC;
REVOKE ALL ON TABLE cedidoadido FROM urbem;
GRANT ALL ON TABLE cedidoadido TO urbem;


--
-- Name: compra; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE compra FROM PUBLIC;
REVOKE ALL ON TABLE compra FROM urbem;
GRANT ALL ON TABLE compra TO urbem;


--
-- Name: credor; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE credor FROM PUBLIC;
REVOKE ALL ON TABLE credor FROM urbem;
GRANT ALL ON TABLE credor TO urbem;


--
-- Name: empenho; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE empenho FROM PUBLIC;
REVOKE ALL ON TABLE empenho FROM urbem;
GRANT ALL ON TABLE empenho TO urbem;


--
-- Name: entidade; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE entidade FROM PUBLIC;
REVOKE ALL ON TABLE entidade FROM urbem;
GRANT ALL ON TABLE entidade TO urbem;


--
-- Name: estagiario; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE estagiario FROM PUBLIC;
REVOKE ALL ON TABLE estagiario FROM urbem;
GRANT ALL ON TABLE estagiario TO urbem;


--
-- Name: funcao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE funcao FROM PUBLIC;
REVOKE ALL ON TABLE funcao FROM urbem;
GRANT ALL ON TABLE funcao TO urbem;


--
-- Name: importacao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE importacao FROM PUBLIC;
REVOKE ALL ON TABLE importacao FROM urbem;
GRANT ALL ON TABLE importacao TO urbem;


--
-- Name: licitacao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE licitacao FROM PUBLIC;
REVOKE ALL ON TABLE licitacao FROM urbem;
GRANT ALL ON TABLE licitacao TO urbem;


--
-- Name: liquidacao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE liquidacao FROM PUBLIC;
REVOKE ALL ON TABLE liquidacao FROM urbem;
GRANT ALL ON TABLE liquidacao TO urbem;


--
-- Name: orgao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE orgao FROM PUBLIC;
REVOKE ALL ON TABLE orgao FROM urbem;
GRANT ALL ON TABLE orgao TO urbem;


--
-- Name: pagamento; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE pagamento FROM PUBLIC;
REVOKE ALL ON TABLE pagamento FROM urbem;
GRANT ALL ON TABLE pagamento TO urbem;


--
-- Name: programa; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE programa FROM PUBLIC;
REVOKE ALL ON TABLE programa FROM urbem;
GRANT ALL ON TABLE programa TO urbem;


--
-- Name: publicacao_edital; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE publicacao_edital FROM PUBLIC;
REVOKE ALL ON TABLE publicacao_edital FROM urbem;
GRANT ALL ON TABLE publicacao_edital TO urbem;


--
-- Name: recurso; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE recurso FROM PUBLIC;
REVOKE ALL ON TABLE recurso FROM urbem;
GRANT ALL ON TABLE recurso TO urbem;


--
-- Name: remuneracao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE remuneracao FROM PUBLIC;
REVOKE ALL ON TABLE remuneracao FROM urbem;
GRANT ALL ON TABLE remuneracao TO urbem;


--
-- Name: rubrica; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE rubrica FROM PUBLIC;
REVOKE ALL ON TABLE rubrica FROM urbem;
GRANT ALL ON TABLE rubrica TO urbem;


--
-- Name: servidor; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE servidor FROM PUBLIC;
REVOKE ALL ON TABLE servidor FROM urbem;
GRANT ALL ON TABLE servidor TO urbem;


--
-- Name: subfuncao; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE subfuncao FROM PUBLIC;
REVOKE ALL ON TABLE subfuncao FROM urbem;
GRANT ALL ON TABLE subfuncao TO urbem;


--
-- Name: unidade; Type: ACL; Schema: transparencia; Owner: urbem
--

REVOKE ALL ON TABLE unidade FROM PUBLIC;
REVOKE ALL ON TABLE unidade FROM urbem;
GRANT ALL ON TABLE unidade TO urbem;


--
-- PostgreSQL database dump complete
--

