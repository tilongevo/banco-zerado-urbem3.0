-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: mysqlhost    Database: project_rede_simples
-- ------------------------------------------------------
-- Server version	5.7.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bbh_administrativo`
--

DROP TABLE IF EXISTS `bbh_administrativo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_administrativo` (
  `bbh_adm_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_adm_identificacao` varchar(255) DEFAULT NULL,
  `bbh_adm_nome` varchar(255) DEFAULT NULL,
  `bbh_adm_data_nascimento` date DEFAULT NULL,
  `bbh_adm_sexo` varchar(1) DEFAULT NULL,
  `bbh_adm_ultimoAcesso` datetime DEFAULT NULL,
  `bbh_adm_ativo` int(11) DEFAULT NULL,
  `bbh_adm_nivel` int(11) DEFAULT '484',
  PRIMARY KEY (`bbh_adm_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_administrativo`
--

LOCK TABLES `bbh_administrativo` WRITE;
/*!40000 ALTER TABLE `bbh_administrativo` DISABLE KEYS */;
INSERT INTO `bbh_administrativo` VALUES (1,'tecnica@longevo.com.br','Técnica','1975-06-23','0','2017-11-15 15:32:17',1,484);
/*!40000 ALTER TABLE `bbh_administrativo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_arquivo`
--

DROP TABLE IF EXISTS `bbh_arquivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_arquivo` (
  `bbh_arq_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_arq_localizacao` varchar(255) DEFAULT NULL,
  `bbh_arq_data_modificado` datetime DEFAULT NULL,
  `bbh_arq_versao` int(11) DEFAULT NULL,
  `bbh_usu_codigo` int(11) DEFAULT NULL,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  `bbh_arq_compartilhado` int(11) DEFAULT '0',
  `bbh_arq_nome` varchar(255) DEFAULT NULL,
  `bbh_arq_tipo` varchar(255) DEFAULT NULL,
  `bbh_arq_titulo` varchar(255) DEFAULT NULL,
  `bbh_arq_autor` varchar(180) DEFAULT NULL,
  `bbh_arq_descricao` text,
  `bbh_arq_nome_logico` varchar(255) DEFAULT NULL,
  `bbh_arq_mime` varchar(150) DEFAULT NULL,
  `bbh_arq_publico` char(1) DEFAULT '0',
  `bbh_arq_obs_publico` text,
  PRIMARY KEY (`bbh_arq_codigo`),
  KEY `bbh_arquivo_bbh_fluxo` (`bbh_flu_codigo`),
  KEY `bbh_usu_arquivo_bbh_usu_codigo` (`bbh_usu_codigo`),
  CONSTRAINT `bbh_arquivo_bbh_fluxo` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_arquivo_bbh_usu_codigo` FOREIGN KEY (`bbh_usu_codigo`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_arquivo`
--

LOCK TABLES `bbh_arquivo` WRITE;
/*!40000 ALTER TABLE `bbh_arquivo` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_arquivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_atividade`
--

DROP TABLE IF EXISTS `bbh_atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_atividade` (
  `bbh_ati_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_sta_ati_codigo` int(11) DEFAULT '1',
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  `bbh_mod_ati_codigo` int(11) DEFAULT NULL,
  `bbh_ati_observacao` text,
  `bbh_usu_codigo` int(11) DEFAULT NULL,
  `bbh_ati_inicio_previsto` date DEFAULT NULL,
  `bbh_ati_final_previsto` date DEFAULT NULL,
  `bbh_ati_inicio_real` date DEFAULT NULL,
  `bbh_ati_final_real` date DEFAULT NULL,
  `bbh_ati_andamento` text,
  `bbh_flu_alt_codigo` int(11) DEFAULT NULL,
  `bbh_alternativa_fluxo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_ati_codigo`),
  KEY `bbh_atividade_bbh_mod_atividade` (`bbh_mod_ati_codigo`),
  KEY `bbh_atividade_bbh_fluxo` (`bbh_flu_codigo`),
  KEY `bbh_atividade_bbh_status_atividade` (`bbh_sta_ati_codigo`),
  KEY `bbh_usu_codigo` (`bbh_usu_codigo`),
  KEY `bbh_flu_alt_codigo` (`bbh_flu_alt_codigo`),
  KEY `bbh_alternativa_fluxo` (`bbh_alternativa_fluxo`),
  CONSTRAINT `bbh_alternativa_fluxo` FOREIGN KEY (`bbh_alternativa_fluxo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_atividade_bbh_fluxo` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_atividade_bbh_mod_atividade` FOREIGN KEY (`bbh_mod_ati_codigo`) REFERENCES `bbh_modelo_atividade` (`bbh_mod_ati_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_atividade_bbh_status_atividade` FOREIGN KEY (`bbh_sta_ati_codigo`) REFERENCES `bbh_status_atividade` (`bbh_sta_ati_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_flu_alt_codigo` FOREIGN KEY (`bbh_flu_alt_codigo`) REFERENCES `bbh_fluxo_alternativa` (`bbh_flu_alt_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_codigo` FOREIGN KEY (`bbh_usu_codigo`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_atividade`
--

LOCK TABLES `bbh_atividade` WRITE;
/*!40000 ALTER TABLE `bbh_atividade` DISABLE KEYS */;
INSERT INTO `bbh_atividade` VALUES (49,2,29,27,NULL,3,'2017-05-31','2017-06-01','2017-05-30','2017-05-30','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'30/05/2017 17:26:33\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'30/05/2017 17:26:21\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(50,2,30,27,NULL,3,'2017-05-31','2017-06-01','2017-05-30','2017-05-30','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'30/05/2017 17:26:10\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'30/05/2017 17:24:35\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(52,2,31,28,NULL,5,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'3\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 09:39:28\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 09:39:08\' mensagem=\'Profissional ciente da atividade\'/><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 09:29:13\' mensagem=\'Bruno, inicia a atividade ae !\'/></andamento>',NULL,NULL),(53,2,31,29,NULL,6,'2017-06-01','2017-06-04','2017-05-31','2017-05-31','<andamento><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 09:50:34\' mensagem=\'Profissional ciente da atividade\'/></andamento>',26,32),(54,2,32,47,NULL,5,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 09:55:55\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 09:54:34\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(55,2,33,32,NULL,3,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'3\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:21:16\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:21:05\' mensagem=\'Profissional ciente da atividade\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 15:55:28\' mensagem=\'vai logo ow !\'/></andamento>',NULL,NULL),(56,2,33,34,NULL,7,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'7\' apelidoUsuario=\'afonso\' depUsuario=\'Divisão de Produtos Químicos e Inflamáveis\' momento=\'31/05/2017 16:23:09\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'7\' apelidoUsuario=\'afonso\' depUsuario=\'Divisão de Produtos Químicos e Inflamáveis\' momento=\'31/05/2017 16:22:45\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(57,2,33,31,NULL,8,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:20:01\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:18:24\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(58,2,33,33,NULL,5,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:22:07\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:21:53\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(60,2,34,37,NULL,5,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:40:42\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:39:24\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(61,2,34,38,NULL,8,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'5\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:47:45\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'4\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:41:56\' mensagem=\'Estou adicionando um comentario aqui\'/><comentario id=\'3\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:41:52\' mensagem=\'Estou adicionando um comentario aqui\'/><comentario id=\'2\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:41:10\' mensagem=\'Profissional ciente da atividade\'/><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:38:50\' mensagem=\'vaaaaai loogooo\'/></andamento>',NULL,NULL),(62,2,34,39,NULL,6,'2017-06-01','2017-06-04','2017-05-31','2017-05-31','<andamento><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:48:32\' mensagem=\'Profissional ciente da atividade\'/></andamento>',31,35),(63,2,35,41,NULL,4,'2017-06-01','2017-06-04','2017-05-31','2017-05-31','<andamento><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 16:54:31\' mensagem=\'Profissional ciente da atividade\'/></andamento>',30,36),(64,2,35,42,NULL,3,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'11\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 17:14:38\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'10\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 17:05:54\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'9\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 17:02:15\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'8\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:53:16\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'7\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:53:16\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'6\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:53:15\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'5\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:53:15\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'4\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:53:14\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'3\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:53:12\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:53:10\' mensagem=\'O profissional mudou o status para Ciente\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 16:52:45\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(65,2,36,52,NULL,4,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:08:54\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:07:53\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(67,2,37,37,NULL,5,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:16:21\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:16:16\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(68,2,37,38,NULL,8,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:16:59\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:16:51\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(69,2,37,39,NULL,6,'2017-06-01','2017-06-04','2017-05-31','2017-05-31','<andamento><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:17:16\' mensagem=\'Profissional ciente da atividade\'/></andamento>',31,38),(70,2,38,41,NULL,4,'2017-06-01','2017-06-04','2017-05-31','2017-05-31','<andamento><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:19:11\' mensagem=\'Profissional ciente da atividade\'/></andamento>',30,39),(72,2,39,52,NULL,4,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:20:34\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:20:21\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(74,2,40,37,NULL,5,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:28:16\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:28:13\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(75,2,40,38,NULL,8,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'3\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:28:39\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'2\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:28:37\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:28:33\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(76,2,40,39,NULL,6,'2017-06-01','2017-06-04','2017-05-31','2017-05-31','<andamento><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:28:58\' mensagem=\'Profissional ciente da atividade\'/></andamento>',31,41),(77,2,41,41,NULL,4,'2017-06-01','2017-06-02','2017-05-31','2017-05-31','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:29:44\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'31/05/2017 17:29:39\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(78,2,41,42,NULL,3,'2017-06-01','2017-06-04','2017-05-31','2017-06-01','<andamento><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'31/05/2017 17:30:20\' mensagem=\'Profissional ciente da atividade\'/></andamento>',32,42),(79,2,42,43,NULL,11,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'2\' idUsuario=\'11\' apelidoUsuario=\'Fabio\' depUsuario=\'Alta Administração\' momento=\'01/06/2017 09:28:24\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'11\' apelidoUsuario=\'Fabio\' depUsuario=\'Alta Administração\' momento=\'01/06/2017 09:25:09\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(80,2,43,27,NULL,3,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 10:13:17\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 10:13:02\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(81,2,44,27,NULL,3,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 11:16:02\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 11:15:47\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(82,2,45,27,NULL,3,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 11:17:39\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 11:17:27\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(83,2,46,27,NULL,3,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:58:41\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:58:27\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(84,2,47,27,NULL,3,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:59:03\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:58:52\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(85,2,48,32,NULL,3,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'4\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:59:39\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'3\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:59:27\' mensagem=\'Por mim está ok\'/><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:59:26\' mensagem=\'Por mim está ok\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'01/06/2017 13:59:10\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(87,2,48,31,NULL,8,'2017-06-02','2017-06-03','2017-06-01','2017-06-01','<andamento><comentario id=\'2\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'01/06/2017 13:58:03\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'01/06/2017 13:57:52\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(88,2,48,33,NULL,5,'2017-06-02','2017-06-05','2017-06-01','2017-06-05','<andamento><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'01/06/2017 14:00:10\' mensagem=\'Profissional ciente da atividade\'/></andamento>',24,50),(89,1,49,27,NULL,3,'2017-06-03','2017-06-04',NULL,NULL,'<andamento></andamento>',NULL,NULL),(90,2,50,49,NULL,5,'2017-06-06','2017-06-07','2017-06-05','2017-06-05','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'05/06/2017 11:14:54\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'05/06/2017 11:14:38\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(91,2,51,32,NULL,3,'2017-06-06','2017-06-07','2017-06-05','2017-06-05','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'05/06/2017 17:56:28\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'05/06/2017 17:56:18\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(93,2,51,31,NULL,8,'2017-06-06','2017-06-07','2017-06-05','2017-06-05','<andamento><comentario id=\'2\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'05/06/2017 17:55:51\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'8\' apelidoUsuario=\'braga\' depUsuario=\'Departamento de Comércio\' momento=\'05/06/2017 17:55:45\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(94,2,51,33,NULL,5,'2017-06-06','2017-06-09','2017-06-05','2017-06-07','<andamento><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'05/06/2017 17:57:15\' mensagem=\'Profissional ciente da atividade\'/></andamento>',24,53),(95,2,52,30,NULL,4,'2017-06-08','2017-06-09','2017-06-07','2017-06-07','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 15:17:32\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 10:59:07\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(96,2,52,28,NULL,5,'2017-06-08','2017-06-09','2017-06-07','2017-06-07','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 10:54:18\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 10:54:00\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(97,2,52,29,NULL,6,'2017-06-08','2017-06-09','2017-06-07','2017-06-07','<andamento><comentario id=\'2\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 10:56:35\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 10:55:48\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(98,2,53,49,NULL,5,'2017-06-08','2017-06-09','2017-06-07','2017-06-07','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 10:53:53\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'07/06/2017 10:53:41\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(99,2,54,27,NULL,3,'2017-06-08','2017-06-09','2017-06-07','2017-06-07','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'07/06/2017 15:52:47\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'07/06/2017 15:52:24\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(100,2,55,27,NULL,3,'2017-06-09','2017-06-10','2017-06-08','2017-06-08','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'08/06/2017 15:25:00\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'08/06/2017 15:23:39\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(101,2,56,30,NULL,4,'2017-06-13','2017-06-14','2017-06-12','2017-06-22','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 15:55:48\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'12/06/2017 11:06:33\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(102,2,56,28,NULL,5,'2017-06-13','2017-06-14','2017-06-12','2017-06-12','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'12/06/2017 11:05:24\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'12/06/2017 11:05:20\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(103,2,56,29,NULL,6,'2017-06-13','2017-06-14','2017-06-12','2017-06-12','<andamento><comentario id=\'2\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'12/06/2017 11:05:51\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'12/06/2017 11:05:46\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(104,2,57,30,NULL,4,'2017-06-14','2017-06-15','2017-06-13','2017-06-22','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 15:56:09\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'13/06/2017 15:36:44\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(105,2,57,28,NULL,5,'2017-06-14','2017-06-15','2017-06-13','2017-06-13','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'13/06/2017 15:35:59\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'13/06/2017 15:35:55\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(106,2,57,29,NULL,6,'2017-06-14','2017-06-15','2017-06-13','2017-06-13','<andamento><comentario id=\'2\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'13/06/2017 15:36:20\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'13/06/2017 15:36:15\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(107,2,58,30,NULL,4,'2017-06-23','2017-06-24','2017-06-22','2017-06-22','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 16:20:25\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 15:56:59\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(108,2,58,28,NULL,5,'2017-06-23','2017-06-24','2017-06-22','2017-06-22','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 14:45:20\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 11:40:08\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(109,2,58,29,NULL,6,'2017-06-23','2017-06-24','2017-06-22','2017-06-22','<andamento><comentario id=\'2\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 15:32:07\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 15:30:01\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(111,2,59,28,NULL,5,'2017-06-23','2017-06-26','2017-06-22','2017-06-23','<andamento><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'22/06/2017 16:46:22\' mensagem=\'Profissional ciente da atividade\'/></andamento>',25,60),(113,2,60,35,NULL,5,'2017-06-24','2017-06-25','2017-06-23','2017-06-27','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 15:52:59\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'23/06/2017 10:26:10\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(114,2,60,35,NULL,5,'2017-06-24','2017-06-25','2017-06-23','2017-06-27','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 15:53:07\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'23/06/2017 10:35:15\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(115,2,60,47,NULL,5,'2017-06-24','2017-06-25','2017-06-23','2017-06-27','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 15:53:36\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'23/06/2017 10:35:28\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(116,2,61,30,NULL,4,'2017-06-28','2017-06-29','2017-06-27','2017-06-27','<andamento><comentario id=\'2\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 16:06:04\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'4\' apelidoUsuario=\'André\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 16:05:56\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(117,2,61,28,NULL,5,'2017-06-28','2017-06-29','2017-06-27','2017-06-27','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 16:05:20\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 08:56:31\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(118,2,61,29,NULL,6,'2017-06-28','2017-06-29','2017-06-27','2017-06-27','<andamento><comentario id=\'2\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 16:05:39\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'6\' apelidoUsuario=\'carlos\' depUsuario=\'Departamento de Comércio\' momento=\'27/06/2017 16:05:35\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(120,2,62,53,NULL,5,'2017-06-29','2017-07-02','2017-06-28','2017-06-28','<andamento><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'28/06/2017 09:48:16\' mensagem=\'Profissional ciente da atividade\'/></andamento>',33,63),(122,2,63,56,NULL,5,'2017-06-29','2017-06-30','2017-06-28','2017-06-28','<andamento><comentario id=\'2\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'28/06/2017 10:45:39\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'5\' apelidoUsuario=\'bruno\' depUsuario=\'Departamento de Comércio\' momento=\'28/06/2017 09:53:11\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(123,2,64,27,NULL,3,'2017-09-14','2017-09-15','2017-09-13','2017-09-13','<andamento><comentario id=\'2\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'13/09/2017 10:59:57\' mensagem=\'Atividade finalizada por decisão do profissional.\'/><comentario id=\'1\' idUsuario=\'3\' apelidoUsuario=\'Cassiano\' depUsuario=\'Departamento de ISS\' momento=\'13/09/2017 10:59:23\' mensagem=\'Profissional ciente da atividade\'/></andamento>',NULL,NULL),(124,1,65,27,NULL,3,'2017-10-06','2017-10-07',NULL,NULL,'<andamento></andamento>',NULL,NULL),(125,1,66,27,NULL,3,'2017-10-26','2017-10-27',NULL,NULL,'<andamento></andamento>',NULL,NULL);
/*!40000 ALTER TABLE `bbh_atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_campo_detalhamento_atividade`
--

DROP TABLE IF EXISTS `bbh_campo_detalhamento_atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_campo_detalhamento_atividade` (
  `bbh_mod_ati_codigo` int(10) NOT NULL DEFAULT '0',
  `bbh_cam_det_flu_codigo` int(10) NOT NULL DEFAULT '0',
  KEY `fk_mod_ati` (`bbh_mod_ati_codigo`),
  KEY `fk_caM_det` (`bbh_cam_det_flu_codigo`),
  CONSTRAINT `fk_caM_det` FOREIGN KEY (`bbh_cam_det_flu_codigo`) REFERENCES `bbh_campo_detalhamento_fluxo` (`bbh_cam_det_flu_codigo`),
  CONSTRAINT `fk_mod_ati` FOREIGN KEY (`bbh_mod_ati_codigo`) REFERENCES `bbh_modelo_atividade` (`bbh_mod_ati_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_campo_detalhamento_atividade`
--

LOCK TABLES `bbh_campo_detalhamento_atividade` WRITE;
/*!40000 ALTER TABLE `bbh_campo_detalhamento_atividade` DISABLE KEYS */;
INSERT INTO `bbh_campo_detalhamento_atividade` VALUES (27,35),(27,36),(30,37),(30,38),(34,39),(34,40),(35,43),(35,44),(36,45),(36,46),(40,47),(40,48),(42,49),(42,50),(43,51),(43,52),(45,53),(45,54),(48,45),(48,46),(49,45),(49,46),(47,43),(47,44),(50,53),(50,54),(51,53),(51,54),(52,53),(52,54),(55,55),(55,56),(56,57),(56,58),(57,59),(57,60);
/*!40000 ALTER TABLE `bbh_campo_detalhamento_atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_campo_detalhamento_fluxo`
--

DROP TABLE IF EXISTS `bbh_campo_detalhamento_fluxo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_campo_detalhamento_fluxo` (
  `bbh_cam_det_flu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_flu_nome` varchar(255) NOT NULL,
  `bbh_cam_det_flu_titulo` varchar(255) DEFAULT NULL,
  `bbh_cam_det_flu_tipo` varchar(255) DEFAULT NULL,
  `bbh_cam_det_flu_curinga` varchar(255) DEFAULT NULL,
  `bbh_cam_det_flu_descricao` text,
  `bbh_det_flu_codigo` int(11) DEFAULT NULL,
  `bbh_cam_det_flu_tamanho` varchar(255) DEFAULT NULL,
  `bbh_cam_det_flu_default` varchar(255) DEFAULT NULL,
  `bbh_cam_det_flu_disponivel` char(1) NOT NULL DEFAULT '1',
  `bbh_cam_det_flu_preencher_inicio` char(1) NOT NULL DEFAULT '1',
  `bbh_cam_det_flu_obrigatorio` char(1) NOT NULL DEFAULT '1',
  `bbh_cam_det_flu_apelido` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bbh_cam_det_flu_codigo`),
  KEY `bbh_campo_detalhamento_fluxo_bbh_detalhamento_fluxo_` (`bbh_det_flu_codigo`),
  CONSTRAINT `bbh_campo_detalhamento_fluxo_bbh_detalhamento_fluxo` FOREIGN KEY (`bbh_det_flu_codigo`) REFERENCES `bbh_detalhamento_fluxo` (`bbh_det_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_campo_detalhamento_fluxo`
--

LOCK TABLES `bbh_campo_detalhamento_fluxo` WRITE;
/*!40000 ALTER TABLE `bbh_campo_detalhamento_fluxo` DISABLE KEYS */;
INSERT INTO `bbh_campo_detalhamento_fluxo` VALUES (35,'bbh_cam_det_19_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para avaliação final de um processo, podendo ser deferida ou indeferida.',19,NULL,'Deferida|Indeferida|','1','0','1','rede-simples-viabilidade-analise-endereco'),(36,'bbh_cam_det_19_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do deferimento ou indeferimento.',19,'50|5',NULL,'1','0','1','rede-simples-viabilidade-analise-endereco-motivo'),(37,'bbh_cam_det_20_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para avaliação final de um processo, podendo ser deferida ou indeferida.',20,NULL,'Deferida|Indeferida|','1','0','1','rede-simples-viabilidade-analise-endereco'),(38,'bbh_cam_det_20_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do deferimento ou indeferimento.',20,'50|5',NULL,'1','0','1','rede-simples-viabilidade-analise-endereco-motivo'),(39,'bbh_cam_det_21_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para avaliação final de um processo, podendo ser deferida ou indeferida.',21,NULL,'Deferida|Indeferida|','1','0','1','rede-simples-viabilidade-analise-endereco'),(40,'bbh_cam_det_21_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do deferimento ou indeferimento.',21,'50|5',NULL,'1','0','1','rede-simples-viabilidade-analise-endereco-motivo'),(41,'bbh_cam_det_22_anaalise','INATIVO','lista_opcoes','INATIVO','INATIVO',22,NULL,'Indeferida|','1','1','1',NULL),(42,'bbh_cam_det_22_motivo','INATIVO','texto_longo','INATIVO2','INATIVO',22,'50|5',NULL,'1','1','1',NULL),(43,'bbh_cam_det_23_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para indeferimento de um processo, quando ainda não é uma atividade final de um processo predecessor.',23,NULL,'Indeferida|','1','1','1','rede-simples-viabilidade-analise-endereco'),(44,'bbh_cam_det_23_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do indeferimento.',23,'50|5',NULL,'1','1','1','rede-simples-viabilidade-analise-endereco-motivo'),(45,'bbh_cam_det_24_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para indeferimento de um processo, quando ainda não é uma atividade final de um processo predecessor.',24,NULL,'Indeferida|','1','1','1','rede-simples-viabilidade-analise-endereco'),(46,'bbh_cam_det_24_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do indeferimento.',24,'50|5',NULL,'1','1','1','rede-simples-viabilidade-analise-endereco-motivo'),(47,'bbh_cam_det_25_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para avaliação final de um processo, podendo ser deferida ou indeferida.',25,NULL,'Deferida|Indeferida|','1','0','1','rede-simples-viabilidade-analise-endereco'),(48,'bbh_cam_det_25_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do deferimento ou indeferimento.',25,'50|5',NULL,'1','0','1','rede-simples-viabilidade-analise-endereco-motivo'),(49,'bbh_cam_det_26_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para avaliação final de um processo, podendo ser deferida ou indeferida.',26,NULL,'Deferida|Indeferida|','1','0','1','rede-simples-viabilidade-analise-endereco'),(50,'bbh_cam_det_26_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do deferimento ou indeferimento.',26,'50|5',NULL,'1','0','1','rede-simples-viabilidade-analise-endereco-motivo'),(51,'bbh_cam_det_27_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para avaliação final de um processo, podendo ser deferida ou indeferida.',27,NULL,'Deferida|Indeferida|','1','0','1','rede-simples-viabilidade-analise-endereco'),(52,'bbh_cam_det_27_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do deferimento ou indeferimento.',27,'50|5',NULL,'1','0','1','rede-simples-viabilidade-analise-endereco-motivo'),(53,'bbh_cam_det_28_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Este campo destina-se  para indeferimento de um processo, quando ainda não é uma \natividade final de um processo predecessor.',28,NULL,'Indeferida|','1','1','1','rede-simples-viabilidade-analise-endereco'),(54,'bbh_cam_det_28_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Este campo destina-se informar o motivo do indeferimento.',28,'50|5',NULL,'1','1','1','rede-simples-viabilidade-analise-endereco-motivo'),(55,'bbh_cam_det_29_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Analise',29,NULL,'Deferida|Indeferida|','1','0','1','rede-simples-viabilidade-analise-endereco'),(56,'bbh_cam_det_29_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Motivo',29,'50|5',NULL,'1','0','1','rede-simples-viabilidade-analise-endereco-motivo'),(57,'bbh_cam_det_30_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Análise',30,NULL,'Indeferida|','1','1','1','rede-simples-viabilidade-analise-endereco'),(58,'bbh_cam_det_30_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Motivo',30,'50|5',NULL,'1','1','1','rede-simples-viabilidade-analise-endereco-motivo'),(59,'bbh_cam_det_31_anaalise','Análise','lista_opcoes','@rede-simples-viabilidade-analise','Análise',31,NULL,'Indeferida|','1','1','1','rede-simples-viabilidade-analise-endereco'),(60,'bbh_cam_det_31_motivo','Motivo','texto_longo','@rede-simples-viabilidade-motivo','Motivo',31,'50|5',NULL,'1','1','1','rede-simples-viabilidade-analise-endereco-motivo');
/*!40000 ALTER TABLE `bbh_campo_detalhamento_fluxo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_campo_detalhamento_protocolo`
--

DROP TABLE IF EXISTS `bbh_campo_detalhamento_protocolo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_campo_detalhamento_protocolo` (
  `bbh_cam_det_pro_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_pro_nome` varchar(255) NOT NULL,
  `bbh_cam_det_pro_titulo` varchar(255) DEFAULT NULL,
  `bbh_cam_det_pro_tipo` varchar(255) DEFAULT NULL,
  `bbh_cam_det_pro_curinga` varchar(255) DEFAULT NULL,
  `bbh_cam_det_pro_descricao` text,
  `bbh_cam_det_pro_tamanho` varchar(255) DEFAULT NULL,
  `bbh_cam_det_pro_default` text,
  `bbh_cam_det_pro_disponivel` char(1) NOT NULL DEFAULT '1',
  `bbh_cam_det_pro_obrigatorio` char(1) NOT NULL DEFAULT '0',
  `bbh_cam_det_pro_visivel` char(1) NOT NULL DEFAULT '1',
  `bbh_cam_det_pro_ordem` int(11) NOT NULL DEFAULT '1',
  `bbh_cam_det_pro_fixo` int(11) NOT NULL DEFAULT '0',
  `bbh_cam_det_pro_preencher_apos_receber` int(11) NOT NULL DEFAULT '0',
  `bbh_cam_det_pro_apelido` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bbh_cam_det_pro_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_campo_detalhamento_protocolo`
--

LOCK TABLES `bbh_campo_detalhamento_protocolo` WRITE;
/*!40000 ALTER TABLE `bbh_campo_detalhamento_protocolo` DISABLE KEYS */;
INSERT INTO `bbh_campo_detalhamento_protocolo` VALUES (1,'bbh_pro_titulo','Assunto/Empresa','texto_simples','@bbh_pro_assunto@','Assunto a ser abordado','255',NULL,'1','1','1',4,1,0,NULL),(2,'bbh_pro_descricao','Observações','texto_longo','@bbh_pro_descricao@',NULL,'50|5',NULL,'1','0','1',8,1,0,NULL),(5,'bbh_pro_identificacao','Processo','texto_simples','@bbh_pro_identificacao@','Processo','255',NULL,'1','1','1',6,1,0,'rede-simples-viabilidade-numeroProcesso'),(7,'bbh_pro_data','Prazo','data','@bbh_pro_prazo@','Prazo para produção dos conhecimentos','255',NULL,'1','0','1',7,1,0,NULL),(8,'bbh_pro_flagrante','Flagrante','lista_opcoes','@bbh_pro_flagrante@','Flagrante','255','Sim|Não|','1','0','0',11,1,0,NULL),(9,'bbh_pro_autoridade','Solicitante','texto_simples','@bbh_pro_solicitante','Solicitante','255',NULL,'1','0','0',10,1,0,NULL),(10,'bbh_dep_codigo','Unidade','numero','@bbh_uni_codigo@','Inidade que receberá a solicitação.','255',NULL,'1','1','1',2,1,0,NULL),(33,'bbh_cam_det_pro_33','Dados empresa','json','@rede-simples-viabilidade-empresa','Dados da empresa recuperadas na Viabilidade - Rede Simples',NULL,NULL,'1','0','1',12,0,0,'rede-simples-viabilidade-empresa'),(34,'bbh_cam_det_pro_34','Recebimento confirmado','lista_opcoes','@rede-simples-viabilidade-confirmaRecebimento',NULL,NULL,'Sim|Não|','1','0','0',13,0,0,'rede-simples-viabilidade-confirmaRecebimento'),(35,'bbh_cam_det_pro_35','Sincronizado Junta Comercial','lista_opcoes','@rede-simples-viabilidade-empresa-sincronizado','rede-simples-viabilidade-analise-endereco-sincronizado',NULL,'Sim|Não|','1','0','0',14,0,0,'rede-simples-viabilidade-analise-endereco-sincronizado'),(36,'bbh_cam_det_pro_36','Situação analise endereço','texto_simples','@rede-simples-viabilidade-analise-endereco',NULL,'255',NULL,'1','0','1',15,0,0,'rede-simples-viabilidade-analise-endereco'),(37,'bbh_cam_det_pro_37','Resposta analise','texto_longo','@rede-simples-viabilidade-analise-endereco-motivo','rede-simples-viabilidade-analise-endereco-motivo','50|5',NULL,'1','0','1',16,0,0,'rede-simples-viabilidade-analise-endereco-motivo');
/*!40000 ALTER TABLE `bbh_campo_detalhamento_protocolo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_campo_indicio`
--

DROP TABLE IF EXISTS `bbh_campo_indicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_campo_indicio` (
  `bbh_cam_ind_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_ind_nome` varchar(255) NOT NULL,
  `bbh_cam_ind_titulo` varchar(255) DEFAULT NULL,
  `bbh_cam_ind_tipo` varchar(255) DEFAULT NULL,
  `bbh_cam_ind_curinga` varchar(255) DEFAULT NULL,
  `bbh_cam_ind_descricao` text,
  `bbh_cam_ind_tamanho` varchar(255) DEFAULT NULL,
  `bbh_cam_ind_default` text,
  `bbh_cam_ind_disponivel` char(1) NOT NULL DEFAULT '1',
  `bbh_cam_ind_obrigatorio` char(1) NOT NULL DEFAULT '0',
  `bbh_cam_ind_mesmaLinha` char(1) NOT NULL DEFAULT '0',
  `bbh_cam_ind_visivel` char(1) NOT NULL DEFAULT '1',
  `bbh_cam_ind_largura_titulo` int(11) NOT NULL DEFAULT '100',
  `bbh_cam_ind_largura_campo` int(11) NOT NULL DEFAULT '100',
  `bbh_cam_ind_ordem` int(11) NOT NULL DEFAULT '1',
  `bbh_cam_ind_fixo` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bbh_cam_ind_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_campo_indicio`
--

LOCK TABLES `bbh_campo_indicio` WRITE;
/*!40000 ALTER TABLE `bbh_campo_indicio` DISABLE KEYS */;
INSERT INTO `bbh_campo_indicio` VALUES (1,'bbh_ind_unidade','Unidade de medida','lista_opcoes',NULL,NULL,NULL,'Quilograma|Metro|Caixa|Peça|Litro|Unidade|','0','0','0','1',100,100,1,'1'),(2,'bbh_ind_titulo','Informação','texto_simples',NULL,'Elencar os dados dos objetos necessáros à realização da pesquisa','255',NULL,'1','0','0','1',100,100,2,'1'),(3,'bbh_ind_referencia','Referência','texto_simples',NULL,'Referência','255',NULL,'0','0','0','1',100,100,3,'1'),(4,'bbh_ind_quantidade','Quantidade','numero',NULL,'Quantidade','16',NULL,'0','0','0','1',100,100,4,'1'),(5,'bbh_ind_valor_unitario','Valor unitário','numero_decimal',NULL,'Valor unitário','16','0.00','0','0','0','1',100,12,5,'1'),(6,'bbh_ind_valor_total','Valor total','numero_decimal',NULL,'Valor total','16','0.00','0','0','0','1',100,12,6,'1'),(7,'bbh_ind_confiabilidade_fonte','Confiabilidade da fonte','lista_opcoes',NULL,'Confiabilidade da fonte','11','0|1|2|3|4|5|6|7|8|9|10','1','0','0','1',100,100,7,'1'),(8,'bbh_ind_veracidade_informacao','Veracidade da Informação','lista_opcoes',NULL,'Veracidade da Informação','11','0|1|2|3|4|5|6|7|8|9|10','1','0','0','1',100,100,8,'1'),(9,'bbh_ind_fonte_informacao','Fonte da informação','texto_simples',NULL,'Fonte da Informação','255',NULL,'1','0','0','1',100,100,9,'0'),(10,'bbh_ind_sigilo','Sigilo','lista_opcoes',NULL,'Sigilo','11','0','1','0','0','1',100,100,10,'0');
/*!40000 ALTER TABLE `bbh_campo_indicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_campo_lista_dinamica`
--

DROP TABLE IF EXISTS `bbh_campo_lista_dinamica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_campo_lista_dinamica` (
  `bbh_cam_list_codigo` int(10) NOT NULL AUTO_INCREMENT,
  `bbh_cam_list_mascara` varchar(255) DEFAULT NULL,
  `bbh_cam_list_titulo` varchar(255) DEFAULT NULL,
  `bbh_cam_list_valor` varchar(255) DEFAULT NULL,
  `bbh_cam_list_ordem` int(11) DEFAULT NULL,
  `bbh_cam_list_tipo` char(1) DEFAULT 'S',
  PRIMARY KEY (`bbh_cam_list_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_campo_lista_dinamica`
--

LOCK TABLES `bbh_campo_lista_dinamica` WRITE;
/*!40000 ALTER TABLE `bbh_campo_lista_dinamica` DISABLE KEYS */;
INSERT INTO `bbh_campo_lista_dinamica` VALUES (2,'01','Código de atividade econômica','6209-1/00 - INSTALAÇÃO DE SOFTWARE; SERVIÇOS DE',1,'S'),(3,'01','Código de atividade econômica','6209-1/00 - RECUPERAÇÃO DE DADOS, ARQUIVOS; SERVIÇOS DE',2,'S');
/*!40000 ALTER TABLE `bbh_campo_lista_dinamica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_campo_tipo_indicio`
--

DROP TABLE IF EXISTS `bbh_campo_tipo_indicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_campo_tipo_indicio` (
  `bbh_tip_codigo` int(10) DEFAULT NULL,
  `bbh_cam_ind_codigo` int(10) DEFAULT NULL,
  `bbh_ordem_exibicao` int(10) DEFAULT NULL,
  KEY `fk_tip_codigo` (`bbh_tip_codigo`),
  KEY `fk_cam_ind_codigo` (`bbh_cam_ind_codigo`),
  CONSTRAINT `fk_cam_ind_codigo` FOREIGN KEY (`bbh_cam_ind_codigo`) REFERENCES `bbh_campo_indicio` (`bbh_cam_ind_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `fk_tip_codigo` FOREIGN KEY (`bbh_tip_codigo`) REFERENCES `bbh_tipo_indicio` (`bbh_tip_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_campo_tipo_indicio`
--

LOCK TABLES `bbh_campo_tipo_indicio` WRITE;
/*!40000 ALTER TABLE `bbh_campo_tipo_indicio` DISABLE KEYS */;
INSERT INTO `bbh_campo_tipo_indicio` VALUES (1,1,1);
/*!40000 ALTER TABLE `bbh_campo_tipo_indicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_departamento`
--

DROP TABLE IF EXISTS `bbh_departamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_departamento` (
  `bbh_dep_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_dep_nome` varchar(100) DEFAULT NULL,
  `bbh_dep_obs` text,
  PRIMARY KEY (`bbh_dep_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_departamento`
--

LOCK TABLES `bbh_departamento` WRITE;
/*!40000 ALTER TABLE `bbh_departamento` DISABLE KEYS */;
INSERT INTO `bbh_departamento` VALUES (1,'INATIVO','INATIVO'),(2,'Recepção dos Documentos','Recepção dos Documentos'),(3,'Departamento de ISS','Departamento de ISS'),(4,'Departamento de Triagem','Departamento de Triagem'),(5,'Divisão de Produtos Químicos e Inflamáveis','Divisão de Produtos Químicos e Inflamáveis'),(6,'Departamento de Comércio','Departamento de Comércio'),(7,'Alta Administração','Alta Administração');
/*!40000 ALTER TABLE `bbh_departamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_dependencia`
--

DROP TABLE IF EXISTS `bbh_dependencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_dependencia` (
  `bbh_pre_mod_ati_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_pre_mod_ati_observacao` text,
  `bbh_modelo_atividade_predecessora` int(11) DEFAULT NULL,
  `bbh_modelo_atividade_sucessora` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_pre_mod_ati_codigo`),
  KEY `bbh_modelo_atividade_predecessora` (`bbh_modelo_atividade_predecessora`),
  KEY `bbh_modelo_atividade_sucessora` (`bbh_modelo_atividade_sucessora`),
  CONSTRAINT `bbh_modelo_atividade_predecessora` FOREIGN KEY (`bbh_modelo_atividade_predecessora`) REFERENCES `bbh_modelo_atividade` (`bbh_mod_ati_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_modelo_atividade_sucessora` FOREIGN KEY (`bbh_modelo_atividade_sucessora`) REFERENCES `bbh_modelo_atividade` (`bbh_mod_ati_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_dependencia`
--

LOCK TABLES `bbh_dependencia` WRITE;
/*!40000 ALTER TABLE `bbh_dependencia` DISABLE KEYS */;
INSERT INTO `bbh_dependencia` VALUES (8,NULL,28,29),(9,NULL,29,30),(10,NULL,31,32),(11,NULL,32,33),(12,NULL,33,34),(13,NULL,37,38),(14,NULL,38,39),(15,NULL,39,40),(16,NULL,41,42),(17,NULL,53,54),(18,NULL,54,55);
/*!40000 ALTER TABLE `bbh_dependencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_detalhamento_fluxo`
--

DROP TABLE IF EXISTS `bbh_detalhamento_fluxo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_detalhamento_fluxo` (
  `bbh_det_flu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_mod_flu_codigo` int(11) DEFAULT NULL,
  `bbh_det_flu_tabela_criada` int(11) DEFAULT '0',
  PRIMARY KEY (`bbh_det_flu_codigo`),
  KEY `bbh_det_flu_codigo_bbh_mod_flu_codigo` (`bbh_mod_flu_codigo`),
  CONSTRAINT `bbh_det_flu_codigo_bbh_mod_flu_codigo` FOREIGN KEY (`bbh_mod_flu_codigo`) REFERENCES `bbh_modelo_fluxo` (`bbh_mod_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_detalhamento_fluxo`
--

LOCK TABLES `bbh_detalhamento_fluxo` WRITE;
/*!40000 ALTER TABLE `bbh_detalhamento_fluxo` DISABLE KEYS */;
INSERT INTO `bbh_detalhamento_fluxo` VALUES (19,19,1),(20,20,1),(21,21,1),(22,22,1),(23,23,1),(24,24,1),(25,25,1),(26,26,1),(27,27,1),(28,28,1),(29,29,1),(30,30,1),(31,31,1);
/*!40000 ALTER TABLE `bbh_detalhamento_fluxo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_detalhamento_protocolo`
--

DROP TABLE IF EXISTS `bbh_detalhamento_protocolo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_detalhamento_protocolo` (
  `bbh_det_pro_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_pro_codigo` int(11) DEFAULT NULL,
  `bbh_cam_det_pro_33` blob,
  `bbh_cam_det_pro_34` varchar(255) DEFAULT NULL,
  `bbh_cam_det_pro_35` varchar(255) DEFAULT NULL,
  `bbh_cam_det_pro_36` varchar(255) DEFAULT NULL,
  `bbh_cam_det_pro_37` blob,
  PRIMARY KEY (`bbh_det_pro_codigo`),
  KEY `fk_bbh_pro_codigo` (`bbh_pro_codigo`),
  CONSTRAINT `fk_bbh_pro_codigo` FOREIGN KEY (`bbh_pro_codigo`) REFERENCES `bbh_protocolos` (`bbh_pro_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_detalhamento_protocolo`
--

LOCK TABLES `bbh_detalhamento_protocolo` WRITE;
/*!40000 ALTER TABLE `bbh_detalhamento_protocolo` DISABLE KEYS */;
INSERT INTO `bbh_detalhamento_protocolo` VALUES (203,210,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2135`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`30591905850`,`nome`:`ROBSON CRUZ`,`email`:`rcruz@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99128668`,`dddCelular`:`13`,`celular`:`991286680`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`12.0`,`areaUtilizada`:`8.0`,`endereco`:{`numeroCep`:`92330500`,`logradouro`:`RUA FLORIANOPOLIS`,`numeroLogradouro`:`12`,`complemento`:`ANDAR: Con 78;`,`bairro`:`MATHIAS VELHO`}},`coletaObjetoSocial`:{`objetoSocial`:`OBJETO XPTO`},`coletaSocio`:{`attributes`:{`cpf`:`18045437219`,`nomeSocio`:`Monteiro Lobato`}},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6202300`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`02`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385066`}}','Sim','Sim','INDEFERIDA','não atendeu a lei 123456'),(204,211,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`30591905850`,`nome`:`ROBSON CRUZ`,`email`:`rcruz@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99128668`,`dddCelular`:`13`,`celular`:`991286680`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92330500`,`logradouro`:`RUA FLORIANOPOLIS`,`numeroLogradouro`:`74`,`bairro`:`MATHIAS VELHO`}},`coletaObjetoSocial`:{`objetoSocial`:`DADOS DA EMPRESA DO URIEL`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6202300`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385081`}}','Sim','Sim','INDEFERIDA','Finalizando atividade de indeferimento processo comercio, aqui a atividade que escolheu por indeferir, foi a atividade 3 (carlos.sena), porem ao escoher para quem ia a atividade de indeferimento, foi escolhido o (bruno.azevedo)...'),(205,212,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92010100`,`logradouro`:`RUA ANITA GARIBALDI`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`PRIMEIRO TESTE`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385087`}}','Sim','Sim','INDEFERIDA','estou indeferindo no protocolo, antes mesmo de receber'),(206,213,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92323030`,`logradouro`:`RUA ANNAPOLIS`,`numeroLogradouro`:`1`,`bairro`:`MATO GRANDE`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 3`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385088`}}','Sim','Sim','DEFERIDA','Estou deferindo o processo já no protocolo, após ter recebido esta solicitação, mas sem enviar para nenhum fluxo...'),(207,214,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92031200`,`logradouro`:`RUA ANTELMO SEGUNDO MANFROI`,`numeroLogradouro`:`1`,`bairro`:`ESTANCIA VELHA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 4`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`06`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385089`}}','Sim','Sim','DEFERIDA','Deferindo processo produtos quimicos'),(208,215,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310370`,`logradouro`:`RUA ANDRADE NEVES`,`numeroLogradouro`:`1`,`bairro`:`HARMONIA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 5`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385090`}}','Sim','Sim','INDEFERIDA','aqui eu indeferi o processo diversificado na atividade 11, mas na atividade 12, msm sem ter chegado nela, eu preenchi as informações como deferida'),(209,216,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92010020`,`logradouro`:`RUA ANDRE DA ROCHA`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 5`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`06`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385091`}}','Sim','Sim','INDEFERIDA','indeferi na atividade 11'),(210,217,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`30591905850`,`nome`:`ROBSON CRUZ`,`email`:`rcruz@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99128668`,`dddCelular`:`13`,`celular`:`991286680`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92031200`,`logradouro`:`RUA ANTELMO SEGUNDO MANFROI`,`numeroLogradouro`:`12`,`bairro`:`ESTANCIA VELHA`}},`coletaObjetoSocial`:{`objetoSocial`:`OBJETO RCRUZ`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`06`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385092`}}','Sim','Sim','DEFERIDA','marquei como deferida e estou enviando para o subfluxo 2'),(211,218,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`30591905850`,`nome`:`ROBSON CRUZ`,`email`:`rcruz@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99128668`,`dddCelular`:`13`,`celular`:`991286680`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310370`,`logradouro`:`RUA ANDRADE NEVES`,`numeroLogradouro`:`12`,`bairro`:`HARMONIA`}},`coletaObjetoSocial`:{`objetoSocial`:`OBJETO 6203-1/00`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6203100`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385093`}}','Sim','Sim','INDEFERIDA','estou indeferindo o processo ISS'),(212,219,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92440688`,`logradouro`:`RUA ANDRE FORSTER`,`numeroLogradouro`:`1`,`bairro`:`GUAJUVIRAS`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 6`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385094`}}','Sim','Sim','DEFERIDA','estou deferindo aqui'),(213,220,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92025440`,`logradouro`:`RUA ANDRE GONCALVES`,`numeroLogradouro`:`1`,`bairro`:`NOSSA SENHORA DAS GRACAS`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 7`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`06`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385095`}}','Sim','Sim','INDEFERIDA','aqui indeferida'),(214,221,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92320030`,`logradouro`:`RUA ANDRE NICHELE`,`numeroLogradouro`:`1`,`bairro`:`MATO GRANDE`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 8`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385097`}}','Sim','Sim','DEFERIDA','deferida'),(215,222,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92032722`,`logradouro`:`BECO ANDREASA`,`numeroLogradouro`:`1`,`bairro`:`ESTANCIA VELHA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 9`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385098`}}','Sim','Sim','INDEFERIDA','indeferida aqui'),(216,223,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92025705`,`logradouro`:`RUA ANGELIM`,`numeroLogradouro`:`1`,`bairro`:`NOSSA SENHORA DAS GRACAS`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 10`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`06`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385099`}}','Sim','Sim','INDEFERIDA','não quis devefir'),(217,224,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92325550`,`logradouro`:`RUA ANGELINA GONCALVES`,`numeroLogradouro`:`1`,`bairro`:`HARMONIA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 11`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`06`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385100`}}','Sim','Sim','INDEFERIDA','indeferi depois de receber, ainda no protocolo.'),(218,225,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310140`,`logradouro`:`RUA ANGELO POSSEBON`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 12`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`02`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385101`}}','Sim','Sim','INDEFERIDA','indeferi !!!'),(219,226,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92010030`,`logradouro`:`RUA ANGUSTURA`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 13`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385103`}}','Sim','Sim','DEFERIDA','deferi aqui'),(220,227,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92200800`,`logradouro`:`RUA ALLAN KARDEC`,`numeroLogradouro`:`1`,`bairro`:`FATIMA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE14`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`06`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385104`}}','Sim','Sim','INDEFERIDA','...'),(221,228,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92025814`,`logradouro`:`RUA ALMERINDO SILVEIRA`,`numeroLogradouro`:`1`,`bairro`:`ESTANCIA VELHA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 15`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`05`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385106`}}','Sim','Sim','DEFERIDA','aaa'),(222,229,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92200550`,`logradouro`:`RUA ANA MARIA`,`numeroLogradouro`:`1`,`bairro`:`FATIMA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 20`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`02`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385115`}}','Sim','Sim','DEFERIDA','ADASDASDASD'),(223,230,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310370`,`logradouro`:`RUA ANDRADE NEVES`,`numeroLogradouro`:`2`,`bairro`:`HARMONIA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 21`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`05`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385117`}}','Sim','Sim','DEFERIDA','Esse processo foi deferido em 13/09/2017'),(224,231,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`9.9999999999E8`,`areaUtilizada`:`9.9999999999E8`,`endereco`:{`numeroCep`:`92200800`,`logradouro`:`RUA ALLAN KARDEC`,`numeroLogradouro`:`999999`,`bairro`:`FATIMA`}},`coletaObjetoSocial`:{`objetoSocial`:`....SDFGSDFSDFSDF`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385118`}}','Sim',NULL,NULL,NULL),(225,232,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92200800`,`logradouro`:`RUA ALLAN KARDEC`,`numeroLogradouro`:`2`,`bairro`:`FATIMA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 22`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`03`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385144`}}','Sim',NULL,NULL,NULL),(226,233,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92323030`,`logradouro`:`RUA ANNAPOLIS`,`numeroLogradouro`:`2`,`bairro`:`MATO GRANDE`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 23`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`06`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385145`}}','Sim',NULL,NULL,NULL),(227,234,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92031200`,`logradouro`:`RUA ANTELMO SEGUNDO MANFROI`,`numeroLogradouro`:`2`,`bairro`:`ESTANCIA VELHA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 24`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`05`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385146`}}','Sim',NULL,NULL,NULL),(228,235,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310370`,`logradouro`:`RUA ANDRADE NEVES`,`numeroLogradouro`:`2`,`bairro`:`HARMONIA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 25`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`03`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385147`}}','Sim',NULL,NULL,NULL),(229,236,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92020490`,`logradouro`:`RUA AMERICA`,`numeroLogradouro`:`2`,`bairro`:`MARECHAL RONDON`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 26`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385148`}}','Sim',NULL,NULL,NULL),(230,237,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92025720`,`logradouro`:`RUA AMERICO VESPUCIO`,`numeroLogradouro`:`2`,`bairro`:`NOSSA SENHORA DAS GRACAS`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 27`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385149`}}','Sim',NULL,NULL,NULL),(231,238,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92025760`,`logradouro`:`RUA AMOR PERFEIRO`,`numeroLogradouro`:`2`,`bairro`:`ESTANCIA VELHA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 28`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385150`}}','Sim',NULL,NULL,NULL),(232,239,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92425634`,`logradouro`:`RUA AMSTERDA`,`numeroLogradouro`:`2`,`bairro`:`SAO JOSE`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 29`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385151`}}','Sim',NULL,NULL,NULL),(233,240,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92200800`,`logradouro`:`RUA ALLAN KARDEC`,`numeroLogradouro`:`3`,`bairro`:`FATIMA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 30`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385152`}}','Sim',NULL,NULL,NULL),(234,241,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92031200`,`logradouro`:`RUA ANTELMO SEGUNDO MANFROI`,`numeroLogradouro`:`3`,`bairro`:`ESTANCIA VELHA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 31`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385153`}}','Sim',NULL,NULL,NULL),(235,242,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310370`,`logradouro`:`RUA ANDRADE NEVES`,`numeroLogradouro`:`3`,`bairro`:`HARMONIA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 32`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385154`}}','Sim',NULL,NULL,NULL),(236,243,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92200800`,`logradouro`:`RUA ALLAN KARDEC`,`numeroLogradouro`:`3`,`bairro`:`FATIMA`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 34`},`coletaAtividadeEconomica`:[{`atividadeEconomica`:{`attributes`:{`cnae`:`1099606`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`1112700`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`1531902`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`1813001`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`2014200`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}}],`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`03`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385157`}}','Sim',NULL,NULL,NULL),(237,244,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92323030`,`logradouro`:`RUA ANNAPOLIS`,`numeroLogradouro`:`3`,`bairro`:`MATO GRANDE`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 35`},`coletaAtividadeEconomica`:[{`atividadeEconomica`:{`attributes`:{`cnae`:`2073800`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`2391503`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`2443100`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`2722802`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}}],`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385158`}}','Sim','Sim','DEFERIDA','Atendeu a lei 123456'),(238,245,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2151`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92200800`,`logradouro`:`ALLAN KARDEC`,`numeroLogradouro`:`03`,`bairro`:`FATIMA`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 36`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385184`}}','Sim','Sim','INDEFERIDA','Estou indeferindo a solicitação, pois os dados de endereço não são compatíveis para o CNAE desejado.'),(239,246,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2151`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`102`}},`cnpj`:`43735654000176`,`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310370`,`logradouro`:`ANDRADE NEVES`,`numeroLogradouro`:`3`,`bairro`:`HARMONIA`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 37`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`02`}},{`attributes`:{`codigo`:`03`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385185`}}','Sim','Sim','INDEFERIDA','Não atendeu a lei...'),(240,247,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2151`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`106`}},`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92323030`,`logradouro`:`ANNAPOLIS`,`numeroLogradouro`:`3`,`bairro`:`MATO GRANDE`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 39`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`06`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385187`}}','Sim','Sim','INDEFERIDA','Não atendeu a lei 123'),(241,248,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2151`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92031200`,`logradouro`:`ANTELMO SEGUNDO MANFROI`,`numeroLogradouro`:`4`,`bairro`:`ESTANCIA VELHA`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 40`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`04`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385188`}}','Sim','Sim','DEFERIDA','estou deferindo'),(242,249,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2151`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310370`,`logradouro`:`ANDRADE NEVES`,`numeroLogradouro`:`4`,`bairro`:`HARMONIA`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`OBJETO SOCIAL TESTE 1`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`03`}},{`attributes`:{`codigo`:`05`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385191`}}','Sim','Sim','DEFERIDA','Atendeu a lei...'),(243,250,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2305`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`70851974201`,`nome`:`NOME TESTE`,`email`:`cpd@jucergs.rs.gov.br`,`dddTelefone`:`00`,`telefone`:`00000000`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`150.0`,`areaUtilizada`:`150.0`,`endereco`:{`numeroCep`:`92200720`,`logradouro`:`JOAQUIM NABUCO`,`numeroLogradouro`:`693`,`bairro`:`FATIMA`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`REPRESENTACAO COMERCIAL E COMERCIO DE VSTUARIO`},`coletaSocio`:{`attributes`:{`cpf`:`00117094056`,`nomeSocio`:`TESTE TESTE`}},`coletaAtividadeEconomica`:[{`atividadeEconomica`:{`attributes`:{`cnae`:`4616800`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`false`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`4781400`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}}],`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`01`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385198`}}','Sim',NULL,NULL,NULL),(244,251,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`70851974201`,`nome`:`NOME TESTE`,`email`:`cpd@jucergs.rs.gov.br`,`dddTelefone`:`00`,`telefone`:`00000000`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`100.0`,`areaUtilizada`:`100.0`,`endereco`:{`numeroCep`:`92130500`,`logradouro`:`ARY DIAS FERREIRA`,`numeroLogradouro`:`311`,`bairro`:`NITEROI`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`INDUSTRIA E COMERCIO DE PRODUTOS NATURAIS, EMBALAGENS DE CHAS, DE MEL E DISTRIBUICAO E BENEFICIAMENTO DE PRODUTOS NATURAIS`},`coletaSocio`:{`attributes`:{`cpf`:`87575159053`,`nomeSocio`:`FFF FFF`}},`coletaAtividadeEconomica`:[{`atividadeEconomica`:{`attributes`:{`cnae`:`1099607`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`8292000`}},`attributes`:{`tipoAtividadeEconomica`:`S`,`exercidaNoLocal`:`true`}},{`atividadeEconomica`:{`attributes`:{`cnae`:`1099699`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}}],`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`01`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385199`}}','Sim',NULL,NULL,NULL),(245,252,'{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`OUTROS`,`evento`:{`attributes`:{`codigo`:`101`}},`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`00875733000`,`nome`:`FELIPE SILVA`,`email`:`felipe@jucergs.rs.gov.br`,`dddTelefone`:`51`,`telefone`:`32167587`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`100.0`,`areaUtilizada`:`50.0`,`endereco`:{`numeroCep`:`92130500`,`logradouro`:`ARY DIAS FERREIRA`,`numeroLogradouro`:`120`,`bairro`:`NITEROI`,`tipoLogradouro`:{`attributes`:{`codigo`:`R`}}}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE`},`coletaSocio`:[{`attributes`:{`cpf`:`82267570106`,`nomeSocio`:`ANTONIO DA SILVA`}},{`attributes`:{`cpf`:`82270384172`,`nomeSocio`:`JOAO DA SILVA`}}],`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`8650003`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`01`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385237`}}','Sim','Sim','DEFERIDA','Sucesso!');
/*!40000 ALTER TABLE `bbh_detalhamento_protocolo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_fluxo`
--

DROP TABLE IF EXISTS `bbh_fluxo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_fluxo` (
  `bbh_flu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_mod_flu_codigo` int(11) DEFAULT NULL,
  `bbh_flu_observacao` text,
  `bbh_flu_data_iniciado` date DEFAULT NULL,
  `bbh_flu_titulo` varchar(255) DEFAULT NULL,
  `bbh_flu_tarefa_pai` int(11) DEFAULT NULL,
  `bbh_usu_codigo` int(11) DEFAULT '0',
  `bbh_flu_oculto` char(1) DEFAULT '0',
  `bbh_flu_finalizado` char(1) DEFAULT '0',
  `bbh_flu_autonumeracao` int(11) DEFAULT NULL,
  `bbh_flu_anonumeracao` int(11) DEFAULT NULL,
  `bbh_flu_codigobarras` varchar(20) DEFAULT NULL,
  `bbh_protocolo_referencia` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_flu_codigo`),
  KEY `bbh_fluxo_bbh_modelo_fluxo` (`bbh_mod_flu_codigo`),
  KEY `bbh_usu_codigo` (`bbh_usu_codigo`),
  KEY `bbh_flu_codigobarras` (`bbh_flu_codigobarras`),
  CONSTRAINT `bbh_fluxo_bbh_modelo_fluxo` FOREIGN KEY (`bbh_mod_flu_codigo`) REFERENCES `bbh_modelo_fluxo` (`bbh_mod_flu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_codigoR` FOREIGN KEY (`bbh_usu_codigo`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_fluxo`
--

LOCK TABLES `bbh_fluxo` WRITE;
/*!40000 ALTER TABLE `bbh_fluxo` DISABLE KEYS */;
INSERT INTO `bbh_fluxo` VALUES (29,19,'','2017-05-30','Processo ISS - 1.1/2017 (Rede Simples)',NULL,1,'0','1',1,2017,NULL,244),(30,19,'','2017-05-30','Processo ISS - 2.1/2017 (Rede Simples)',NULL,1,'0','1',2,2017,NULL,210),(31,20,'iniciando processo comercio teste 1','2017-05-31','Processo Comércio - 1.2/2017 (Rede Simples)',NULL,1,'0','0',1,2017,NULL,211),(32,23,'aqui é observação ao iniciar indeferimento da atividade 3 do processo comercio','2017-05-31','Sub: Processo Comércio - 1.2/2017 (Rede Simples)',53,1,'0','1',NULL,NULL,NULL,211),(33,21,'Iniciei o fluxo de produtos quimicos','2017-05-31','Processo Produtos Químicos e Inflamáveis - 1.3/2017 (Rede Simples)',NULL,1,'0','1',1,2017,NULL,214),(34,25,'iniciado processo diversificado','2017-05-31','Processo Diversificado - 1.5/2017 (Rede Simples)',NULL,1,'0','0',1,2017,NULL,215),(35,26,'foi tomada a decisão de ir para o subfluxo 1','2017-05-31','Sub: Processo Diversificado - 1.5/2017 (Rede Simples)',62,1,'0','1',NULL,NULL,NULL,215),(36,28,'campo de observação da atividade 11 que preenchi','2017-05-31','Sub: Sub: Processo Diversificado - 1.5/2017 (Rede Simples)',63,1,'0','1',NULL,NULL,NULL,215),(37,25,'iniciado o fluxo diversificado teste 2','2017-05-31','Processo Diversificado - 2.5/2017 (Rede Simples)',NULL,1,'0','0',2,2017,NULL,216),(38,26,'aqui foi tomada a decisao de ir para o subfluxo 1 teste 2','2017-05-31','Sub: Processo Diversificado - 2.5/2017 (Rede Simples)',69,1,'0','0',NULL,NULL,NULL,216),(39,28,'indeferinto na atividade 11 ','2017-05-31','Sub: Sub: Processo Diversificado - 2.5/2017 (Rede Simples)',70,1,'0','1',NULL,NULL,NULL,216),(40,25,'processo diversificado teste 3','2017-05-31','Processo Diversificado - 3.5/2017 (Rede Simples)',NULL,1,'0','0',3,2017,NULL,217),(41,26,'iniciado subfluxo 1','2017-05-31','Sub: Processo Diversificado - 3.5/2017 (Rede Simples)',76,1,'0','0',NULL,NULL,NULL,217),(42,26,'aqui é a observação que estou iniciando o subfluxo 2 já com os campos de detalhamento preenchidos','2017-06-01','Sub: Sub: Processo Diversificado - 3.5/2017 (Rede Simples)',78,1,'0','1',NULL,NULL,NULL,217),(43,19,'iniciado processo ISS','2017-06-01','Processo ISS - 3.1/2017 (Rede Simples)',NULL,1,'0','1',3,2017,NULL,218),(44,19,'iniciado','2017-06-01','Processo ISS - 4.1/2017 (Rede Simples)',NULL,1,'0','1',4,2017,NULL,219),(45,19,'','2017-06-01','',NULL,1,'0','1',5,2017,'',220),(46,19,'','2017-06-01','',NULL,1,'0','1',6,2017,'',221),(47,19,'Alteração descrição Uriel','2017-06-01','Alteração Uriel',NULL,1,'0','1',7,2017,'',222),(48,21,'adicionei esse texto na observação 2','2017-06-01','Processo Produtos Químicos e Inflamáveis - 2.3/2017 (Rede Simples - adicionei esse texto no titulo) - adicionei esse texto no titulo 2',NULL,1,'0','0',2,2017,'',223),(49,19,'','2017-06-02','Processo ISS - 8.1/2017 (Rede Simples)',NULL,1,'0','0',8,2017,NULL,243),(50,24,'aqui é a obervação','2017-06-05','Sub: Processo Produtos Químicos e Inflamáveis - 2.3/2017 (Rede Simples - adicionei esse texto no titulo) - adicionei esse texto no titulo 2',88,1,'0','1',NULL,NULL,NULL,223),(51,21,'','2017-06-05','Processo Produtos Químicos e Inflamáveis - 3.3/2017 (Rede Simples)',NULL,1,'0','0',3,2017,NULL,225),(52,20,'campo observação preenchido pelo protocolo...','2017-06-07','Processo Comércio - 2.2/2017 (Rede Simples)',NULL,1,'0','1',2,2017,NULL,226),(53,24,'','2017-06-07','Sub: Processo Produtos Químicos e Inflamáveis - 3.3/2017 (Rede Simples)',94,1,'0','1',NULL,NULL,NULL,225),(54,19,'campo observação','2017-06-07','Processo ISS - 9.1/2017 (Rede Simples)',NULL,1,'0','1',9,2017,NULL,248),(55,19,'posso adicionar algo aqui...','2017-06-08','Processo ISS - 10.1/2017 (Rede Simples)',NULL,1,'0','1',10,2017,NULL,249),(56,20,'','2017-06-12','Processo Comércio - 3.2/2017 (Rede Simples)',NULL,1,'0','1',3,2017,NULL,227),(57,20,'','2017-06-13','Processo Comércio - 4.2/2017 (Rede Simples)',NULL,1,'0','1',4,2017,NULL,228),(58,20,'','2017-06-22','Processo Comércio - 5.2/2017 (Rede Simples)',NULL,1,'0','1',5,2017,NULL,251),(59,20,'','2017-06-22','Processo Comércio - 6.2/2017 (Rede Simples)',NULL,1,'0','0',6,2017,NULL,250),(60,23,'','2017-06-23','Sub: Processo Comércio - 6.2/2017 (Rede Simples)',111,1,'0','1',NULL,NULL,NULL,250),(61,20,'','2017-06-27','Processo Comércio - 7.2/2017 (Rede Simples)',NULL,1,'0','1',7,2017,NULL,229),(62,29,'','2017-06-28','Processo Comércio - 1.2/2017 (Rede Simples)',NULL,1,'0','0',1,2017,NULL,245),(63,30,'','2017-06-28','Sub: Processo Comércio - 1.2/2017 (Rede Simples)',120,1,'0','1',NULL,NULL,NULL,245),(64,19,'','2017-09-13','Processo ISS - 11.1/2017 (Rede Simples)',NULL,1,'0','1',11,2017,NULL,230),(65,19,'','2017-10-05','Processo ISS - 12.1/2017 (Rede Simples)',NULL,1,'0','0',12,2017,NULL,242),(66,19,'','2017-10-25','Processo ISS - 13.1/2017 (Rede Simples)',NULL,1,'0','0',13,2017,NULL,241);
/*!40000 ALTER TABLE `bbh_fluxo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_fluxo_alternativa`
--

DROP TABLE IF EXISTS `bbh_fluxo_alternativa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_fluxo_alternativa` (
  `bbh_flu_alt_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_flu_alt_titulo` varchar(255) DEFAULT NULL,
  `bbh_flu_observacao` text,
  `bbh_mod_ati_codigo` int(11) DEFAULT NULL,
  `bbh_atividade_predileta` int(11) DEFAULT NULL,
  `bbh_flu_alt_icone` varchar(50) DEFAULT '4.gif',
  `bbh_mod_flu_codigo` int(11) DEFAULT NULL,
  `bbh_mod_ati_ordem` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_flu_alt_codigo`),
  KEY `bbh_fluxo_alternativa_bbh_modelo_tarefa` (`bbh_mod_ati_codigo`),
  KEY `bbh_mod_flu_codigo` (`bbh_mod_flu_codigo`),
  CONSTRAINT `bbh_fluxo_alternativa_bbh_modelo_tarefa` FOREIGN KEY (`bbh_mod_ati_codigo`) REFERENCES `bbh_modelo_atividade` (`bbh_mod_ati_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_mod_flu_codigo` FOREIGN KEY (`bbh_mod_flu_codigo`) REFERENCES `bbh_modelo_fluxo` (`bbh_mod_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_fluxo_alternativa`
--

LOCK TABLES `bbh_fluxo_alternativa` WRITE;
/*!40000 ALTER TABLE `bbh_fluxo_alternativa` DISABLE KEYS */;
INSERT INTO `bbh_fluxo_alternativa` VALUES (22,'Indeferimento - Ativ. 5 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 5 - Processo Produtos Químicos e Inflamáveis',31,1,'4.gif',24,1),(23,'Indeferimento - Ativ. 1 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 1 - Processo Produtos Químicos e Inflamáveis',32,1,'4.gif',24,2),(24,'Indeferimento - Ativ. 2 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 2 - Processo Produtos Químicos e Inflamáveis',33,1,'4.gif',24,3),(25,'Indeferimento - Processo Comércio - Ativ. 2','Indeferimento - Processo Comércio - Ativ. 2',28,1,'4.gif',23,1),(26,'Indeferimento - Processo Comércio - Ativ. 3','Indeferimento - Processo Comércio - Ativ. 3',29,1,'4.gif',23,2),(27,'Indeferimento - Ativ. 7 - Processo Diversificado','Indeferimento - Ativ. 7 - Processo Diversificado',37,1,'4.gif',28,1),(28,'Indeferimento - Ativ. 8 - Processo Diversificado','Indeferimento - Ativ. 8 - Processo Diversificado',38,1,'4.gif',28,2),(29,'Indeferimento - Ativ. 9 - Processo Diversificado','Indeferimento - Ativ. 9 - Processo Diversificado',39,2,'4.gif',28,3),(30,'Indeferimento - Ativ. 11 - Processo Diversificado','Indeferimento - Ativ. 11 - Processo Diversificado',41,1,'4.gif',28,4),(31,'Sub Processo Diversificado 1 - Atividade 11','Esta decisão leva para Sub Processo Diversificado 1 - Atividade 11',39,1,'4.gif',26,1),(32,'Sub Processo Diversificado 2 - Atividade 13','Esta decisão leva para Sub Processo Diversificado 2 - Atividade 13',42,1,'4.gif',27,1),(33,'Indeferimento - Processo Comércio - Ativ. 2','Indeferimento - Processo Comércio - Ativ. 2',53,1,'4.gif',30,1),(34,'Indeferimento - Processo Comércio - Ativ. 3','Indeferimento - Processo Comércio - Ativ. 3',54,1,'4.gif',31,1);
/*!40000 ALTER TABLE `bbh_fluxo_alternativa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_fluxo_relacionado`
--

DROP TABLE IF EXISTS `bbh_fluxo_relacionado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_fluxo_relacionado` (
  `bbh_flu_codigo_p` int(11) NOT NULL DEFAULT '0',
  `bbh_flu_codigo_f` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bbh_flu_codigo_p`,`bbh_flu_codigo_f`),
  KEY `codigo_f` (`bbh_flu_codigo_f`),
  CONSTRAINT `codigo_f` FOREIGN KEY (`bbh_flu_codigo_f`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`),
  CONSTRAINT `codigo_p` FOREIGN KEY (`bbh_flu_codigo_p`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_fluxo_relacionado`
--

LOCK TABLES `bbh_fluxo_relacionado` WRITE;
/*!40000 ALTER TABLE `bbh_fluxo_relacionado` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_fluxo_relacionado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_indicio`
--

DROP TABLE IF EXISTS `bbh_indicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_indicio` (
  `bbh_ind_codigo` int(10) NOT NULL AUTO_INCREMENT,
  `bbh_tip_codigo` int(10) DEFAULT NULL,
  `bbh_pro_codigo` int(10) DEFAULT NULL,
  `bbh_usu_codigo` int(10) DEFAULT NULL,
  `bbh_ind_cadastro` datetime DEFAULT NULL,
  `bbh_ind_unidade` varchar(255) DEFAULT NULL,
  `bbh_ind_titulo` varchar(255) DEFAULT NULL,
  `bbh_ind_referencia` varchar(255) DEFAULT NULL,
  `bbh_ind_quantidade` int(11) DEFAULT NULL,
  `bbh_ind_valor_unitario` float DEFAULT NULL,
  `bbh_ind_valor_total` float DEFAULT NULL,
  `bbh_ind_confiabilidade_fonte` char(1) DEFAULT NULL,
  `bbh_ind_veracidade_informacao` int(11) DEFAULT NULL,
  `bbh_ind_fonte_informacao` varchar(255) DEFAULT NULL,
  `bbh_ind_sigilo` int(11) DEFAULT '-1',
  PRIMARY KEY (`bbh_ind_codigo`),
  KEY `fk_tipo` (`bbh_tip_codigo`),
  KEY `fk_protocolo` (`bbh_pro_codigo`),
  CONSTRAINT `fk_protocolo` FOREIGN KEY (`bbh_pro_codigo`) REFERENCES `bbh_protocolos` (`bbh_pro_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_indicio`
--

LOCK TABLES `bbh_indicio` WRITE;
/*!40000 ALTER TABLE `bbh_indicio` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_indicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_mensagens`
--

DROP TABLE IF EXISTS `bbh_mensagens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_mensagens` (
  `bbh_men_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_men_data_recebida` datetime DEFAULT NULL,
  `bbh_men_data_leitura` datetime DEFAULT NULL,
  `bbh_usu_codigo_remet` int(11) DEFAULT NULL,
  `bbh_usu_codigo_destin` int(11) DEFAULT NULL,
  `bbh_men_assunto` varchar(255) DEFAULT NULL,
  `bbh_men_mensagem` text,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  `bbh_men_exclusao_remetente` int(11) DEFAULT '0',
  `bbh_men_exclusao_destinatario` int(11) DEFAULT '0',
  PRIMARY KEY (`bbh_men_codigo`),
  KEY `bbh_usu_codigo_remet` (`bbh_usu_codigo_remet`),
  KEY `bbh_usu_codigo_destin` (`bbh_usu_codigo_destin`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_usu_codigo_destin` FOREIGN KEY (`bbh_usu_codigo_destin`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_codigo_remet` FOREIGN KEY (`bbh_usu_codigo_remet`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_mensagens`
--

LOCK TABLES `bbh_mensagens` WRITE;
/*!40000 ALTER TABLE `bbh_mensagens` DISABLE KEYS */;
INSERT INTO `bbh_mensagens` VALUES (1,'2017-05-22 11:29:07','2017-05-22 11:29:10',1,1,'','',NULL,0,0),(2,'2017-05-24 18:10:39','2017-05-24 18:11:04',2,1,'Eae mano','Eae mano!!!',23,0,0),(3,'2017-05-24 18:11:27',NULL,1,2,'','',NULL,0,0);
/*!40000 ALTER TABLE `bbh_mensagens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_atividade`
--

DROP TABLE IF EXISTS `bbh_modelo_atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_atividade` (
  `bbh_mod_ati_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_mod_flu_codigo` int(11) DEFAULT NULL,
  `bbh_mod_ati_nome` varchar(255) DEFAULT NULL,
  `bbh_mod_ati_observacao` text,
  `bbh_mod_ati_duracao` int(11) DEFAULT NULL,
  `bbh_mod_ati_inicio` int(11) DEFAULT NULL,
  `bbh_mod_ati_ordem` int(11) DEFAULT NULL,
  `bbh_mod_ati_atribuicao` int(11) DEFAULT NULL,
  `bbh_per_codigo` int(11) DEFAULT NULL,
  `bbh_mod_ati_mecanismo` int(11) DEFAULT '0',
  `bbh_mod_ati_icone` varchar(50) DEFAULT '3.gif',
  `bbh_mod_atiInicio` varchar(1) DEFAULT '0',
  `bbh_mod_atiFim` varchar(1) DEFAULT '0',
  `bbh_mod_ati_relatorio` char(1) DEFAULT '0',
  PRIMARY KEY (`bbh_mod_ati_codigo`),
  KEY `modelo_fluxo_modelo_atividade` (`bbh_mod_flu_codigo`),
  KEY `bbh_per_codigo` (`bbh_per_codigo`),
  CONSTRAINT `bbh_per_codigo` FOREIGN KEY (`bbh_per_codigo`) REFERENCES `bbh_perfil` (`bbh_per_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `modelo_fluxo_modelo_atividade` FOREIGN KEY (`bbh_mod_flu_codigo`) REFERENCES `bbh_modelo_fluxo` (`bbh_mod_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_atividade`
--

LOCK TABLES `bbh_modelo_atividade` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_atividade` DISABLE KEYS */;
INSERT INTO `bbh_modelo_atividade` VALUES (27,19,'Atividade 1','Esta é a atividade 1 e somente o Perfil  Supervisor - ISS pode visualizar.',1,1,1,NULL,18,0,'3.gif','1','1','0'),(28,20,'(ANTIGA NÃO USAR)Atividade 2','Esta é a atividade 2 e somente o Perfil  Analista - Comércio pode visualizar.',1,1,1,NULL,19,0,'3.gif','1','0','0'),(29,20,'(ANTIGA NÃO USAR)Atividade 3','Esta é a atividade 3 e somente o Perfil  Analista - Comércio pode visualizar.',1,1,2,NULL,19,0,'3.gif','0','0','0'),(30,20,'(ANTIGA NÃO USAR)Atividade 4','Esta é a atividade 4 e somente o Perfil  Supervisor - Comércio pode visualizar.',1,1,3,NULL,21,0,'3.gif','0','1','0'),(31,21,'Atividade 5','Esta é a atividade 5 e somente o Perfil  Analista de Produtos Químicos e Inflamáveis pode visualizar.',1,1,1,NULL,20,0,'3.gif','1','0','0'),(32,21,'Atividade 1','Esta é a atividade 1 e somente o Perfil  Supervisor - ISS pode visualizar.',1,1,2,NULL,18,0,'3.gif','0','0','0'),(33,21,'Atividade 2','Esta é a atividade 2 e somente o Perfil  Analista - Comércio pode visualizar.\nAqui se deve gerar um relatório obrigatório',1,1,3,NULL,19,0,'3.gif','0','0','0'),(34,21,'Atividade 6','Esta é a atividade 6 e somente o Perfil  Supervisor de Produtos Químicos e Inflamáveis pode visualizar.',1,1,4,NULL,22,0,'3.gif','0','1','0'),(35,23,'(ANTIGA NÃO USAR)Indeferimento - Processo Comércio - Ativ. 2','Está é a atividade para inferimento do Processo Comércio',1,1,1,NULL,31,0,'3.gif','1','0','0'),(36,24,'Indeferimento - Ativ. 5 - Processo Produtos Químicos e Inflamáveis','Está é a atividade para Indeferimento - Ativ. 5 - Processo Produtos Químicos e Inflamáveis',1,1,1,NULL,33,0,'3.gif','1','1','0'),(37,25,'Atividade 7','Esta é a atividade 7 e somente o Perfil  Analista - Comércio pode visualizar.',1,1,1,NULL,19,0,'3.gif','1','0','0'),(38,25,'Atividade 8','Esta é a atividade 8 e somente o Perfil  Analista de Produtos Químicos e Inflamáveis pode visualizar.',1,1,2,NULL,20,0,'3.gif','0','0','0'),(39,25,'Atividade 9','Esta é a atividade 9 e somente o Perfil  Analista - Comércio pode visualizar.',1,1,3,NULL,19,0,'1.gif','0','0','0'),(40,25,'Atividade 10','Esta é a atividade 10 e somente o Perfil  Supervisor de Produtos Químicos e Inflamáveis pode visualizar.',1,1,4,NULL,22,0,'3.gif','0','1','0'),(41,26,'Atividade 11','Esta é a atividade 11 e somente o Perfil  Supervisor - Comércio pode visualizar.',1,1,1,NULL,21,0,'3.gif','1','0','0'),(42,26,'Atividade 12','Esta é a atividade 12 e somente o Perfil  Supervisor - ISS pode visualizar.',1,1,2,NULL,18,0,'1.gif','0','1','0'),(43,27,'Atividade 13','Esta é a atividade 1 e somente o Perfil  Gerente Geral pode visualizar.',1,1,1,NULL,24,0,'3.gif','1','1','0'),(45,28,'Indeferimento - Ativ. 7 - Processo Diversificado','Indeferimento - Ativ. 7 - Processo Diversificado',1,1,1,NULL,36,0,'3.gif','1','1','0'),(47,23,'(ANTIGA NÃO USAR)Indeferimento - Processo Comércio - Ativ. 3','Esta é a atividade de Indeferimento - Processo Comércio - Ativ. 3',1,1,2,NULL,32,0,'3.gif','1','1','0'),(48,24,'Indeferimento - Ativ. 1 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 1 - Processo Produtos Químicos e Inflamáveis',1,1,2,NULL,34,0,'3.gif','1','1','0'),(49,24,'Indeferimento - Ativ. 2 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 2 - Processo Produtos Químicos e Inflamáveis',1,1,3,NULL,35,0,'3.gif','1','1','0'),(50,28,'Indeferimento - Ativ. 8 - Processo Diversificado','Indeferimento - Ativ. 8 - Processo Diversificado',1,1,2,NULL,37,0,'3.gif','1','1','0'),(51,28,'Indeferimento - Ativ. 9 - Processo Diversificado','Indeferimento - Ativ. 9 - Processo Diversificado',1,1,3,NULL,38,0,'3.gif','1','1','0'),(52,28,'Indeferimento - Ativ. 11 - Processo Diversificado','Indeferimento - Ativ. 11 - Processo Diversificado',1,1,4,NULL,39,0,'3.gif','1','1','0'),(53,29,'Atividade 2','Atividade 2',1,1,1,NULL,19,0,'3.gif','1','0','0'),(54,29,'Atividade 3','Atividade 3',1,1,2,NULL,19,0,'3.gif','0','0','0'),(55,29,'Atividade 4 ','Atividade 4',1,1,3,NULL,21,0,'3.gif','0','1','0'),(56,30,'Indeferimento Processo Comércio - Atividade 2','Indeferimento Processo Comércio - Atividade 2',1,1,1,NULL,31,0,'3.gif','1','1','0'),(57,31,'Indeferimento Processo Comércio - Atividade 3','Indeferimento Processo Comércio - Atividade 3',1,1,1,NULL,32,0,'3.gif','1','1','0');
/*!40000 ALTER TABLE `bbh_modelo_atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo` (
  `bbh_mod_flu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_tip_flu_codigo` int(11) DEFAULT NULL,
  `bbh_mod_flu_nome` varchar(255) DEFAULT NULL,
  `bbh_mod_flu_observacao` text,
  `bbh_mod_flu_sub` char(1) DEFAULT '0',
  PRIMARY KEY (`bbh_mod_flu_codigo`),
  KEY `bbh_modelo_fluxo_bbh_tipo_fluxo` (`bbh_tip_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_bbh_tipo_fluxo` FOREIGN KEY (`bbh_tip_flu_codigo`) REFERENCES `bbh_tipo_fluxo` (`bbh_tip_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo`
--

LOCK TABLES `bbh_modelo_fluxo` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo` VALUES (19,18,'Processo ISS','Modelo desenvolvido para Processo ISS','0'),(20,19,'(ANTIGA NÃO USAR)Processo Comércio','(ANTIGO)Modelo desenvolvido para Processo Comércio','0'),(21,20,'Processo Produtos Químicos e Inflamáveis','Modelo desenvolvido para Processo Produtos Químicos e Inflamáveis','0'),(22,21,'INATIVO','INATIVO','1'),(23,21,'(ANTIGA NÃO USAR)Indeferimento Processo Comércio','(ANTIGA NÃO USAR)Este modelo de processo foi desenhado para indeferimento do Processo Comércio quando a atividade ainda não é a atividade final.','1'),(24,21,'Indeferimento Processo Produtos Químicos e Inflamáveis','Este modelo de processo foi desenhado para indeferimento do Processo  Produtos Químicos e Inflamáveis quando a atividade ainda não é a atividade final.','1'),(25,22,'Processo Diversificado','Tipo de processo desenhado para processos diversificados.','0'),(26,22,'Sub Processo Diversificado 1','Modelo desenvolvido para Processo Diversificado 1','1'),(27,22,'Sub Processo Diversificado 2','Modelo desenvolvido para Sub Processo Diversificado 2','1'),(28,21,'Indeferimento Processo Diversificado','Este modelo de processo foi desenhado para indeferimento Diversificado quando a atividade ainda não é a atividade final.','1'),(29,23,'Processo Comércio','Processo Comércio','0'),(30,21,'Indeferimento Processo Comércio - Atividade 2','Indeferimento Processo Comércio - Atividade 2','1'),(31,21,'Indeferimento Processo Comércio - Atividade 3','Indeferimento Processo Comércio - Atividade 3','1');
/*!40000 ALTER TABLE `bbh_modelo_fluxo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_19_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_19_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_19_detalhado` (
  `bbh_mod_flu_19_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_19_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_19_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_19_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_19_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_19_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_19_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_19_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_19_detalhado` VALUES (15,'Indeferida','não atendeu a lei 123456',30),(16,'Deferida','Atendeu a lei 123456',29),(17,'Deferida','estou indeferindo o processo ISS',43),(18,'Deferida','estou deferindo aqui',44),(19,'Indeferida','aqui indeferida',45),(20,'Deferida','deferida',46),(21,'Indeferida','indeferida aqui',47),(22,'Deferida','estou deferindo',54),(23,'Deferida','Atendeu a lei...',55),(24,'Deferida','Esse processo foi deferido em 13/09/2017',64);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_19_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_20_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_20_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_20_detalhado` (
  `bbh_mod_flu_20_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_20_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_20_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_20_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_20_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_20_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_20_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_20_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_20_detalhado` VALUES (14,'Deferida','deferi aqui',52),(15,'Indeferida','...',56),(16,'Deferida','aaa',57),(17,'Deferida','Todos os dados foram validados e estão de acordo, sendo assim a solicitação foi deferida.',58),(18,'Deferida','ADASDASDASD',61);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_20_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_21_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_21_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_21_detalhado` (
  `bbh_mod_flu_21_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_21_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_21_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_21_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_21_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_21_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_21_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_21_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_21_detalhado` VALUES (13,'Deferida','Deferindo processo produtos quimicos',33);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_21_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_22_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_22_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_22_detalhado` (
  `bbh_mod_flu_22_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_22_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_22_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_22_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_22_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_22_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_22_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_22_detalhado` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_22_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_23_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_23_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_23_detalhado` (
  `bbh_mod_flu_23_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_23_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_23_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_23_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_23_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_23_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_23_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_23_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_23_detalhado` VALUES (14,'Indeferida','Finalizando atividade de indeferimento processo comercio, aqui a atividade que escolheu por indeferir, foi a atividade 3 (carlos.sena), porem ao escoher para quem ia a atividade de indeferimento, foi escolhido o (bruno.azevedo)...',32),(15,'Indeferida','',60);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_23_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_24_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_24_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_24_detalhado` (
  `bbh_mod_flu_24_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_24_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_24_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_24_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_24_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_24_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_24_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_24_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_24_detalhado` VALUES (13,'Indeferida','não quis devefir',50),(14,'Indeferida','indeferi !!!',53);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_24_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_25_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_25_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_25_detalhado` (
  `bbh_mod_flu_25_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_25_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_25_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_25_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_25_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_25_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_25_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_25_detalhado` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_25_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_26_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_26_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_26_detalhado` (
  `bbh_mod_flu_26_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_26_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_26_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_26_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_26_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_26_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_26_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_26_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_26_detalhado` VALUES (13,'Deferida','Preenchi os campos de indeferimento da atividade 12, antes de chegar na atividade 12, neste momento a solicitação está na atividade 11 do subfluxo 1 do processo diversificado\nNo campo analise, eu preenchi como Deferida.',35),(14,'Deferida','marquei como deferida e estou enviando para o subfluxo 2',41);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_26_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_27_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_27_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_27_detalhado` (
  `bbh_mod_flu_27_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_27_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_27_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_27_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_27_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_27_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_27_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_27_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_27_detalhado` VALUES (13,'Indeferida','Aqui eu estou indeferindo o subprocesso 2 no perfil do fabio.faria',42);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_27_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_28_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_28_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_28_detalhado` (
  `bbh_mod_flu_28_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_28_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_28_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_28_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_28_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_28_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_28_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_28_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_28_detalhado` VALUES (13,'Indeferida','aqui eu indeferi o processo diversificado na atividade 11, mas na atividade 12, msm sem ter chegado nela, eu preenchi as informações como deferida',36),(14,'Indeferida','indeferi na atividade 11',39);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_28_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_29_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_29_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_29_detalhado` (
  `bbh_mod_flu_29_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_29_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_29_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_29_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_29_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_29_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_29_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_29_detalhado` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_29_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_30_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_30_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_30_detalhado` (
  `bbh_mod_flu_30_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_30_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_30_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_30_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_30_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_30_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_30_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_30_detalhado` DISABLE KEYS */;
INSERT INTO `bbh_modelo_fluxo_30_detalhado` VALUES (13,'Indeferida','Estou indeferindo a solicitação, pois os dados de endereço não são compatíveis para o CNAE desejado.',63);
/*!40000 ALTER TABLE `bbh_modelo_fluxo_30_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_fluxo_31_detalhado`
--

DROP TABLE IF EXISTS `bbh_modelo_fluxo_31_detalhado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_fluxo_31_detalhado` (
  `bbh_mod_flu_31_det_codigo_pk` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_cam_det_31_anaalise` varchar(255) DEFAULT NULL,
  `bbh_cam_det_31_motivo` blob,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_mod_flu_31_det_codigo_pk`),
  KEY `bbh_flu_codigo` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_modelo_fluxo_31_detalhado_ibfk_1` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_fluxo_31_detalhado`
--

LOCK TABLES `bbh_modelo_fluxo_31_detalhado` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_31_detalhado` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_modelo_fluxo_31_detalhado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_modelo_paragrafo`
--

DROP TABLE IF EXISTS `bbh_modelo_paragrafo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_modelo_paragrafo` (
  `bbh_mod_par_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_mod_par_nome` varchar(255) DEFAULT NULL,
  `bbh_mod_par_titulo` varchar(255) DEFAULT NULL,
  `bbh_mod_par_paragrafo` text,
  `bbh_mod_flu_codigo` int(11) DEFAULT NULL,
  `bbh_mod_par_privado` char(1) DEFAULT '0',
  `bbh_usu_autor` int(11) DEFAULT NULL,
  `bbh_adm_codigo` int(11) DEFAULT NULL,
  `bbh_mod_par_momento` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`bbh_mod_par_codigo`),
  KEY `bbh_mod_flu_codigo_paragrafo` (`bbh_mod_flu_codigo`),
  CONSTRAINT `bbh_mod_flu_codigo_paragrafo` FOREIGN KEY (`bbh_mod_flu_codigo`) REFERENCES `bbh_modelo_fluxo` (`bbh_mod_flu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_modelo_paragrafo`
--

LOCK TABLES `bbh_modelo_paragrafo` WRITE;
/*!40000 ALTER TABLE `bbh_modelo_paragrafo` DISABLE KEYS */;
INSERT INTO `bbh_modelo_paragrafo` VALUES (4,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  --INICIO DO TESTE RELATORIO--<br />  Abaixo NOME/CURINGA<br />  <br />  Análise&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-analise<br />  Motivo&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-motivo<br />  <br />  <br />  <br />  Assunto/Empresa&nbsp;&nbsp; &nbsp;@bbh_pro_assunto@<br />  Observações&nbsp;&nbsp; &nbsp;@bbh_pro_descricao@<br />  Processo&nbsp;&nbsp; &nbsp;@bbh_pro_identificacao@<br />  Prazo&nbsp;&nbsp; &nbsp;@bbh_pro_prazo@<br />  Flagrante&nbsp;&nbsp; &nbsp;@bbh_pro_flagrante@<br />  Solicitante&nbsp;&nbsp; &nbsp;@bbh_pro_solicitante<br />  Unidade&nbsp;&nbsp; &nbsp;@bbh_uni_codigo@<br />  Dados empresa&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-empresa<br />  Recebimento confirmado&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-confirmaRecebimento<br />  Sincronizado Junta Comercial&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-empresa-sincronizado<br />  Situação analise endereço&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-analise-endereco<br />  Resposta analise&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-analise-endereco-motivo</p>  <p>   </p>  <p>  --INICIO DO TESTE RELATORIO--</p> 	   ',21,'0',NULL,1,'2017-06-01 13:43:53'),(5,'Modelo relatório pré definido - Processo Comércio','Modelo relatório pré definido - Processo Comércio','  	      	  	   <p>  --INICIO DO TESTE RELATORIO--<br />  <br />  <br />  Análise&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-analise</p>  <p>  Motivo&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-motivo<br />  <br />  <br />  <br />  Assunto/Empresa&nbsp;&nbsp; &nbsp;@bbh_pro_assunto@</p>  <p>  Observações&nbsp;&nbsp; &nbsp;@bbh_pro_descricao@</p>  <p>  Processo&nbsp;&nbsp; &nbsp;@bbh_pro_identificacao@</p>  <p>  Prazo&nbsp;&nbsp; &nbsp;@bbh_pro_prazo@</p>  <p>  Flagrante&nbsp;&nbsp; &nbsp;@bbh_pro_flagrante@</p>  <p>  Solicitante&nbsp;&nbsp; &nbsp;@bbh_pro_solicitante</p>  <p>  Unidade&nbsp;&nbsp; &nbsp;@bbh_uni_codigo@</p>  <p>  Dados empresa&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-empresa</p>  <p>  Recebimento confirmado&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-confirmaRecebimento</p>  <p>  Sincronizado Junta Comercial&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-empresa-sincronizado</p>  <p>  Situação analise endereço&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-analise-endereco</p>  <p>  Resposta analise&nbsp;&nbsp; &nbsp;@rede-simples-viabilidade-analise-endereco-motivo</p>  <p>   </p>  <p>  --FIM DO TESTE RELATORIO--</p> 	   ',20,'0',NULL,1,'2017-06-07 10:48:57');
/*!40000 ALTER TABLE `bbh_modelo_paragrafo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_paragrafo`
--

DROP TABLE IF EXISTS `bbh_paragrafo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_paragrafo` (
  `bbh_par_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_par_titulo` varchar(255) DEFAULT NULL,
  `bbh_par_paragrafo` text,
  `bbh_rel_codigo` int(11) NOT NULL,
  `bbh_mod_par_codigo` int(11) DEFAULT NULL,
  `bbh_par_ordem` int(11) DEFAULT NULL,
  `bbh_par_momento` date DEFAULT NULL,
  `bbh_par_autor` varchar(100) DEFAULT NULL,
  `bbh_par_arquivo` varchar(255) DEFAULT NULL,
  `bbh_par_nmArquivo` varchar(100) DEFAULT NULL,
  `bbh_par_legenda` text,
  `bbh_par_tipo_anexo` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`bbh_par_codigo`),
  KEY `bbh_relatorio` (`bbh_rel_codigo`),
  CONSTRAINT `bbh_relatorio` FOREIGN KEY (`bbh_rel_codigo`) REFERENCES `bbh_relatorio` (`bbh_rel_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_paragrafo`
--

LOCK TABLES `bbh_paragrafo` WRITE;
/*!40000 ALTER TABLE `bbh_paragrafo` DISABLE KEYS */;
INSERT INTO `bbh_paragrafo` VALUES (14,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  Abaixo NOME/CURINGA<br />  <br />  <br />  Número do protocolo &nbsp;&nbsp; &nbsp;@#numprotocolo<br />  Solicitante &nbsp;&nbsp; &nbsp;@#solicitante<br />  Oficio &nbsp;&nbsp; &nbsp;@#oficio<br />  Departamento &nbsp;&nbsp; &nbsp;@#departamento<br />  Data do ofício &nbsp;&nbsp; &nbsp;@#dtoficio<br />  Data do cadastro &nbsp;&nbsp; &nbsp;@#dtcadastro<br />  Flagrante &nbsp;&nbsp; &nbsp;@#flagrante<br />  Conteúdo do ofício &nbsp;&nbsp; &nbsp;@#conteudo<br />  Recebido por &nbsp;&nbsp; &nbsp;@#recebidopor<br />  Data de recebimento &nbsp;&nbsp; &nbsp;@#dtrecebimento<br />  Autoridade solicitante &nbsp;&nbsp; &nbsp;@#autoridadesolic<br />  Número do processo &nbsp;&nbsp; &nbsp;##@numeroprocesso<br />  Profissional responsavel &nbsp;&nbsp; &nbsp;##@profresponsavel</p>  <p>   </p>  <p>  Análise <span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  Motivo <span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p> 	   ',4,4,6,'2017-06-01','Administrador',NULL,NULL,NULL,NULL),(15,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  Abaixo NOME/CURINGA<br />  <br />  <br />  Número do protocolo &nbsp;&nbsp; &nbsp;@#numprotocolo<br />  Solicitante &nbsp;&nbsp; &nbsp;@#solicitante<br />  Oficio &nbsp;&nbsp; &nbsp;@#oficio<br />  Departamento &nbsp;&nbsp; &nbsp;@#departamento<br />  Data do ofício &nbsp;&nbsp; &nbsp;@#dtoficio<br />  Data do cadastro &nbsp;&nbsp; &nbsp;@#dtcadastro<br />  Flagrante &nbsp;&nbsp; &nbsp;@#flagrante<br />  Conteúdo do ofício &nbsp;&nbsp; &nbsp;@#conteudo<br />  Recebido por &nbsp;&nbsp; &nbsp;@#recebidopor<br />  Data de recebimento &nbsp;&nbsp; &nbsp;@#dtrecebimento<br />  Autoridade solicitante &nbsp;&nbsp; &nbsp;@#autoridadesolic<br />  Número do processo &nbsp;&nbsp; &nbsp;##@numeroprocesso<br />  Profissional responsavel &nbsp;&nbsp; &nbsp;##@profresponsavel</p> 	   ',4,4,7,'2017-06-01','Administrador',NULL,NULL,NULL,NULL),(17,'','---',5,NULL,1,'2017-06-02','',NULL,NULL,NULL,NULL),(19,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  Abaixo NOME/CURINGA<br />  <br />  <br />  Número do protocolo &nbsp;&nbsp; &nbsp;@#numprotocolo<br />  Solicitante &nbsp;&nbsp; &nbsp;@#solicitante<br />  Oficio &nbsp;&nbsp; &nbsp;@#oficio<br />  Departamento &nbsp;&nbsp; &nbsp;@#departamento<br />  Data do ofício &nbsp;&nbsp; &nbsp;@#dtoficio<br />  Data do cadastro &nbsp;&nbsp; &nbsp;@#dtcadastro<br />  Flagrante &nbsp;&nbsp; &nbsp;@#flagrante<br />  Conteúdo do ofício &nbsp;&nbsp; &nbsp;@#conteudo<br />  Recebido por &nbsp;&nbsp; &nbsp;@#recebidopor<br />  Data de recebimento &nbsp;&nbsp; &nbsp;@#dtrecebimento<br />  Autoridade solicitante &nbsp;&nbsp; &nbsp;@#autoridadesolic<br />  Número do processo &nbsp;&nbsp; &nbsp;##@numeroprocesso<br />  Profissional responsavel &nbsp;&nbsp; &nbsp;##@profresponsavel</p> 	   ',5,4,3,'2017-06-02','Administrador',NULL,NULL,NULL,NULL),(20,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  Abaixo NOME/CURINGA<br />  <br />  <br />  Número do protocolo &nbsp;&nbsp; &nbsp;@#numprotocolo<br />  Solicitante &nbsp;&nbsp; &nbsp;@#solicitante<br />  Oficio &nbsp;&nbsp; &nbsp;@#oficio<br />  Departamento &nbsp;&nbsp; &nbsp;@#departamento<br />  Data do ofício &nbsp;&nbsp; &nbsp;@#dtoficio<br />  Data do cadastro &nbsp;&nbsp; &nbsp;@#dtcadastro<br />  Flagrante &nbsp;&nbsp; &nbsp;@#flagrante<br />  Conteúdo do ofício &nbsp;&nbsp; &nbsp;@#conteudo<br />  Recebido por &nbsp;&nbsp; &nbsp;@#recebidopor<br />  Data de recebimento &nbsp;&nbsp; &nbsp;@#dtrecebimento<br />  Autoridade solicitante &nbsp;&nbsp; &nbsp;@#autoridadesolic<br />  Número do processo &nbsp;&nbsp; &nbsp;##@numeroprocesso<br />  Profissional responsavel &nbsp;&nbsp; &nbsp;##@profresponsavel</p> 	   ',5,4,4,'2017-06-02','Administrador',NULL,NULL,NULL,NULL),(21,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  Abaixo NOME/CURINGA<br />  <br />  <br />  Número do protocolo &nbsp;&nbsp; &nbsp;@#numprotocolo<br />  Solicitante &nbsp;&nbsp; &nbsp;@#solicitante<br />  Oficio &nbsp;&nbsp; &nbsp;@#oficio<br />  Departamento &nbsp;&nbsp; &nbsp;@#departamento<br />  Data do ofício &nbsp;&nbsp; &nbsp;@#dtoficio<br />  Data do cadastro &nbsp;&nbsp; &nbsp;@#dtcadastro<br />  Flagrante &nbsp;&nbsp; &nbsp;@#flagrante<br />  Conteúdo do ofício &nbsp;&nbsp; &nbsp;@#conteudo<br />  Recebido por &nbsp;&nbsp; &nbsp;@#recebidopor<br />  Data de recebimento &nbsp;&nbsp; &nbsp;@#dtrecebimento<br />  Autoridade solicitante &nbsp;&nbsp; &nbsp;@#autoridadesolic<br />  Número do processo &nbsp;&nbsp; &nbsp;##@numeroprocesso<br />  Profissional responsavel &nbsp;&nbsp; &nbsp;##@profresponsavel</p> 	   ',5,4,5,'2017-06-02','Administrador',NULL,NULL,NULL,NULL),(22,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  Abaixo NOME/CURINGA<br />  <br />  <br />  Número do protocolo &nbsp;&nbsp; &nbsp;@#numprotocolo<br />  Solicitante &nbsp;&nbsp; &nbsp;@#solicitante<br />  Oficio &nbsp;&nbsp; &nbsp;@#oficio<br />  Departamento &nbsp;&nbsp; &nbsp;@#departamento<br />  Data do ofício &nbsp;&nbsp; &nbsp;@#dtoficio<br />  Data do cadastro &nbsp;&nbsp; &nbsp;@#dtcadastro<br />  Flagrante &nbsp;&nbsp; &nbsp;@#flagrante<br />  Conteúdo do ofício &nbsp;&nbsp; &nbsp;@#conteudo<br />  Recebido por &nbsp;&nbsp; &nbsp;@#recebidopor<br />  Data de recebimento &nbsp;&nbsp; &nbsp;@#dtrecebimento<br />  Autoridade solicitante &nbsp;&nbsp; &nbsp;@#autoridadesolic<br />  Número do processo &nbsp;&nbsp; &nbsp;##@numeroprocesso<br />  Profissional responsavel &nbsp;&nbsp; &nbsp;##@profresponsavel</p>  <p>   </p>  <p>  Análise <span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  Motivo <span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p> 	   ',4,NULL,8,'2017-06-02','Bruno Azevedo',NULL,NULL,NULL,NULL),(27,'teste logado usuário comum','  	      	  	   <p>  inicio teste logado</p>  <p>   </p>  <p>  Análise<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  Motivo<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>   </p>  <p>   </p>  <p>   </p>  <p>  Assunto/Empresa<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>Rede Simples</p>  <p>  Observações<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  Processo<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>RSP1700385101</p>  <p>  Prazo<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>2017-05-19</p>  <p>  Flagrante<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>Não</p>  <p>  Solicitante<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  Unidade<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>INATIVO</p>  <p>  Dados empresa<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310140`,`logradouro`:`RUA ANGELO POSSEBON`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 12`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`02`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385101`}}</p>  <p>  Recebimento confirmado<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>Sim</p>  <p>  Sincronizado Junta Comercial<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310140`,`logradouro`:`RUA ANGELO POSSEBON`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 12`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`02`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385101`}}-sincronizado</p>  <p>  Situação analise endereço<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  Resposta analise<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>-motivo</p>  <p>   </p>  <p>  fim teste logado...</p>   ',6,NULL,5,'2017-06-05','Bruno Azevedo',NULL,NULL,NULL,NULL),(32,'Relatório de atividade 2 - Processo Produtos Químicos e Inflamáveis','  	      	  	   <p>  INICIO Relatório pré definido teste<br />  Abaixo NOME/CURINGA<br />  <br />  Análise&nbsp;&nbsp; &nbsp;<br />  Motivo&nbsp;&nbsp; &nbsp;<br />  <br />  <br />  <br />  Assunto/Empresa&nbsp;&nbsp; &nbsp;Rede Simples<br />  Observações&nbsp;&nbsp; &nbsp;<br />  Processo&nbsp;&nbsp; &nbsp;RSP1700385101<br />  Prazo&nbsp;&nbsp; &nbsp;2017-05-19<br />  Flagrante&nbsp;&nbsp; &nbsp;Não<br />  Solicitante&nbsp;&nbsp; &nbsp;<br />  Unidade&nbsp;&nbsp; &nbsp;INATIVO<br />  Dados empresa&nbsp;&nbsp; &nbsp;{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310140`,`logradouro`:`RUA ANGELO POSSEBON`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 12`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`02`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385101`}}<br />  Recebimento confirmado&nbsp;&nbsp; &nbsp;Sim<br />  Sincronizado Junta Comercial&nbsp;&nbsp; &nbsp;{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92310140`,`logradouro`:`RUA ANGELO POSSEBON`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 12`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:{`attributes`:{`codigo`:`02`}},`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385101`}}-sincronizado<br />  Situação analise endereço&nbsp;&nbsp; &nbsp;<br />  Resposta analise&nbsp;&nbsp; &nbsp;-motivo</p>  <p>   </p>  <p>  FIM relatorio pre definido</p> 	   ',6,4,6,'2017-06-05','Administrador',NULL,NULL,NULL,NULL),(39,'Aqui é o titulo em texto com editor','  	      	  	   <p>  Aqui é o corpo da msg do texto com editor<br />  <br />  Iniciando teste</p>  <p>  &nbsp;Assunto/Empresa<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>Rede Simples</p>  <p>  &nbsp;Observações<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  &nbsp;Processo<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>RSP1700385103</p>  <p>  &nbsp;Prazo<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>2017-05-22</p>  <p>  &nbsp;Flagrante<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>Não</p>  <p>  &nbsp;Solicitante<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  &nbsp;Unidade<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>INATIVO</p>  <p>  &nbsp;Dados empresa<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92010030`,`logradouro`:`RUA ANGUSTURA`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 13`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385103`}}</p>  <p>  &nbsp;Recebimento confirmado<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>Sim</p>  <p>  &nbsp;Sincronizado Junta Comercial<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92010030`,`logradouro`:`RUA ANGUSTURA`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 13`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385103`}}-sincronizado</p>  <p>  &nbsp;Situação analise endereço<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>-endereco</p>  <p>  &nbsp;Resposta analise<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span>-endereco-motivo</p>  <p>   </p>  <p>  &nbsp;Análise<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <p>  &nbsp;Motivo<span class=\"Apple-tab-span\" style=\"white-space:pre\"> </span></p>  <div>   </div>  <div>  Finalizando teste ...</div> 	   ',7,NULL,6,'2017-06-07','André Luis','39.gif','39.gif','teste 1',NULL),(40,'Modelo relatório pré definido - Processo Comércio','  	      	  	   <p>  --INICIO DO TESTE RELATORIO--<br />  <br />  <br />  Análise&nbsp;&nbsp; &nbsp;</p>  <p>  Motivo&nbsp;&nbsp; &nbsp;<br />  <br />  <br />  <br />  Assunto/Empresa&nbsp;&nbsp; &nbsp;Rede Simples</p>  <p>  Observações&nbsp;&nbsp; &nbsp;</p>  <p>  Processo&nbsp;&nbsp; &nbsp;RSP1700385103</p>  <p>  Prazo&nbsp;&nbsp; &nbsp;2017-05-22</p>  <p>  Flagrante&nbsp;&nbsp; &nbsp;Não</p>  <p>  Solicitante&nbsp;&nbsp; &nbsp;</p>  <p>  Unidade&nbsp;&nbsp; &nbsp;INATIVO</p>  <p>  Dados empresa&nbsp;&nbsp; &nbsp;{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92010030`,`logradouro`:`RUA ANGUSTURA`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 13`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385103`}}</p>  <p>  Recebimento confirmado&nbsp;&nbsp; &nbsp;Sim</p>  <p>  Sincronizado Junta Comercial&nbsp;&nbsp; &nbsp;{`municipio`:{`attributes`:{`codigoRFB`:`8589`}},`naturezaJuridica`:{`attributes`:{`codigo`:`2062`}},`tipoEnquadramento`:`MICRO_EMPRESA`,`evento`:{`attributes`:{`codigo`:`101`}},`resultadoClassificacao`:[],`orgaoRegistro`:{`attributes`:{`codigo`:`1`,`nome`:`Junta Comercial`}},`requerente`:{`login`:`33390216863`,`nome`:`URIEL JADI SPADA BRITO`,`email`:`uriel.brito@longevo.com.br`,`dddTelefone`:`13`,`telefone`:`99999999`},`coleta`:{`coletaEndereco`:{`areaTotalEmpreendimento`:`1.0`,`areaUtilizada`:`1.0`,`endereco`:{`numeroCep`:`92010030`,`logradouro`:`RUA ANGUSTURA`,`numeroLogradouro`:`1`,`bairro`:`CENTRO`}},`coletaObjetoSocial`:{`objetoSocial`:`TESTE 13`},`coletaAtividadeEconomica`:{`atividadeEconomica`:{`attributes`:{`cnae`:`6201501`}},`attributes`:{`tipoAtividadeEconomica`:`P`,`exercidaNoLocal`:`true`}},`coletaTipoUnidadeFormaAtuacao`:[{`attributes`:{`codigo`:`01`}},{`attributes`:{`codigo`:`04`}},{`attributes`:{`codigo`:`07`}}],`codigoTipoUnidade`:`PRODUTIVA`},`attributes`:{`numeroProtocolo`:`RSP1700385103`}}-sincronizado</p>  <p>  Situação analise endereço&nbsp;&nbsp; &nbsp;-endereco</p>  <p>  Resposta analise&nbsp;&nbsp; &nbsp;-endereco-motivo</p>  <p>   </p>  <p>  --FIM DO TESTE RELATORIO--</p> 	   ',7,5,6,'2017-06-07','Administrador',NULL,NULL,NULL,NULL),(42,'','---',8,NULL,1,'2017-06-12','',NULL,NULL,NULL,NULL),(44,'ScreenHunter_48 Jun. 08 16.30','',9,NULL,2,'2017-06-13','André Luis','44.gif','44.gif','ScreenHunter_48 Jun. 08 16.30',''),(45,'Bl@ck_arquivo_ANEXO*~','teste',9,NULL,3,'2017-06-13','André Luis','45.pdf','45.pdf','teste','pdf.gif'),(46,'teste logado usuário comum','  	      	  	   <p>  teste</p> 	   ',9,NULL,4,'2017-06-13','André Luis',NULL,NULL,NULL,NULL),(48,'Modelo relatório pré definido - Processo Comércio','  	      	  	   <p>  --INICIO DO TESTE RELATORIO--<br />  <br />  <br />  Análise&nbsp;&nbsp; &nbsp;Deferida</p>  <p>  Motivo&nbsp;&nbsp; &nbsp;<br />  <br />  <br />  <br />  Assunto/Empresa&nbsp;&nbsp; &nbsp;Rede Simples</p>  <p>  Observações&nbsp;&nbsp; &nbsp;</p>  <p>  Processo&nbsp;&nbsp; &nbsp;RSP1700385106</p>  <p>  Prazo&nbsp;&nbsp; &nbsp;2017-05-22</p>  <p>  Flagrante&nbsp;&nbsp; &nbsp;Não</p>  <p>  Solicitante&nbsp;&nbsp; &nbsp;</p>  <p>  Unidade&nbsp;&nbsp; &nbsp;INATIVO</p>  <p>  Dados empresa&nbsp;&nbsp; &nbsp;<div style=\"margin-top: 3px;teste2\"><strong>Município: </strong>8589</div><div style=\"margin-top: 3px;teste2\"><strong>Natureza jurídica: </strong>SOCIEDADE EMPRESARIA LIMITADA</div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de enquadramento: </strong>MICRO_EMPRESA</div><div style=\"margin-top: 3px;teste2\"><strong>Evento: </strong>Inscrição de primeiro estabelecimento</div><div style=\"margin-top: 3px;teste2\"><strong>Resultado classificação: </strong>-</div><div style=\"margin-top: 3px;teste2\"><strong>Órgão registro: </strong>1 - Junta Comercial</div><div style=\"margin-top: 3px;teste\"><strong>Requerente: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Login: </strong>33390216863</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Nome: </strong>URIEL JADI SPADA BRITO</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Email: </strong>uriel.brito@longevo.com.br</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Telefone: </strong>13 99999999</div></div><div style=\"margin-top: 3px;teste\"><strong>Endereço: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Logradouro: </strong>RUA ALMERINDO SILVEIRA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Número: </strong>1</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CEP: </strong>92025814</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Bairro: </strong>ESTANCIA VELHA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área total do empreendimento: </strong>1.0</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área utilizada: </strong>1.0</div></div><div style=\"margin-top: 3px;teste2\"><strong>Objeto social: </strong>TESTE 15</div><div style=\"margin-top: 3px;teste\"><strong>Atividades: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CNAE: 6201501: </strong>Principal - exercida no local: Sim</div></div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de unidade: </strong>PRODUTIVA</div><div style=\"margin-top: 3px;teste\"><strong>Forma de atuação: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>1: </strong>Estabelecimento fixo</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>5: </strong>Porta a Porta, Postos Móveis ou por Ambulantes</div></div><div style=\"margin-top: 3px;teste2\"><strong>Número do protocolo: </strong>RSP1700385106</div></p>  <p>  Recebimento confirmado&nbsp;&nbsp; &nbsp;Sim</p>  <p>  Sincronizado Junta Comercial&nbsp;&nbsp; &nbsp;<div style=\"margin-top: 3px;teste2\"><strong>Município: </strong>8589</div><div style=\"margin-top: 3px;teste2\"><strong>Natureza jurídica: </strong>SOCIEDADE EMPRESARIA LIMITADA</div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de enquadramento: </strong>MICRO_EMPRESA</div><div style=\"margin-top: 3px;teste2\"><strong>Evento: </strong>Inscrição de primeiro estabelecimento</div><div style=\"margin-top: 3px;teste2\"><strong>Resultado classificação: </strong>-</div><div style=\"margin-top: 3px;teste2\"><strong>Órgão registro: </strong>1 - Junta Comercial</div><div style=\"margin-top: 3px;teste\"><strong>Requerente: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Login: </strong>33390216863</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Nome: </strong>URIEL JADI SPADA BRITO</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Email: </strong>uriel.brito@longevo.com.br</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Telefone: </strong>13 99999999</div></div><div style=\"margin-top: 3px;teste\"><strong>Endereço: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Logradouro: </strong>RUA ALMERINDO SILVEIRA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Número: </strong>1</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CEP: </strong>92025814</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Bairro: </strong>ESTANCIA VELHA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área total do empreendimento: </strong>1.0</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área utilizada: </strong>1.0</div></div><div style=\"margin-top: 3px;teste2\"><strong>Objeto social: </strong>TESTE 15</div><div style=\"margin-top: 3px;teste\"><strong>Atividades: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CNAE: 6201501: </strong>Principal - exercida no local: Sim</div></div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de unidade: </strong>PRODUTIVA</div><div style=\"margin-top: 3px;teste\"><strong>Forma de atuação: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>1: </strong>Estabelecimento fixo</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>5: </strong>Porta a Porta, Postos Móveis ou por Ambulantes</div></div><div style=\"margin-top: 3px;teste2\"><strong>Número do protocolo: </strong>RSP1700385106</div>-sincronizado</p>  <p>  Situação analise endereço&nbsp;&nbsp; &nbsp;Deferida-endereco</p>  <p>  Resposta analise&nbsp;&nbsp; &nbsp;Deferida-endereco-motivo</p>  <p>   </p>  <p>  --FIM DO TESTE RELATORIO--</p> 	   ',9,5,6,'2017-06-13','Administrador',NULL,NULL,NULL,NULL),(49,'Bl@ck_quebra_LINHA*~','---',9,NULL,5,'2017-06-13','André Luis',NULL,NULL,NULL,NULL),(50,'Bl@ck_quebra_LINHA*~','---',10,NULL,1,'2017-06-13','André Luis',NULL,NULL,NULL,NULL),(51,'ScreenHunter_48 Jun. 08 16.30','',10,NULL,2,'2017-06-13','André Luis','44.gif','44.gif','ScreenHunter_48 Jun. 08 16.30',''),(52,'Bl@ck_arquivo_ANEXO*~','teste',10,NULL,3,'2017-06-13','André Luis','45.pdf','45.pdf','teste','pdf.gif'),(53,'teste logado usuário comum','  	      	  	   <p>  teste</p> 	   ',10,NULL,4,'2017-06-13','André Luis',NULL,NULL,NULL,NULL),(54,'Modelo relatório pré definido - Processo Comércio','  	      	  	   <p>  --INICIO DO TESTE RELATORIO--<br />  <br />  <br />  Análise&nbsp;&nbsp; &nbsp;Deferida</p>  <p>  Motivo&nbsp;&nbsp; &nbsp;<br />  <br />  <br />  <br />  Assunto/Empresa&nbsp;&nbsp; &nbsp;Rede Simples</p>  <p>  Observações&nbsp;&nbsp; &nbsp;</p>  <p>  Processo&nbsp;&nbsp; &nbsp;RSP1700385106</p>  <p>  Prazo&nbsp;&nbsp; &nbsp;2017-05-22</p>  <p>  Flagrante&nbsp;&nbsp; &nbsp;Não</p>  <p>  Solicitante&nbsp;&nbsp; &nbsp;</p>  <p>  Unidade&nbsp;&nbsp; &nbsp;INATIVO</p>  <p>  Dados empresa&nbsp;&nbsp; &nbsp;<div style=\"margin-top: 3px;teste2\"><strong>Município: </strong>8589</div><div style=\"margin-top: 3px;teste2\"><strong>Natureza jurídica: </strong>SOCIEDADE EMPRESARIA LIMITADA</div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de enquadramento: </strong>MICRO_EMPRESA</div><div style=\"margin-top: 3px;teste2\"><strong>Evento: </strong>Inscrição de primeiro estabelecimento</div><div style=\"margin-top: 3px;teste2\"><strong>Resultado classificação: </strong>-</div><div style=\"margin-top: 3px;teste2\"><strong>Órgão registro: </strong>1 - Junta Comercial</div><div style=\"margin-top: 3px;teste\"><strong>Requerente: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Login: </strong>33390216863</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Nome: </strong>URIEL JADI SPADA BRITO</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Email: </strong>uriel.brito@longevo.com.br</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Telefone: </strong>13 99999999</div></div><div style=\"margin-top: 3px;teste\"><strong>Endereço: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Logradouro: </strong>RUA ALMERINDO SILVEIRA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Número: </strong>1</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CEP: </strong>92025814</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Bairro: </strong>ESTANCIA VELHA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área total do empreendimento: </strong>1.0</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área utilizada: </strong>1.0</div></div><div style=\"margin-top: 3px;teste2\"><strong>Objeto social: </strong>TESTE 15</div><div style=\"margin-top: 3px;teste\"><strong>Atividades: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CNAE: 6201501: </strong>Principal - exercida no local: Sim</div></div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de unidade: </strong>PRODUTIVA</div><div style=\"margin-top: 3px;teste\"><strong>Forma de atuação: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>1: </strong>Estabelecimento fixo</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>5: </strong>Porta a Porta, Postos Móveis ou por Ambulantes</div></div><div style=\"margin-top: 3px;teste2\"><strong>Número do protocolo: </strong>RSP1700385106</div></p>  <p>  Recebimento confirmado&nbsp;&nbsp; &nbsp;Sim</p>  <p>  Sincronizado Junta Comercial&nbsp;&nbsp; &nbsp;<div style=\"margin-top: 3px;teste2\"><strong>Município: </strong>8589</div><div style=\"margin-top: 3px;teste2\"><strong>Natureza jurídica: </strong>SOCIEDADE EMPRESARIA LIMITADA</div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de enquadramento: </strong>MICRO_EMPRESA</div><div style=\"margin-top: 3px;teste2\"><strong>Evento: </strong>Inscrição de primeiro estabelecimento</div><div style=\"margin-top: 3px;teste2\"><strong>Resultado classificação: </strong>-</div><div style=\"margin-top: 3px;teste2\"><strong>Órgão registro: </strong>1 - Junta Comercial</div><div style=\"margin-top: 3px;teste\"><strong>Requerente: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Login: </strong>33390216863</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Nome: </strong>URIEL JADI SPADA BRITO</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Email: </strong>uriel.brito@longevo.com.br</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Telefone: </strong>13 99999999</div></div><div style=\"margin-top: 3px;teste\"><strong>Endereço: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Logradouro: </strong>RUA ALMERINDO SILVEIRA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Número: </strong>1</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CEP: </strong>92025814</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Bairro: </strong>ESTANCIA VELHA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área total do empreendimento: </strong>1.0</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área utilizada: </strong>1.0</div></div><div style=\"margin-top: 3px;teste2\"><strong>Objeto social: </strong>TESTE 15</div><div style=\"margin-top: 3px;teste\"><strong>Atividades: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CNAE: 6201501: </strong>Principal - exercida no local: Sim</div></div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de unidade: </strong>PRODUTIVA</div><div style=\"margin-top: 3px;teste\"><strong>Forma de atuação: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>1: </strong>Estabelecimento fixo</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>5: </strong>Porta a Porta, Postos Móveis ou por Ambulantes</div></div><div style=\"margin-top: 3px;teste2\"><strong>Número do protocolo: </strong>RSP1700385106</div>-sincronizado</p>  <p>  Situação analise endereço&nbsp;&nbsp; &nbsp;Deferida-endereco</p>  <p>  Resposta analise&nbsp;&nbsp; &nbsp;Deferida-endereco-motivo</p>  <p>   </p>  <p>  --FIM DO TESTE RELATORIO--</p> 	   ',10,5,6,'2017-06-13','Administrador',NULL,NULL,NULL,NULL),(55,'Bl@ck_quebra_LINHA*~','---',10,NULL,5,'2017-06-13','André Luis',NULL,NULL,NULL,NULL),(57,'RELATORIO TESTANDO AS FORMATAÇÕES','  	      	  	   <p>  <strong>Relatório de teste rede simples, usando editor de texto, esta linha em negrito.</strong></p>  <p>  <u>Relatório de teste rede simples, usando editor de texto, &nbsp;esta linha sublihado</u></p>  <p>  <em>Relatório de teste rede simples, usando editor de texto, &nbsp;esta linha em itálico</em></p>  <p>  <strike><strong>Relatório de teste rede simples, usando editor de texto, &nbsp;esta linha está tachado.</strong></strike></p>  <p>  <sub>Relatório de teste rede simples, usando editor de texto, &nbsp;esta linha esta subscrita</sub></p>  <p>  <sup>Relatório de teste rede simples, usando editor de texto, &nbsp;esta linha esta sobrescrita</sup></p>  <p>   </p>  <ol>  <li>  &nbsp;usando numeracao</li>  <li>  aqui tbm</li>  <li>  e aqui tbm</li>  </ol>  <ul>  <li>  usnado marcador</li>  <li>  aqui tbm</li>  <li>  e aqui tbm</li>  </ul>  <div>  <a href=\"http://texto em hiperlink\">aqui é um hiperlink</a></div>  <div>   </div>  <div>  <a name=\"testando ancora\"></a></div>  <div>   </div>  <div>  <table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 200px;\">  <tbody>  <tr>  <td>  coluna 1</td>  <td>  coluna 2</td>  </tr>  <tr>  <td>  2222</td>  <td>  22222</td>  </tr>  <tr>  <td>  dsdsad</td>  <td>  adfdaffdsfs</td>  </tr>  </tbody>  </table>  </div>  <div>  <hr />  <span style=\"background-color: rgb(64, 224, 208);\">fundo de outra cor daqui pra baixo</span></div>  <p>  <span style=\"color: rgb(255, 0, 0);\"><span style=\"background-color: rgb(64, 224, 208);\">texto colorido</span></span></p>  <p>   </p>  <p>  <font color=\"#ff0000\"><span style=\"background-color: rgb(64, 224, 208);\">Aqui abaixo os dados da empresa:</span></font></p>  <p>   </p>  <p>  <strong style=\"font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 10px;\"><div style=\"margin-top: 3px;teste2\"><strong>Município: </strong>8589</div><div style=\"margin-top: 3px;teste2\"><strong>Natureza jurídica: </strong>SOCIEDADE EMPRESARIA LIMITADA</div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de enquadramento: </strong>MICRO_EMPRESA</div><div style=\"margin-top: 3px;teste2\"><strong>Evento: </strong>Inscrição de primeiro estabelecimento</div><div style=\"margin-top: 3px;teste2\"><strong>Resultado classificação: </strong>-</div><div style=\"margin-top: 3px;teste2\"><strong>Órgão registro: </strong>1 - Junta Comercial</div><div style=\"margin-top: 3px;teste\"><strong>Requerente: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Login: </strong>33390216863</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Nome: </strong>URIEL JADI SPADA BRITO</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Email: </strong>uriel.brito@longevo.com.br</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Telefone: </strong>13 99999999</div></div><div style=\"margin-top: 3px;teste\"><strong>Endereço: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Logradouro: </strong>RUA ALMERINDO SILVEIRA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Número: </strong>1</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CEP: </strong>92025814</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Bairro: </strong>ESTANCIA VELHA</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área total do empreendimento: </strong>1.0</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>Área utilizada: </strong>1.0</div></div><div style=\"margin-top: 3px;teste2\"><strong>Objeto social: </strong>TESTE 15</div><div style=\"margin-top: 3px;teste\"><strong>Atividades: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>CNAE: 6201501: </strong>Principal - exercida no local: Sim</div></div><div style=\"margin-top: 3px;teste2\"><strong>Tipo de unidade: </strong>PRODUTIVA</div><div style=\"margin-top: 3px;teste\"><strong>Forma de atuação: </strong><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>1: </strong>Estabelecimento fixo</div><div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\"><strong>5: </strong>Porta a Porta, Postos Móveis ou por Ambulantes</div></div><div style=\"margin-top: 3px;teste2\"><strong>Número do protocolo: </strong>RSP1700385106</div></strong></p>   ',9,NULL,7,'2017-06-13','André Luis',NULL,NULL,NULL,NULL),(59,'Relatório - Dados da Empresa - Rede Simples','  	      	  	   <p style=\"text-align: center;\">  <span style=\"font-size:24px;\"><u><strong>Relatório de viabilidade Comércio</strong></u></span></p>  <p>  Segue relatório de consulta de viabilidade CNAE e Endereço, Rede Simples. Abaixo dados relevantes sobre a consulta:</p>  <p>  <span style=\"font-size:11px;\"><b style=\"font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px;\"><strong>Município: </strong>8589</b></span></p>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Natureza jurídica: </strong>SOCIEDADE EMPRESARIA LIMITADA</b></font></span></div>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Tipo de enquadramento: </strong>MICRO_EMPRESA</b></font></span></div>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Evento: </strong>Inscrição de primeiro estabelecimento</b></font></span></div>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Resultado classificação: </strong>-</b></font></span></div>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Órgão registro: </strong>1 - Junta Comercial</b></font></span></div>  <div style=\"margin-top: 3px;teste\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Requerente: </strong></b></font></span>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Login: </strong>33390216863</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Nome: </strong>URIEL JADI SPADA BRITO</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Email: </strong>uriel.brito@longevo.com.br</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Telefone: </strong>13 99999999</b></font></span></div>  </div>  <div style=\"margin-top: 3px;teste\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Endereço: </strong></b></font></span>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Logradouro: </strong>RUA ALMERINDO SILVEIRA</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Número: </strong>1</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>CEP: </strong>92025814</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Bairro: </strong>ESTANCIA VELHA</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Área total do empreendimento: </strong>1.0</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Área utilizada: </strong>1.0</b></font></span></div>  </div>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Objeto social: </strong>TESTE 15</b></font></span></div>  <div style=\"margin-top: 3px;teste\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Atividades: </strong></b></font></span>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>CNAE: 6201501: </strong>Principal - exercida no local: Sim</b></font></span></div>  </div>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Tipo de unidade: </strong>PRODUTIVA</b></font></span></div>  <div style=\"margin-top: 3px;teste\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Forma de atuação: </strong></b></font></span>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>1: </strong>Estabelecimento fixo</b></font></span></div>  <div class=\"sub-item\" style=\"margin-left: 15px; margin-top: 3px;\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>5: </strong>Porta a Porta, Postos Móveis ou por Ambulantes</b></font></span></div>  </div>  <div style=\"margin-top: 3px;teste2\">  <span style=\"font-size:11px;\"><font face=\"Verdana, Arial, Helvetica, sans-serif\"><b><strong>Número do protocolo: </strong>RSP1700385106</b></font></span></div>  <p>  <sub><span style=\"background-color:#ffffff;\"><strong><em>Atenciosamente,</em></strong></span></sub></p>  <p>  <sub><span style=\"background-color:#ffffff;\"><strong><em>Andre Luis -&nbsp;Supervisor de Comércio</em></strong></span></sub></p> 	   ',11,NULL,8,'2017-06-15','André Luis',NULL,NULL,NULL,NULL),(65,'.','',11,NULL,7,'2017-06-15','André Luis','65.gif','65.gif','.','');
/*!40000 ALTER TABLE `bbh_paragrafo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_perfil`
--

DROP TABLE IF EXISTS `bbh_perfil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_perfil` (
  `bbh_per_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_per_nome` varchar(255) DEFAULT NULL,
  `bbh_per_observacao` text,
  `bbh_per_fluxo` varchar(1) DEFAULT '0',
  `bbh_per_mensagem` varchar(1) DEFAULT '0',
  `bbh_per_arquivos` varchar(1) DEFAULT '0',
  `bbh_per_equipe` varchar(1) DEFAULT '0',
  `bbh_per_tarefas` varchar(1) DEFAULT '0',
  `bbh_per_relatorios` varchar(1) DEFAULT '0',
  `bbh_per_protocolos` varchar(1) DEFAULT '0',
  `bbh_per_central_indicios` char(1) DEFAULT '0',
  `bbh_per_bi` char(1) DEFAULT '0',
  `bbh_per_geo` char(1) DEFAULT '0',
  `bbh_per_peoplerank` char(1) DEFAULT '0',
  `bbh_per_corp` char(1) DEFAULT '0',
  `bbh_per_pub` char(1) DEFAULT '0',
  `bbh_per_matriz` int(5) DEFAULT '0',
  `bbh_per_unidade` int(5) DEFAULT '0',
  PRIMARY KEY (`bbh_per_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_perfil`
--

LOCK TABLES `bbh_perfil` WRITE;
/*!40000 ALTER TABLE `bbh_perfil` DISABLE KEYS */;
INSERT INTO `bbh_perfil` VALUES (1,'Perfil','Usuário do Sistema','1','1','1','1','1','1','1','1','0','0','0','0','0',0,0),(17,'Triagem','Triagem','1','1','1','1','1','1','1','1','0','0','0','0','0',0,0),(18,'Supervisor - ISS','Supervisor - ISS','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(19,'Analista - Comércio','Analista - Comércio','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(20,'Analista de Riscos','Analista de Riscos','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(21,'Supervisor - Comércio','Supervisor - Comércio','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(22,'Supervisor de Riscos','Supervisor de Riscos','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(23,'Indeferimento','Este perfil é destinado para que o usuário possa seguir uma alternativa para indeferimento, quando a atividade não é um atividade final.','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(24,'Gerente Geral','Gerente Geral','1','1','1','1','1','1','1','0','0','0','0','0','0',-1,-1),(31,'Indeferimento - Ativ. 2 - Processo Comércio','Indeferimento - Ativ. 2 - Processo Comércio','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(32,'Indeferimento - Ativ. 3 - Processo Comércio','Indeferimento - Ativ. 3 - Processo Comércio','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(33,'Indeferimento - Ativ. 5 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 5 - Processo Produtos Químicos e Inflamáveis','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(34,'Indeferimento - Ativ. 1 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 1 - Processo Produtos Químicos e Inflamáveis','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(35,'Indeferimento - Ativ. 2 - Processo Produtos Químicos e Inflamáveis','Indeferimento - Ativ. 2 - Processo Produtos Químicos e Inflamáveis','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(36,'Indeferimento - Ativ. 7 - Processo Diversificado','Indeferimento - Ativ. 7 - Processo Diversificado','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(37,'Indeferimento - Ativ. 8 - Processo Diversificado','Indeferimento - Ativ. 8 - Processo Diversificado','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(38,'Indeferimento - Ativ. 9 - Processo Diversificado','Indeferimento - Ativ. 9 - Processo Diversificado','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1),(39,'Indeferimento - Ativ. 11 - Processo Diversificado','Indeferimento - Ativ. 11 - Processo Diversificado','1','1','1','0','1','1','0','0','0','0','0','0','0',-1,-1);
/*!40000 ALTER TABLE `bbh_perfil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_permissao_fluxo`
--

DROP TABLE IF EXISTS `bbh_permissao_fluxo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_permissao_fluxo` (
  `bbh_per_flu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_mod_flu_codigo` int(11) DEFAULT NULL,
  `bbh_per_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_per_flu_codigo`),
  KEY `bbh_permissao_fluxo_bbh_modelo_fluxo` (`bbh_mod_flu_codigo`),
  KEY `bbh_permissao_fluxo_bbh_perfil` (`bbh_per_codigo`),
  CONSTRAINT `bbh_permissao_fluxo_bbh_modelo_fluxo` FOREIGN KEY (`bbh_mod_flu_codigo`) REFERENCES `bbh_modelo_fluxo` (`bbh_mod_flu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_permissao_fluxo_bbh_perfil` FOREIGN KEY (`bbh_per_codigo`) REFERENCES `bbh_perfil` (`bbh_per_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_permissao_fluxo`
--

LOCK TABLES `bbh_permissao_fluxo` WRITE;
/*!40000 ALTER TABLE `bbh_permissao_fluxo` DISABLE KEYS */;
INSERT INTO `bbh_permissao_fluxo` VALUES (14,19,17),(18,24,20),(19,24,18),(20,24,19),(22,25,17),(23,26,19),(24,27,18),(28,28,19),(29,28,20),(30,28,21),(35,19,1),(38,25,1),(39,21,1),(40,29,1),(41,30,19),(42,31,19);
/*!40000 ALTER TABLE `bbh_permissao_fluxo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_protocolos`
--

DROP TABLE IF EXISTS `bbh_protocolos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_protocolos` (
  `bbh_pro_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_pro_titulo` varchar(255) DEFAULT NULL,
  `bbh_pro_descricao` text,
  `bbh_pro_obs` text,
  `bbh_pro_momento` datetime DEFAULT CURRENT_TIMESTAMP,
  `bbh_pro_identificacao` varchar(100) DEFAULT NULL,
  `bbh_pro_email` varchar(100) DEFAULT NULL,
  `bbh_pro_senha` varchar(100) DEFAULT NULL,
  `bbh_pro_status` char(1) DEFAULT NULL,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  `bbh_dep_codigo` int(255) DEFAULT NULL,
  `bbh_pro_data` date DEFAULT NULL,
  `bbh_pro_recebido` varchar(255) DEFAULT NULL,
  `bbh_pro_dt_recebido` datetime DEFAULT NULL,
  `bbh_pro_flagrante` char(1) DEFAULT '0',
  `bbh_pro_autoridade` varchar(255) DEFAULT NULL,
  `bbh_flu_pai` int(10) DEFAULT NULL,
  `bbh_usu_codigo` int(10) DEFAULT NULL,
  PRIMARY KEY (`bbh_pro_codigo`),
  KEY `bbh_flu_codigoP` (`bbh_flu_codigo`),
  KEY `dep_codigo` (`bbh_dep_codigo`),
  CONSTRAINT `bbh_flu_codigoP` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `dep_codigo` FOREIGN KEY (`bbh_dep_codigo`) REFERENCES `bbh_departamento` (`bbh_dep_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=253 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_protocolos`
--

LOCK TABLES `bbh_protocolos` WRITE;
/*!40000 ALTER TABLE `bbh_protocolos` DISABLE KEYS */;
INSERT INTO `bbh_protocolos` VALUES (210,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"30/05/2017 17:20\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-17 17:35:25','RSP1700385066','tecnica@longevo.com.br',NULL,'6',30,1,'2017-05-17','tecnica@longevo.com.br','2017-05-30 17:20:33','N',NULL,NULL,NULL),(211,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"31/05/2017 09:04\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-17 17:35:25','RSP1700385081','tecnica@longevo.com.br',NULL,'6',31,1,'2017-05-17','tecnica@longevo.com.br','2017-05-31 09:04:19','N',NULL,NULL,NULL),(212,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"17/05/2017 17:57\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"31/05/2017 12:01\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo indeferido.\"/><conversa momento=\"31/05/2017 12:01\" profissional=\"Técnica Longevo\" mensagem=\"estou indeferindo no protocolo, antes mesmo de receber\"/></despacho>\n','2017-05-17 17:48:19','RSP1700385087','tecnica@longevo.com.br',NULL,'6',NULL,1,'2017-05-17','tecnica@longevo.com.br','2017-05-31 12:01:52','N',NULL,NULL,NULL),(213,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"31/05/2017 12:02\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"31/05/2017 12:08\" profissional=\"Técnica Longevo\" mensagem=\"Arquivado.\"/><conversa momento=\"31/05/2017 12:08\" profissional=\"Técnica Longevo\" mensagem=\"Estou deferindo o processo já no protocolo, após ter recebido esta solicitação, mas sem enviar para nenhum fluxo...\"/></despacho>\n','2017-05-18 16:48:02','RSP1700385088','tecnica@longevo.com.br',NULL,'5',NULL,1,'2017-05-18','tecnica@longevo.com.br','2017-05-31 12:02:32','N',NULL,NULL,NULL),(214,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"31/05/2017 15:52\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-18 16:48:02','RSP1700385089','tecnica@longevo.com.br',NULL,'5',33,1,'2017-05-18','tecnica@longevo.com.br','2017-05-31 15:52:23','N',NULL,NULL,NULL),(215,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"22/05/2017 17:11\" profissional=\"Técnica Longevo\" mensagem=\"Arquivado.\"/><conversa momento=\"31/05/2017 16:35\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-18 16:48:02','RSP1700385090','tecnica@longevo.com.br',NULL,'6',34,1,'2017-05-18','tecnica@longevo.com.br','2017-05-31 16:35:40','N',NULL,NULL,NULL),(216,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"31/05/2017 17:15\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-18 16:54:18','RSP1700385091','tecnica@longevo.com.br',NULL,'6',37,1,'2017-05-18','tecnica@longevo.com.br','2017-05-31 17:15:18','N',NULL,NULL,NULL),(217,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"23/05/2017 11:24\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo em situação de aguardando.\"/><conversa momento=\"31/05/2017 17:27\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-18 22:02:04','RSP1700385092','tecnica@longevo.com.br',NULL,'5',40,1,'2017-05-18','tecnica@longevo.com.br','2017-05-31 17:27:29','N',NULL,NULL,NULL),(218,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"23/05/2017 16:25\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo indeferido.\"/><conversa momento=\"23/05/2017 16:25\" profissional=\"Técnica Longevo\" mensagem=\"Não atendeu os requisitos do processo.\"/><conversa momento=\"01/06/2017 10:12\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"01/06/2017 10:12\" profissional=\"Técnica Longevo\" mensagem=\"recebido aqui\"/></despacho>\n','2017-05-18 19:11:03','RSP1700385093','tecnica@longevo.com.br',NULL,'6',43,1,'2017-05-18','tecnica@longevo.com.br','2017-06-01 10:12:10','N',NULL,NULL,NULL),(219,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"23/05/2017 17:37\" profissional=\"Técnica Longevo\" mensagem=\"Arquivado.\"/><conversa momento=\"23/05/2017 17:37\" profissional=\"Técnica Longevo\" mensagem=\"Atendeu Lei 123/2017\"/><conversa momento=\"01/06/2017 11:15\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-19 10:21:07','RSP1700385094','tecnica@longevo.com.br',NULL,'5',44,1,'2017-05-19','tecnica@longevo.com.br','2017-06-01 11:15:07','N',NULL,NULL,NULL),(220,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"01/06/2017 11:16\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-19 10:23:03','RSP1700385095','tecnica@longevo.com.br',NULL,'6',45,1,'2017-05-19','tecnica@longevo.com.br','2017-06-01 11:16:25','N',NULL,NULL,NULL),(221,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"01/06/2017 11:22\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-19 14:51:04','RSP1700385097','tecnica@longevo.com.br',NULL,'5',46,1,'2017-05-19','tecnica@longevo.com.br','2017-06-01 11:22:29','N',NULL,NULL,NULL),(222,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"01/06/2017 11:29\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-19 14:52:06','RSP1700385098','tecnica@longevo.com.br',NULL,'6',47,1,'2017-05-19','tecnica@longevo.com.br','2017-06-01 11:29:32','N',NULL,NULL,NULL),(223,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"01/06/2017 13:55\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-19 14:54:03','RSP1700385099','tecnica@longevo.com.br',NULL,'6',48,1,'2017-05-19','tecnica@longevo.com.br','2017-06-01 13:55:54','N',NULL,NULL,NULL),(224,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"05/06/2017 11:36\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"05/06/2017 11:37\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo indeferido.\"/><conversa momento=\"05/06/2017 11:37\" profissional=\"Técnica Longevo\" mensagem=\"indeferi depois de receber, ainda no protocolo.\"/></despacho>\n','2017-05-19 14:56:06','RSP1700385100','tecnica@longevo.com.br',NULL,'6',NULL,1,'2017-05-19','tecnica@longevo.com.br','2017-06-05 11:37:50','N',NULL,NULL,NULL),(225,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"05/06/2017 17:49\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-19 14:58:03','RSP1700385101','tecnica@longevo.com.br',NULL,'6',51,1,'2017-05-19','tecnica@longevo.com.br','2017-06-05 17:49:11','N',NULL,NULL,NULL),(226,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"07/06/2017 10:51\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-22 14:58:08','RSP1700385103','tecnica@longevo.com.br',NULL,'5',52,1,'2017-05-22','tecnica@longevo.com.br','2017-06-07 10:51:57','N',NULL,NULL,NULL),(227,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"30/05/2017 09:54\" profissional=\"carlos\" mensagem=\"teste campo despacho com uma atividade que ainda não pode ser tomada ação pois existem predecessoras ...\"/><conversa momento=\"30/05/2017 09:54\" profissional=\"carlos\" mensagem=\"teste 2 campo despacho com uma atividade que ainda não pode ser tomada ação pois existem predecessoras ...\"/><conversa momento=\"12/06/2017 11:04\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-22 15:03:05','RSP1700385104','tecnica@longevo.com.br',NULL,'6',56,1,'2017-05-22','tecnica@longevo.com.br','2017-06-12 11:04:31','N',NULL,NULL,NULL),(228,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"13/06/2017 15:35\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-22 16:34:03','RSP1700385106','tecnica@longevo.com.br',NULL,'5',57,1,'2017-05-22','tecnica@longevo.com.br','2017-06-13 15:35:02','N',NULL,NULL,NULL),(229,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"24/05/2017 11:23\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"27/06/2017 08:49\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-24 10:59:05','RSP1700385115','tecnica@longevo.com.br',NULL,'5',61,1,'2017-05-24','tecnica@longevo.com.br','2017-06-27 08:49:29','N',NULL,NULL,NULL),(230,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"24/05/2017 12:04\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"13/09/2017 10:57\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-24 11:02:05','RSP1700385117','tecnica@longevo.com.br',NULL,'5',64,1,'2017-05-24','tecnica@longevo.com.br','2017-09-13 10:57:29','N',NULL,NULL,NULL),(231,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"25/05/2017 08:36\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"25/05/2017 10:34\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo devolvido ao local de origem.\"/><conversa momento=\"25/05/2017 10:36\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-24 11:03:04','RSP1700385118','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-24','tecnica@longevo.com.br','2017-05-25 10:36:24','N',NULL,NULL,NULL),(232,'Rede Simples',NULL,NULL,'2017-05-29 10:40:07','RSP1700385144','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(233,'Rede Simples',NULL,NULL,'2017-05-29 10:41:05','RSP1700385145','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(234,'Rede Simples',NULL,NULL,'2017-05-29 10:42:04','RSP1700385146','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(235,'Rede Simples',NULL,NULL,'2017-05-29 10:43:04','RSP1700385147','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(236,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"25/10/2017 13:49\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-29 10:45:04','RSP1700385148','tecnica@longevo.com.br',NULL,'2',NULL,1,'2017-05-29','tecnica@longevo.com.br','2017-10-25 13:49:05','N',NULL,NULL,NULL),(237,'Rede Simples',NULL,NULL,'2017-05-29 10:46:04','RSP1700385149','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(238,'Rede Simples',NULL,NULL,'2017-05-29 10:47:06','RSP1700385150','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(239,'Rede Simples',NULL,NULL,'2017-05-29 10:49:03','RSP1700385151','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(240,'Rede Simples',NULL,NULL,'2017-05-29 10:51:05','RSP1700385152','tecnica@longevo.com.br',NULL,'1',NULL,1,'2017-05-29',NULL,NULL,'N',NULL,NULL,NULL),(241,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"25/10/2017 13:45\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-29 10:53:05','RSP1700385153','tecnica@longevo.com.br',NULL,'4',66,1,'2017-05-29','tecnica@longevo.com.br','2017-10-25 13:45:14','N',NULL,NULL,NULL),(242,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"05/10/2017 16:48\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"05/10/2017 16:48\" profissional=\"Técnica Longevo\" mensagem=\"em analise de viabilidade\"/></despacho>\n','2017-05-29 10:54:07','RSP1700385154','tecnica@longevo.com.br',NULL,'4',65,1,'2017-05-29','tecnica@longevo.com.br','2017-10-05 16:48:41','N',NULL,NULL,NULL),(243,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"02/06/2017 17:19\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-29 15:55:05','RSP1700385157','tecnica@longevo.com.br',NULL,'4',49,1,'2017-05-29','tecnica@longevo.com.br','2017-06-02 17:19:45','N',NULL,NULL,NULL),(244,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"30/05/2017 16:51\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-05-29 15:55:05','RSP1700385158','tecnica@longevo.com.br',NULL,'5',29,1,'2017-05-29','tecnica@longevo.com.br','2017-05-30 16:51:50','N',NULL,NULL,NULL),(245,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"28/06/2017 09:42\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-06-07 15:36:06','RSP1700385184','tecnica@longevo.com.br',NULL,'6',62,1,'2017-06-07','tecnica@longevo.com.br','2017-06-28 09:42:43','N',NULL,NULL,NULL),(246,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"08/06/2017 15:28\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo indeferido.\"/><conversa momento=\"08/06/2017 15:28\" profissional=\"Técnica Longevo\" mensagem=\"Não atendeu a lei...\"/></despacho>\n','2017-06-07 15:38:06','RSP1700385185','tecnica@longevo.com.br',NULL,'6',NULL,1,'2017-06-07','tecnica@longevo.com.br','2017-06-08 15:28:40','N',NULL,NULL,NULL),(247,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"07/06/2017 15:46\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo indeferido.\"/><conversa momento=\"07/06/2017 15:46\" profissional=\"Técnica Longevo\" mensagem=\"Não atendeu a lei 123\"/></despacho>\n','2017-06-07 15:40:06','RSP1700385187','tecnica@longevo.com.br',NULL,'6',NULL,1,'2017-06-07','tecnica@longevo.com.br','2017-06-07 15:46:37','N',NULL,NULL,NULL),(248,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"07/06/2017 15:47\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-06-07 15:45:04','RSP1700385188','tecnica@longevo.com.br',NULL,'5',54,1,'2017-06-07','tecnica@longevo.com.br','2017-06-07 15:47:57','N',NULL,NULL,NULL),(249,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"08/06/2017 14:56\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"08/06/2017 15:02\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo devolvido ao local de origem.\"/><conversa momento=\"08/06/2017 15:03\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-06-08 14:52:06','RSP1700385191','tecnica@longevo.com.br',NULL,'5',55,1,'2017-06-08','tecnica@longevo.com.br','2017-06-08 15:03:39','N',NULL,NULL,NULL),(250,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"22/06/2017 16:39\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-06-09 10:35:07','RSP1700385198','tecnica@longevo.com.br',NULL,'5',59,1,'2017-06-09','tecnica@longevo.com.br','2017-06-22 16:39:26','N',NULL,NULL,NULL),(251,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"20/06/2017 17:12\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"22/06/2017 10:43\" profissional=\"Técnica Longevo\" mensagem=\"Protocolo em situação de aguardando.\"/><conversa momento=\"22/06/2017 10:43\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/></despacho>\n','2017-06-09 10:41:06','RSP1700385199','tecnica@longevo.com.br',NULL,'5',58,1,'2017-06-09','tecnica@longevo.com.br','2017-06-22 10:43:12','N',NULL,NULL,NULL),(252,'Rede Simples',NULL,'<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<despacho><conversa momento=\"05/10/2017 16:42\" profissional=\"Técnica Longevo\" mensagem=\"Recebeu protocolo com todos osInformação e anexos.\"/><conversa momento=\"05/10/2017 16:42\" profissional=\"Técnica Longevo\" mensagem=\"Arquivado.\"/><conversa momento=\"05/10/2017 16:42\" profissional=\"Técnica Longevo\" mensagem=\"Sucesso!\"/></despacho>\n','2017-07-14 10:34:05','RSP1700385237','tecnica@longevo.com.br',NULL,'5',NULL,1,'2017-07-14','tecnica@longevo.com.br','2017-10-05 16:42:32','N',NULL,NULL,NULL);
/*!40000 ALTER TABLE `bbh_protocolos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_relatorio`
--

DROP TABLE IF EXISTS `bbh_relatorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_relatorio` (
  `bbh_rel_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_rel_data_criacao` date DEFAULT NULL,
  `bbh_rel_arquivo` varchar(255) DEFAULT NULL,
  `bbh_rel_observacao` text,
  `bbh_ati_codigo` int(11) NOT NULL,
  `bbh_rel_finalizado` int(1) DEFAULT '0',
  `bbh_rel_titulo` varchar(255) DEFAULT NULL,
  `bbh_usu_codigo` int(11) DEFAULT NULL,
  `bbh_rel_pdf` char(1) DEFAULT '0',
  `bbh_rel_ass` char(1) DEFAULT '0',
  `bbh_rel_nmArquivo` varchar(255) DEFAULT NULL,
  `bbh_rel_caminho` varchar(255) DEFAULT NULL,
  `bbh_rel_protegido` char(1) DEFAULT '0',
  PRIMARY KEY (`bbh_rel_codigo`),
  KEY `bbh_relatorio_bbh_ati_codigo` (`bbh_ati_codigo`),
  CONSTRAINT `bbh_relatorio_bbh_ati_codigo` FOREIGN KEY (`bbh_ati_codigo`) REFERENCES `bbh_atividade` (`bbh_ati_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_relatorio`
--

LOCK TABLES `bbh_relatorio` WRITE;
/*!40000 ALTER TABLE `bbh_relatorio` DISABLE KEYS */;
INSERT INTO `bbh_relatorio` VALUES (3,'2017-06-01',NULL,'Aqui é o campo \"Descrição\" de um relatório teste que estou fazendo...',88,0,'Processo Produtos Químicos e Inflamáveis - 2.3/2017 (Rede Simples - adicionei esse texto no titulo) - adicionei esse texto no titulo 2 - 2.3/2017',5,'0','0',NULL,NULL,'0'),(4,'2017-06-01',NULL,'Preenchi a descrição de teste',88,0,'Processo Produtos Químicos e Inflamáveis - 2.3/2017 (Rede Simples - adicionei esse texto no titulo) - adicionei esse texto no titulo 2 - 2.3/2017',5,'1','0',NULL,NULL,'0'),(5,'2017-06-02',NULL,'relatorio teste',88,0,'Processo Produtos Químicos e Inflamáveis - 2.3/2017 (Rede Simples - adicionei esse texto no titulo) - adicionei esse texto no titulo 2 - 2.3/2017',5,'1','0',NULL,NULL,'0'),(6,'2017-06-05',NULL,'relatório teste',94,0,'Processo Produtos Químicos e Inflamáveis - 3.3/2017 (Rede Simples) - 3.3/2017',5,'1','0',NULL,NULL,'0'),(7,'2017-06-07',NULL,'criando relatório teste 1',95,1,'Processo Comércio - 2.2/2017 (Rede Simples) - 2.2/2017',4,'1','0',NULL,NULL,'0'),(8,'2017-06-12',NULL,'teste novo laudo',101,1,'Processo Comércio - 3.2/2017 (Rede Simples) - 3.2/2017',4,'0','0',NULL,NULL,'0'),(9,'2017-06-13',NULL,'teste',104,1,'Processo Comércio - 4.2/2017 (Rede Simples) - 4.2/2017',4,'1','0',NULL,NULL,'0'),(10,'2017-06-13',NULL,'teste',104,1,'Processo Comércio - 4.2/2017 (Rede Simples) - 4.2/2017',4,'1','0',NULL,NULL,'0'),(11,'2017-06-15',NULL,'Novo relatorio',104,1,'NOVO - Processo Comércio - 4.2/2017 (Rede Simples) - 4.2/2017',4,'1','0',NULL,NULL,'0');
/*!40000 ALTER TABLE `bbh_relatorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_servicos`
--

DROP TABLE IF EXISTS `bbh_servicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_servicos` (
  `bbh_ser_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_usu_codigo_tomador` int(11) DEFAULT NULL,
  `bbh_usu_codigo_prestador` int(11) DEFAULT NULL,
  `bbh_flu_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_ser_codigo`),
  KEY `bbh_usu_codigo_tomador` (`bbh_usu_codigo_tomador`),
  KEY `bbh_usu_codigo_prestador` (`bbh_usu_codigo_prestador`),
  KEY `bbh_flu_codigo_ser` (`bbh_flu_codigo`),
  CONSTRAINT `bbh_flu_codigo_ser` FOREIGN KEY (`bbh_flu_codigo`) REFERENCES `bbh_fluxo` (`bbh_flu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_codigo_prestador` FOREIGN KEY (`bbh_usu_codigo_prestador`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_codigo_tomador` FOREIGN KEY (`bbh_usu_codigo_tomador`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_servicos`
--

LOCK TABLES `bbh_servicos` WRITE;
/*!40000 ALTER TABLE `bbh_servicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_servicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_setup`
--

DROP TABLE IF EXISTS `bbh_setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_setup` (
  `bbh_set_codigo` int(10) NOT NULL AUTO_INCREMENT,
  `bbh_set_email_origem` varchar(255) DEFAULT NULL,
  `bbh_set_titulo_origem` varchar(255) DEFAULT NULL,
  `bbh_set_assunto` varchar(255) DEFAULT NULL,
  `bbh_set_usuario` varchar(255) DEFAULT NULL,
  `bbh_set_senha` varchar(255) DEFAULT NULL,
  `bbh_set_smtp` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bbh_set_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_setup`
--

LOCK TABLES `bbh_setup` WRITE;
/*!40000 ALTER TABLE `bbh_setup` DISABLE KEYS */;
INSERT INTO `bbh_setup` VALUES (1,'site@longevo.com.br','Longevo','Mensagem do fluxo','site@longevo.com.br','.com@2012','smtp1.longevo.com.br');
/*!40000 ALTER TABLE `bbh_setup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_status_atividade`
--

DROP TABLE IF EXISTS `bbh_status_atividade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_status_atividade` (
  `bbh_sta_ati_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_sta_ati_nome` varchar(255) DEFAULT NULL,
  `bbh_sta_ati_peso` int(11) DEFAULT NULL,
  `bbh_sta_ati_observacao` text,
  PRIMARY KEY (`bbh_sta_ati_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_status_atividade`
--

LOCK TABLES `bbh_status_atividade` WRITE;
/*!40000 ALTER TABLE `bbh_status_atividade` DISABLE KEYS */;
INSERT INTO `bbh_status_atividade` VALUES (1,'Não inicializado',0,NULL),(2,'Finalizado',100,NULL),(3,'Ciente',5,''),(4,'Aguardando',10,NULL),(5,'Em andamento',20,'');
/*!40000 ALTER TABLE `bbh_status_atividade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_tipo_fluxo`
--

DROP TABLE IF EXISTS `bbh_tipo_fluxo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_tipo_fluxo` (
  `bbh_tip_flu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_tip_flu_identificacao` varchar(255) DEFAULT NULL,
  `bbh_tip_flu_nome` varchar(255) DEFAULT NULL,
  `bbh_tip_flu_codigo_pai` int(11) DEFAULT NULL,
  `bbh_tip_flu_observacao` text,
  PRIMARY KEY (`bbh_tip_flu_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_tipo_fluxo`
--

LOCK TABLES `bbh_tipo_fluxo` WRITE;
/*!40000 ALTER TABLE `bbh_tipo_fluxo` DISABLE KEYS */;
INSERT INTO `bbh_tipo_fluxo` VALUES (18,'01','Viabilidade - ISS',NULL,'Tipo de processo desenhado para Viabilidade - ISS'),(19,'02.00','(ANTIGA NÃO USAR)Viabilidade - Comércio',NULL,'(ANTIGA NÃO USAR)Tipo de processo desenhado para Viabilidade - Comércio'),(20,'03','Viabilidade - Produtos Químicos e Inflamáveis',NULL,'Tipo de processo desenhado para Viabilidade - Produtos Químicos e Inflamáveis'),(21,'04','Viabilidade - Indeferimentos',NULL,'Tipo de processo desenhado para indeferimentos que acontecem em atividades que não são as atividades finais de um processo.'),(22,'05',' Viabilidade - Diversificada',NULL,'Tipo de processo desenhado para Viabilidade - Diversificada.'),(23,'02','Viabilidade - Comércio',NULL,'Viabilidade - Comércio');
/*!40000 ALTER TABLE `bbh_tipo_fluxo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_tipo_indicio`
--

DROP TABLE IF EXISTS `bbh_tipo_indicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_tipo_indicio` (
  `bbh_tip_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_tip_nome` varchar(255) DEFAULT NULL,
  `bbh_tip_descricao` text,
  `bbh_tip_ativo` int(11) DEFAULT '1',
  `bbh_tipo_corp` int(11) DEFAULT '1',
  `bbh_dep_codigo` int(255) DEFAULT NULL,
  PRIMARY KEY (`bbh_tip_codigo`),
  KEY `ind_bbh_dep_codigo` (`bbh_dep_codigo`),
  CONSTRAINT `ind_bbh_dep_codigo` FOREIGN KEY (`bbh_dep_codigo`) REFERENCES `bbh_departamento` (`bbh_dep_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_tipo_indicio`
--

LOCK TABLES `bbh_tipo_indicio` WRITE;
/*!40000 ALTER TABLE `bbh_tipo_indicio` DISABLE KEYS */;
INSERT INTO `bbh_tipo_indicio` VALUES (1,'Informações conhecidas','Elencar as informações dos objetos necessários à realização da pesquisa',0,0,1);
/*!40000 ALTER TABLE `bbh_tipo_indicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_usuario`
--

DROP TABLE IF EXISTS `bbh_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_usuario` (
  `bbh_usu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_usu_identificacao` varchar(255) DEFAULT NULL,
  `bbh_usu_nome` varchar(255) DEFAULT NULL,
  `bbh_usu_apelido` varchar(100) DEFAULT '584',
  `bbh_usu_data_nascimento` date DEFAULT NULL,
  `bbh_usu_sexo` varchar(1) DEFAULT NULL,
  `bbh_usu_atribuicao` datetime DEFAULT NULL,
  `bbh_usu_rg` varchar(50) DEFAULT NULL,
  `bbh_usu_cpf` varchar(50) DEFAULT NULL,
  `bbh_dep_codigo` int(11) DEFAULT NULL,
  `bbh_usu_cargo` varchar(255) DEFAULT NULL,
  `bbh_usu_permissao_dep` int(11) DEFAULT NULL,
  `bbh_usu_chefe` int(11) DEFAULT NULL,
  `bbh_usu_tel_comercial` varchar(60) DEFAULT NULL,
  `bbh_usu_tel_residencial` varchar(60) DEFAULT NULL,
  `bbh_usu_tel_celular` varchar(60) DEFAULT NULL,
  `bbh_usu_tel_recados` varchar(60) DEFAULT NULL,
  `bbh_usu_fax` varchar(60) DEFAULT NULL,
  `bbh_usu_email_alternativo` varchar(80) DEFAULT NULL,
  `bbh_usu_endereco` varchar(255) DEFAULT NULL,
  `bbh_usu_cidade` varchar(150) DEFAULT NULL,
  `bbh_usu_estado` varchar(2) DEFAULT 'SP',
  `bbh_usu_cep` varchar(9) DEFAULT NULL,
  `bbh_usu_pais` varchar(80) DEFAULT 'Brasil',
  `bbh_usu_ultimoAcesso` datetime DEFAULT '0000-00-00 00:00:00',
  `bbh_usu_ativo` int(11) DEFAULT '1',
  `bbh_usu_restringir_receb_solicitacao` char(1) DEFAULT '0',
  `bbh_usu_restringir_ini_processo` char(1) DEFAULT '0',
  `bbh_usu_nivel` int(11) DEFAULT '584',
  PRIMARY KEY (`bbh_usu_codigo`),
  KEY `bbh_dep_codigo` (`bbh_dep_codigo`),
  KEY `bbh_usu_chefe` (`bbh_usu_chefe`),
  CONSTRAINT `bbh_dep_codigo` FOREIGN KEY (`bbh_dep_codigo`) REFERENCES `bbh_departamento` (`bbh_dep_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_chefe` FOREIGN KEY (`bbh_usu_chefe`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_usuario`
--

LOCK TABLES `bbh_usuario` WRITE;
/*!40000 ALTER TABLE `bbh_usuario` DISABLE KEYS */;
INSERT INTO `bbh_usuario` VALUES (1,'tecnica@longevo.com.br','Técnica','Técnica Longevo','1975-06-23','1','2017-05-25 10:43:24','100','100',1,'Tecnica Blackbee',0,1,'11 985362282','','','11 985362282','','tecnica@longevo.com.br','Endereço Comercial','São Paulo','SP','11310064','Brasil','2017-11-15 15:30:21',1,'0','0',584),(2,'renato.augusto@longevo.com.br','Renato Augusto','Renato','1980-01-01','1',NULL,'1234','1234',4,'Analista de Triagem',0,11,'',NULL,NULL,'',NULL,'','','','SP','','','2017-05-29 14:54:59',1,'0','0',584),(3,'cassiano.brito@longevo.com.br','Cassiano Brito','Cassiano','1980-01-01','1','2017-10-25 13:46:10','01','01',3,'Supervisor ISS',0,11,'',NULL,NULL,'',NULL,'','','','SP','','','2017-09-13 10:59:08',1,'0','0',584),(4,'andre.luis@longevo.com.br','André Luis','André','1980-01-01','1','2017-06-28 09:43:29','02','02',6,'Supervisor Comercio',0,11,'',NULL,NULL,'',NULL,'','','','SP','','','2017-09-13 10:58:17',1,'0','0',584),(5,'bruno.azevedo@longevo.com.br','Bruno Azevedo','bruno','1980-01-01','1','2017-06-28 09:51:17','03','03',6,'Analista Comércio',0,4,'',NULL,NULL,'',NULL,'','','','SP','','','2017-06-28 10:34:35',1,'0','0',584),(6,'carlos.sena@longevo.com.br','Carlos Sena','carlos','1980-01-01','1','2017-06-28 09:43:29','04','04',6,'Analista Comércio',0,4,'',NULL,NULL,'',NULL,'','','','SP','','','2017-09-13 10:58:50',1,'0','0',584),(7,'afonso.bento@longevo.com.br','Afonso Bento','afonso','1980-01-01','1','2017-06-05 17:49:33','05','05',5,'Supervisor de Produtos Químicos e Inflamáveis',0,11,'',NULL,NULL,'',NULL,'','','','SP','','','2017-09-13 10:58:31',1,'0','0',584),(8,'braga.bueno@longevo.com.br','Braga Bueno','braga','1980-01-01','1','2017-06-05 17:49:33','06','06',6,'Analista',0,7,'',NULL,NULL,'',NULL,'','','','SP','','','2017-06-05 17:50:13',1,'0','0',584),(9,'celso.luz@longevo.com.br','Celso Luz','celso','1980-01-01','1','2017-05-30 10:56:06','07','07',5,'Analista',0,7,'',NULL,NULL,'',NULL,'','','','SP','','','2017-05-30 13:28:38',1,'0','0',584),(10,'daniel.abreu@longevo.com.br','Daniel Abreu','daniel','1980-01-01','1',NULL,'08','08',5,'Analista',0,7,'',NULL,NULL,'',NULL,'','','','SP','','','2017-05-24 18:06:34',1,'0','0',584),(11,'fabio.faria@longevo.com.br','Fabio Faria','Fabio','1980-01-01','1','2017-06-01 09:24:05','10','10',7,'Gerente Geral',0,1,'',NULL,NULL,'',NULL,'','','','SP','','','2017-06-05 11:54:11',1,'0','0',584);
/*!40000 ALTER TABLE `bbh_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_usuario_nomeacao`
--

DROP TABLE IF EXISTS `bbh_usuario_nomeacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_usuario_nomeacao` (
  `bbh_usu_per_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_usu_codigo` int(11) DEFAULT NULL,
  `bbh_per_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_usu_per_codigo`),
  KEY `bbh_usu_codigo_bbh_usuario` (`bbh_usu_codigo`),
  KEY `bbh_per_codigo_bbh_perfil` (`bbh_per_codigo`),
  CONSTRAINT `bbh_per_codigo_bbh_perfil` FOREIGN KEY (`bbh_per_codigo`) REFERENCES `bbh_perfil` (`bbh_per_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usu_codigo_bbh_usuario` FOREIGN KEY (`bbh_usu_codigo`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_usuario_nomeacao`
--

LOCK TABLES `bbh_usuario_nomeacao` WRITE;
/*!40000 ALTER TABLE `bbh_usuario_nomeacao` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbh_usuario_nomeacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbh_usuario_perfil`
--

DROP TABLE IF EXISTS `bbh_usuario_perfil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbh_usuario_perfil` (
  `bbh_usu_per_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbh_usu_codigo` int(11) DEFAULT NULL,
  `bbh_per_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbh_usu_per_codigo`),
  KEY `bbh_usuario_perfil_bbh_usuario` (`bbh_usu_codigo`),
  KEY `bbh_usuario_perfil_bbh_perfil` (`bbh_per_codigo`),
  CONSTRAINT `bbh_usuario_perfil_bbh_perfil` FOREIGN KEY (`bbh_per_codigo`) REFERENCES `bbh_perfil` (`bbh_per_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `bbh_usuario_perfil_bbh_usuario` FOREIGN KEY (`bbh_usu_codigo`) REFERENCES `bbh_usuario` (`bbh_usu_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbh_usuario_perfil`
--

LOCK TABLES `bbh_usuario_perfil` WRITE;
/*!40000 ALTER TABLE `bbh_usuario_perfil` DISABLE KEYS */;
INSERT INTO `bbh_usuario_perfil` VALUES (1,1,1),(4,3,18),(5,5,19),(6,6,19),(8,8,20),(9,9,20),(10,10,20),(11,4,21),(12,7,22),(21,11,24),(23,2,17),(33,5,31),(34,6,31),(35,5,32),(36,6,32),(37,8,33),(38,9,33),(39,10,33),(40,3,34),(41,5,35),(42,6,35),(43,5,36),(44,6,36),(45,8,37),(46,9,37),(47,10,37),(48,5,38),(49,6,38),(50,4,39);
/*!40000 ALTER TABLE `bbh_usuario_perfil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_aplicacao`
--

DROP TABLE IF EXISTS `bbp_adm_aplicacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_aplicacao` (
  `bbp_adm_apl_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_apl_nome` varchar(100) DEFAULT NULL,
  `bbp_adm_apl_apelido` varchar(100) DEFAULT NULL,
  `bbp_adm_apl_observacao` blob,
  `bbp_adm_apl_url` varchar(255) DEFAULT NULL,
  `bbp_adm_apl_ativo` char(1) DEFAULT '1',
  `bbp_adm_apl_icone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`bbp_adm_apl_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_aplicacao`
--

LOCK TABLES `bbp_adm_aplicacao` WRITE;
/*!40000 ALTER TABLE `bbp_adm_aplicacao` DISABLE KEYS */;
INSERT INTO `bbp_adm_aplicacao` VALUES (7,'Controle de Processos','BBHive Administrativo',NULL,'http://redesimples.prod/e-solution/servicos/bbhive/','1','bbhive.gif'),(8,'Controle de Processos','BBHive Operacional','','http://redesimples.prod/corporativo/servicos/bbhive/','1','bbhive.gif'),(9,'Controle de Processos','BBHive Público','','http://redesimples.prod/servicos/bbhive/','1','bbhive.gif'),(13,'Controle de acessos','Policy','observação','http://redesimples.prod/e-solution/servicos/policy/','1','policy.gif');
/*!40000 ALTER TABLE `bbp_adm_aplicacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_autenticacao`
--

DROP TABLE IF EXISTS `bbp_adm_autenticacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_autenticacao` (
  `bbp_adm_aut_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_aut_usuario` varchar(75) DEFAULT NULL,
  `bbp_adm_aut_senha` varchar(50) DEFAULT NULL,
  `bbp_adm_aut_ip` varchar(25) DEFAULT NULL,
  `bbp_adm_acesso` datetime DEFAULT '0000-00-00 00:00:00',
  `bbp_adm_nivel` int(11) DEFAULT '774',
  `bbp_adm_user` char(1) DEFAULT '0',
  PRIMARY KEY (`bbp_adm_aut_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_autenticacao`
--

LOCK TABLES `bbp_adm_autenticacao` WRITE;
/*!40000 ALTER TABLE `bbp_adm_autenticacao` DISABLE KEYS */;
INSERT INTO `bbp_adm_autenticacao` VALUES (1,'bbpass@adm','e8d95a51f3af4a3b134bf6bb680a213a','0.0.0.0','2017-09-13 11:58:33',774,'1'),(6,'tecnica@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a','0.0.0.0','2017-07-14 17:45:10',774,'0');
/*!40000 ALTER TABLE `bbp_adm_autenticacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock`
--

DROP TABLE IF EXISTS `bbp_adm_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock` (
  `bbp_adm_loc_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_loc_nome` varchar(100) DEFAULT NULL,
  `bbp_adm_loc_arquivo` varchar(255) DEFAULT NULL,
  `bbp_adm_loc_observacao` blob,
  `bbp_adm_loc_diretorio` varchar(50) NOT NULL,
  `bbp_adm_loc_ativo` char(1) DEFAULT '1',
  `bbp_adm_loc_icone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bbp_adm_loc_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock`
--

LOCK TABLES `bbp_adm_lock` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock` DISABLE KEYS */;
INSERT INTO `bbp_adm_lock` VALUES (9,'Freepass','freepass.php','    Livre acesso','freepass','1','livre acesso.gif'),(10,'Nopass','nopass.php','     Acesso negado','nopass','1','acesso negado.gif'),(11,'Login e Senha','login.php','   ','login','1','login.gif'),(12,'Firewall','firewall.php','   ','firewall','1','firewall.gif'),(13,'Biometria','biometria.php','   ','biometria','1','biometria.gif'),(14,'Assinatura Digital','assinatura.php','    ','assinaturadigital','1','assinatura.gif'),(15,'SMS','sms.php','     Envio da chave por mensagem de texto','sms','1','sms.gif'),(16,'Login e Senha Cidadao','login_acad.php','    ','login_acad','1','login cidadaobr.gif'),(17,'Login CBR','login_cbr.php',' Utilizado para autenticar os usuários do CBR 2.0','login_cbr','1','login cidadaobr.gif'),(18,'Biometria - Nitgen','biometria_nitgen.php',NULL,'biometria_nitgen','1','biometria.gif'),(19,'Login CPF','login_chave.php',' Utilizado para autenticar os usuários via CPF','login_chave','1','login chave.gif');
/*!40000 ALTER TABLE `bbp_adm_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock_aplicacao`
--

DROP TABLE IF EXISTS `bbp_adm_lock_aplicacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock_aplicacao` (
  `bbp_adm_lock_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_loc_codigo` int(11) DEFAULT NULL,
  `bbp_adm_apl_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbp_adm_lock_codigo`),
  KEY `bbp_adm_loc_codigo` (`bbp_adm_loc_codigo`),
  KEY `bbp_adm_apl_codigo` (`bbp_adm_apl_codigo`),
  CONSTRAINT `bbp_adm_apl_codigo` FOREIGN KEY (`bbp_adm_apl_codigo`) REFERENCES `bbp_adm_aplicacao` (`bbp_adm_apl_codigo`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `bbp_adm_loc_codigo` FOREIGN KEY (`bbp_adm_loc_codigo`) REFERENCES `bbp_adm_lock` (`bbp_adm_loc_codigo`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock_aplicacao`
--

LOCK TABLES `bbp_adm_lock_aplicacao` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock_aplicacao` DISABLE KEYS */;
INSERT INTO `bbp_adm_lock_aplicacao` VALUES (1,11,13),(28,11,7),(29,11,8),(31,11,9);
/*!40000 ALTER TABLE `bbp_adm_lock_aplicacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock_assinatura`
--

DROP TABLE IF EXISTS `bbp_adm_lock_assinatura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock_assinatura` (
  `bbp_adm_lock_ass_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_lock_ass_nome` varchar(100) DEFAULT NULL,
  `bbp_adm_lock_ass_email` varchar(100) NOT NULL DEFAULT '',
  `bbp_adm_lock_ass_cpf` bigint(12) NOT NULL DEFAULT '0',
  `bbp_adm_lock_ass_acesso` datetime DEFAULT '0000-00-00 00:00:00',
  `bbp_adm_lock_ass_obs` text,
  PRIMARY KEY (`bbp_adm_lock_ass_codigo`),
  UNIQUE KEY `bbp_adm_lock_ass_email` (`bbp_adm_lock_ass_email`),
  UNIQUE KEY `bbp_adm_lock_ass_cpf` (`bbp_adm_lock_ass_cpf`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock_assinatura`
--

LOCK TABLES `bbp_adm_lock_assinatura` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock_assinatura` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbp_adm_lock_assinatura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock_biometria`
--

DROP TABLE IF EXISTS `bbp_adm_lock_biometria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock_biometria` (
  `bbp_adm_lock_bio_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_lock_bio_nome` varchar(75) DEFAULT NULL,
  `bbp_adm_lock_bio_email` varchar(75) DEFAULT NULL,
  `bbp_adm_lock_bio_chave` text,
  `bbp_adm_lock_bio_obs` text,
  `bbp_adm_lock_bio_acesso` datetime DEFAULT '0000-00-00 00:00:00',
  `bbh_adm_lock_bio_imagem` blob,
  `bbp_adm_loc_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbp_adm_lock_bio_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock_biometria`
--

LOCK TABLES `bbp_adm_lock_biometria` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock_biometria` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbp_adm_lock_biometria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock_firewall`
--

DROP TABLE IF EXISTS `bbp_adm_lock_firewall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock_firewall` (
  `bbp_adm_lock_fir_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_lock_fir_ip` varchar(50) DEFAULT NULL,
  `bbp_adm_lock_fir_obs` text,
  PRIMARY KEY (`bbp_adm_lock_fir_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock_firewall`
--

LOCK TABLES `bbp_adm_lock_firewall` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock_firewall` DISABLE KEYS */;
/*!40000 ALTER TABLE `bbp_adm_lock_firewall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock_loginchave`
--

DROP TABLE IF EXISTS `bbp_adm_lock_loginchave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock_loginchave` (
  `bbp_adm_lock_log_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_lock_log_nome` varchar(75) DEFAULT NULL,
  `bbp_adm_lock_log_chave` varchar(75) NOT NULL DEFAULT '',
  `bbp_adm_lock_log_senha` varchar(50) NOT NULL DEFAULT '',
  `bbp_adm_lock_log_nasc` date DEFAULT NULL,
  `bbp_adm_lock_log_cargo` varchar(255) DEFAULT NULL,
  `bbh_adm_lock_log_nivel` int(11) NOT NULL DEFAULT '784',
  `bbh_adm_lock_log_sexo` char(1) NOT NULL DEFAULT 'm',
  `bbp_adm_lock_log_acesso` datetime DEFAULT '0000-00-00 00:00:00',
  `bbp_adm_lock_log_obs` text,
  `bbp_adm_lock_log_ativo` char(1) DEFAULT '1',
  PRIMARY KEY (`bbp_adm_lock_log_codigo`),
  KEY `bbp_adm_lock_log_email` (`bbp_adm_lock_log_chave`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock_loginchave`
--

LOCK TABLES `bbp_adm_lock_loginchave` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock_loginchave` DISABLE KEYS */;
INSERT INTO `bbp_adm_lock_loginchave` VALUES (1,'Robson Cruz','63858536245','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','0000-00-00 00:00:00',NULL,'1'),(2,'Emerson Rios','16956820846','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','0000-00-00 00:00:00',NULL,'1');
/*!40000 ALTER TABLE `bbp_adm_lock_loginchave` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock_loginsenha`
--

DROP TABLE IF EXISTS `bbp_adm_lock_loginsenha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock_loginsenha` (
  `bbp_adm_lock_log_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_lock_log_nome` varchar(75) DEFAULT NULL,
  `bbp_adm_lock_log_email` varchar(75) NOT NULL DEFAULT '',
  `bbp_adm_lock_log_senha` varchar(50) NOT NULL DEFAULT '',
  `bbp_adm_lock_log_nasc` date DEFAULT NULL,
  `bbp_adm_lock_log_cargo` varchar(255) DEFAULT NULL,
  `bbh_adm_lock_log_nivel` int(11) NOT NULL DEFAULT '784',
  `bbh_adm_lock_log_sexo` char(1) NOT NULL DEFAULT 'm',
  `bbp_adm_lock_log_acesso` datetime DEFAULT '0000-00-00 00:00:00',
  `bbp_adm_lock_log_obs` text,
  `bbp_adm_lock_log_ativo` char(1) DEFAULT '1',
  PRIMARY KEY (`bbp_adm_lock_log_codigo`),
  KEY `bbp_adm_lock_log_email` (`bbp_adm_lock_log_email`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock_loginsenha`
--

LOCK TABLES `bbp_adm_lock_loginsenha` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock_loginsenha` DISABLE KEYS */;
INSERT INTO `bbp_adm_lock_loginsenha` VALUES (6,'Robson Cruz','tecnica@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a','1975-06-23','Gerente de Projetos',784,'m','2017-11-15 15:32:17','Efetuando a gestão dos projetos de desenvolvimento de software para a Blackbee Sistemas na produção, homologação e implantação de seus produtos em servidores dedicados ou compartilhados.','1'),(7,'Renato Augusto','renato.augusto@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-05-29 14:54:59',NULL,'1'),(8,'Cassiano Brito','cassiano.brito@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-09-13 10:59:07',NULL,'1'),(9,'André Luis','andre.luis@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-09-13 10:58:17',NULL,'1'),(10,'Bruno Azevedo','bruno.azevedo@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-06-28 10:34:35',NULL,'1'),(11,'Carlos Sena','carlos.sena@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-09-13 10:58:50',NULL,'1'),(12,'Afonso Bento','afonso.bento@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-09-13 10:58:30',NULL,'1'),(13,'Braga Bueno','braga.bueno@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-06-05 17:50:12',NULL,'1'),(14,'Celso Luz','celso.luz@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-05-30 13:28:38',NULL,'1'),(15,'Daniel Abreu','daniel.abreu@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-05-24 18:06:34',NULL,'1'),(16,'Fabio Faria','fabio.faria@longevo.com.br','e8d95a51f3af4a3b134bf6bb680a213a',NULL,NULL,784,'m','2017-06-05 11:54:11',NULL,'1');
/*!40000 ALTER TABLE `bbp_adm_lock_loginsenha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bbp_adm_lock_sms`
--

DROP TABLE IF EXISTS `bbp_adm_lock_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bbp_adm_lock_sms` (
  `bbp_adm_lock_sms_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `bbp_adm_lock_sms_nome` varchar(105) DEFAULT NULL,
  `bbp_adm_lock_sms_email` varchar(75) DEFAULT NULL,
  `bbp_adm_lock_sms_chave` varchar(8) DEFAULT '0',
  `bbp_adm_lock_sms_celular` varchar(20) DEFAULT NULL,
  `bbp_adm_lock_sms_observacao` text,
  `bbp_adm_lock_sms_acesso` datetime DEFAULT NULL,
  PRIMARY KEY (`bbp_adm_lock_sms_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbp_adm_lock_sms`
--

LOCK TABLES `bbp_adm_lock_sms` WRITE;
/*!40000 ALTER TABLE `bbp_adm_lock_sms` DISABLE KEYS */;
INSERT INTO `bbp_adm_lock_sms` VALUES (1,'Emerson','emersonrios@backsite.com.br','0','13 78033392','',NULL);
/*!40000 ALTER TABLE `bbp_adm_lock_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pol_aplicacao`
--

DROP TABLE IF EXISTS `pol_aplicacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pol_aplicacao` (
  `pol_apl_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `pol_apl_nome` varchar(75) DEFAULT NULL,
  `pol_apl_descricao` text,
  `pol_apl_url` varchar(150) DEFAULT NULL,
  `pol_apl_icone` varchar(255) DEFAULT NULL,
  `pol_apl_relevancia` int(11) DEFAULT NULL,
  PRIMARY KEY (`pol_apl_codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pol_aplicacao`
--

LOCK TABLES `pol_aplicacao` WRITE;
/*!40000 ALTER TABLE `pol_aplicacao` DISABLE KEYS */;
INSERT INTO `pol_aplicacao` VALUES (7,'BBHive','Sistema de Workflow da Blackbee','http://redesimples.prod','bbhive.gif',0),(10,'BBPASS','Sistema de Validação de Permissão de Passaporte da Black Bee Back','http://redesimples.prod','bbpass.gif',0);
/*!40000 ALTER TABLE `pol_aplicacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pol_apontamento`
--

DROP TABLE IF EXISTS `pol_apontamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pol_apontamento` (
  `apo_codigo` int(10) NOT NULL AUTO_INCREMENT,
  `pol_apl_codigo` int(10) DEFAULT NULL,
  `pol_aud_acao` text,
  `apo_tempo_execucao` int(11) DEFAULT '0',
  `apo_observacao` text,
  PRIMARY KEY (`apo_codigo`),
  KEY `pol_apl_codigo` (`pol_apl_codigo`),
  FULLTEXT KEY `pol_aud_acao` (`pol_aud_acao`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pol_apontamento`
--

LOCK TABLES `pol_apontamento` WRITE;
/*!40000 ALTER TABLE `pol_apontamento` DISABLE KEYS */;
INSERT INTO `pol_apontamento` VALUES (1,7,'Acessou a página principal do sistema - BBHive corporativo.',3,''),(2,7,'Efetuou Login no BBHIVE.',1,''),(3,7,'Acessou a página para cadastro de (Solicitação(ões)) - BBHive público.',5,'');
/*!40000 ALTER TABLE `pol_apontamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pol_auditoria`
--

DROP TABLE IF EXISTS `pol_auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pol_auditoria` (
  `pol_aud_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `pol_aud_usuario` varchar(100) DEFAULT NULL,
  `pol_aud_acao` text,
  `pol_aud_momento` datetime DEFAULT '0000-00-00 00:00:00',
  `pol_aud_ip` varchar(30) DEFAULT NULL,
  `pol_aud_nivel` varchar(30) DEFAULT NULL,
  `pol_aud_obs` text,
  `pol_aud_relevancia` int(11) NOT NULL DEFAULT '0',
  `pol_apl_codigo` int(11) DEFAULT NULL,
  `pol_aud_ip_aplic` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`pol_aud_codigo`),
  KEY `pol_apl_codigo` (`pol_apl_codigo`),
  KEY `pol_aud_usuario` (`pol_aud_usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pol_auditoria`
--

LOCK TABLES `pol_auditoria` WRITE;
/*!40000 ALTER TABLE `pol_auditoria` DISABLE KEYS */;
INSERT INTO `pol_auditoria` VALUES (1,'tecnica@longevo.com.br','Acessou a página principal do sistema - BBHive corporativo.','2017-11-15 15:31:43','172.17.0.3','1',NULL,0,7,'0'),(2,'tecnica@longevo.com.br','Acessou a página principal do sistema - BBHive corporativo.','2017-11-15 15:31:43','172.17.0.3','1',NULL,0,7,'0'),(3,'tecnica@longevo.com.br','Efetuou Login no BBHIVE.','2017-11-15 15:32:17','172.17.0.3','1',NULL,0,7,'0');
/*!40000 ALTER TABLE `pol_auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pol_grafico`
--

DROP TABLE IF EXISTS `pol_grafico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pol_grafico` (
  `pol_graf_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `pol_pol_codigo` int(11) DEFAULT NULL,
  `pol_graf_titulo` varchar(255) DEFAULT NULL,
  `pol_graf_tipo` varchar(255) DEFAULT NULL,
  `pol_graf_grupo` char(1) DEFAULT NULL,
  `pol_apl_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`pol_graf_codigo`),
  KEY `pol_aplicacao_pol_apl_codigo` (`pol_apl_codigo`),
  KEY `politicas` (`pol_pol_codigo`),
  CONSTRAINT `pol_aplicacao_pol_apl_codigo` FOREIGN KEY (`pol_apl_codigo`) REFERENCES `pol_aplicacao` (`pol_apl_codigo`) ON UPDATE NO ACTION,
  CONSTRAINT `politicas` FOREIGN KEY (`pol_pol_codigo`) REFERENCES `pol_politica` (`pol_pol_codigo`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pol_grafico`
--

LOCK TABLES `pol_grafico` WRITE;
/*!40000 ALTER TABLE `pol_grafico` DISABLE KEYS */;
INSERT INTO `pol_grafico` VALUES (1,1,'Fábrica','linha','',7),(2,1,'gfjg','pizza','4',7);
/*!40000 ALTER TABLE `pol_grafico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pol_politica`
--

DROP TABLE IF EXISTS `pol_politica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pol_politica` (
  `pol_pol_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `pol_pol_titulo` varchar(255) DEFAULT NULL,
  `pol_usu_identificacao` varchar(255) DEFAULT NULL,
  `pol_pol_criacao` datetime DEFAULT NULL,
  `pol_pol_descricao` text,
  `pol_pol_xml` blob,
  `pol_apl_codigo` int(11) DEFAULT NULL,
  PRIMARY KEY (`pol_pol_codigo`),
  KEY `pol_apl_codigo_pol` (`pol_apl_codigo`),
  CONSTRAINT `pol_apl_codigo_pol` FOREIGN KEY (`pol_apl_codigo`) REFERENCES `pol_aplicacao` (`pol_apl_codigo`) ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pol_politica`
--

LOCK TABLES `pol_politica` WRITE;
/*!40000 ALTER TABLE `pol_politica` DISABLE KEYS */;
INSERT INTO `pol_politica` VALUES (1,'Técnica','tecnica@blackbee.com.br','2014-02-14 00:00:00',NULL,'<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n<politica><condicao><quem nome=\"Quem\" campo=\"pol_aud_usuario\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><quando nome=\"Quando\" campo=\"pol_aud_momento\" tipoCondicao=\"\" valor=\"\" campoData=\"1\" publicado=\"0\"/><onde nome=\"Onde\" campo=\"pol_aud_ip\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><oque nome=\"O que\" campo=\"pol_aud_acao\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><relevancia nome=\"Relev\�ncia\" campo=\"pol_aud_relevancia\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/></condicao><ordenacao><quem nome=\"Quem\" campo=\"pol_aud_usuario\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><quando nome=\"Quando\" campo=\"pol_aud_momento\" tipoCondicao=\"2\" valor=\"DESC\" campoData=\"1\" publicado=\"1\"/><onde nome=\"Onde\" campo=\"pol_aud_ip\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><oque nome=\"O que\" campo=\"pol_aud_acao\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><relevancia nome=\"Relev\�ncia\" campo=\"pol_aud_relevancia\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/></ordenacao></politica>\n',7),(2,'Fábrica','tecnica@blackbee.com.br','2014-02-14 00:00:00',NULL,'<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n<politica><condicao><quem nome=\"Quem\" campo=\"pol_aud_usuario\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><quando nome=\"Quando\" campo=\"pol_aud_momento\" tipoCondicao=\"\" valor=\"\" campoData=\"1\" publicado=\"0\"/><onde nome=\"Onde\" campo=\"pol_aud_ip\" tipoCondicao=\"=\" valor=\"179.99.214.233\" campoData=\"0\" publicado=\"1\"/><oque nome=\"O que\" campo=\"pol_aud_acao\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><relevancia nome=\"Relev\�ncia\" campo=\"pol_aud_relevancia\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/></condicao><ordenacao><quem nome=\"Quem\" campo=\"pol_aud_usuario\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><quando nome=\"Quando\" campo=\"pol_aud_momento\" tipoCondicao=\"2\" valor=\"DESC\" campoData=\"1\" publicado=\"1\"/><onde nome=\"Onde\" campo=\"pol_aud_ip\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><oque nome=\"O que\" campo=\"pol_aud_acao\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/><relevancia nome=\"Relev\�ncia\" campo=\"pol_aud_relevancia\" tipoCondicao=\"\" valor=\"\" campoData=\"0\" publicado=\"0\"/></ordenacao></politica>\n',7);
/*!40000 ALTER TABLE `pol_politica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pol_usuario`
--

DROP TABLE IF EXISTS `pol_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pol_usuario` (
  `pol_usu_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `pol_usu_identificacao` varchar(255) DEFAULT NULL,
  `pol_usu_nome` varchar(255) DEFAULT NULL,
  `pol_usu_ultimoAcesso` datetime DEFAULT '0000-00-00 00:00:00',
  `pol_usu_sexo` char(1) DEFAULT 'm',
  `pol_usu_observacao` text,
  `pol_usu_nivel` int(11) DEFAULT '684',
  PRIMARY KEY (`pol_usu_codigo`),
  UNIQUE KEY `identificacao` (`pol_usu_identificacao`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pol_usuario`
--

LOCK TABLES `pol_usuario` WRITE;
/*!40000 ALTER TABLE `pol_usuario` DISABLE KEYS */;
INSERT INTO `pol_usuario` VALUES (10,'freepass@bbpass','Freepass','0000-00-00 00:00:00','m','',684),(11,'tecnica@longevo.com.br','Blackbee','0000-00-00 00:00:00','m','Usuário para acesso ao policy',684);
/*!40000 ALTER TABLE `pol_usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-15 18:09:03
